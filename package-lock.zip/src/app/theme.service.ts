import { Injectable } from '@angular/core';

export const darkTheme = {
  'text-colour-one': '#192038',
  'background-color': '#ebeff5',
  'div-color':'#ffffff',
  'border-bottom-card':'#dee1ef',
  'border-table':'#e6e8f5',
  'table-body':'#efefef',
  'gray-colour':'#dfe0f3',
  'head-panel':'#f9f9f9',
  'text-color-two':'#3e4f6f',
  'blue-border':'#b6b6ca',
  'paret-green':'#00c873',
  'blue-shade':'#e9ecff',
  'menu-icon':'#bbbdc5',
  'drop-shadows1':'rgba(0,0,0,.2)',
  'drop-shadows2':'rgba(0,0,0,.14)',
  'drop-shadow3':'rgba(0,0,0,.12)',
  'black-green' :'#00c873',
  'card-header':'#00c873'
};

export const lightTheme = {
  'text-colour-one': '#efefef',
  'background-color': 'black',
  'div-color':'#222b45',
  'border-bottom-card':'#151a30',
  'border-table':'#060606',
  'table-body':'#18192b',
  'gray-colour':'#484343',
  'head-panel':'#222235',
  'text-color-two':'#8e9bb4',
  'blue-border':'#293975',
  'paret-green':'#00c873',
  'blue-shade':'#1f233a',
  'menu-icon':'#bbbdc5',
  'drop-shadows1':'rgb(11, 16, 29)',
  'drop-shadows2':'rgb(3, 3, 8)',
  'drop-shadow3':'rgb(3, 3, 8)',
  'black-green':'#efefef',
  'card-header':'#222b45'
};

@Injectable({ providedIn: 'root' })
export class ThemeService {
  toggleDark() {
    this.setTheme(darkTheme);
  }

  toggleLight() {
    this.setTheme(lightTheme);
  }

  private setTheme(theme: {}) {
    Object.keys(theme).forEach(k =>
      document.documentElement.style.setProperty(`--${k}`, theme[k])
    );
  }
}