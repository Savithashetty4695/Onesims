import { Component, OnInit,AfterViewInit, ViewChildren } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';
import{ChartOptions} from 'chart.js';
import { FormControl } from '@angular/forms';
import { ThemeService } from '../../theme.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  ngOnInit() {
  }
  
  show:boolean=true;
  toggle():any{
  this.show=!this.show
  }
  darkTheme = new FormControl(false);
  constructor(private themeService: ThemeService) {
    this.darkTheme.valueChanges.subscribe(value => {
      if (value) {
        this.themeService.toggleDark();
      } else {
        this.themeService.toggleLight();
      }
    });
  }
}
