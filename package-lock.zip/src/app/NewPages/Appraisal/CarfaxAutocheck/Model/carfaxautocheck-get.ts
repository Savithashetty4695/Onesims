export class CarfaxAutockeck {
    public imbCarfaxIcon: boolean;
    public imbCarfaxIconEdit: boolean;

    public btnReportPurchaseEdit: boolean;
    public imbAutocheck: boolean;
    public btnAutocheckPurchase: boolean;

    public imbCarfaxIconImageUrl: number;
    public imbCarfaxIconJavascript: string;

    public imbAutocheckImageUrl: string;
    public imbAutocheckJavascript: string;


    public lblErrorText: string;
    public lblErrorVisible: boolean;
    public imbCarfaxImageUrl: string;
    
}
