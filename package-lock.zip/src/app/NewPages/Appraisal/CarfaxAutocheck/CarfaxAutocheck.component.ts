import { Component, OnInit } from '@angular/core';
import {Response} from '@angular/http';
import {KBBServiceService} from '../Services/kbbservice.service';
import {VinVehicleDetails} from '../Model/vin-vehicle-details';
import {HttpServiceService} from '../Services/http-service.service';
import {VehicleParams} from '../Model/vehicle-params.model';
import {CarfaxAutockeck} from './Model/carfaxautocheck-get';
import {ErrorHandler}from '../common/error-handler';
import {LinkEnum} from '../Model/link-enum.enum';


@Component({
    selector: 'app-CarfaxAutochek',
    templateUrl: './CarfaxAutochek.component.html',
    styleUrls: ['./CarfaxAutochek.component.css'],
})
export class CarfaxAutochekHeaderComponent implements OnInit {
    indexCounter: number;
    CarfaxAutockeckDetails: CarfaxAutockeck;
    vehicleparams: VehicleParams;
    errorHandler: ErrorHandler;
    carfaxurl: string;

    constructor(public kbbServiceService: KBBServiceService, public httpService: HttpServiceService) {
        
            this.CarfaxAutockeckDetails = new CarfaxAutockeck();
        this.vehicleparams = new VehicleParams();
        this.errorHandler = new ErrorHandler();
    }


    callAutoCheckJavascript() {
        window.open(this.CarfaxAutockeckDetails.imbAutocheckJavascript, '_blank', 'left=250,top=10,menubar=0,scrollbars=yes,width=700,height=670');
    }



    callcarfaxJavascript(): void {
        window.open(this.CarfaxAutockeckDetails.imbCarfaxIconJavascript, '_blank', 'left=250,top=10,menubar=0,scrollbars=yes,width=700,height=670');
    }

   persistCarfaxAutocheckData() {
        this.kbbServiceService.setData(this.CarfaxAutockeckDetails, LinkEnum.CarfaxAutocheckPageonload);
    }

    ngOnInit() {
        this.vehicleparams = this.kbbServiceService.getVehicleParameters();
        
  let cachedAutoCheckCarfaxData = this.kbbServiceService.GetCarfaxAutocheckFromCache(this.vehicleparams);
        if (cachedAutoCheckCarfaxData != null)
        {
            this.CarfaxAutockeckDetails = cachedAutoCheckCarfaxData;
          //  this.carfaxurl = this.getCarFaxIcon(this.CarfaxAutockeckDetails.imbCarfaxIconImageUrl);
            this.carfaxurl = this.CarfaxAutockeckDetails.imbCarfaxImageUrl;
       }
        else
            this.kbbServiceService.GetCarfaxAutocheckFromAPI(this.vehicleparams).subscribe(
                (result: CarfaxAutockeck) => {
                    (this.CarfaxAutockeckDetails = result);
                    this.persistCarfaxAutocheckData();
                   // this.carfaxurl = this.getCarFaxIcon(this.CarfaxAutockeckDetails.imbCarfaxIconImageUrl);
                    this.carfaxurl = this.CarfaxAutockeckDetails.imbCarfaxImageUrl;
                },
                (error: Response | any) => this.errorHandler.handleError(error));
        
   }

    // Commented below because of  Carfax Icon was not displaying in IPAD (did the same logic from server side)
    //getCarFaxIcon(urlid: number) {
    //    switch (urlid) {
          
    //        case urlid = 10:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/majorProb.gif';

    //        case urlid = 20:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/frameDamage.gif';

    //        case urlid = 30:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/accident.gif';

    //        case urlid = 40:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/accident.gif';

    //        case urlid = 50:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/oneowner.gif';

    //        case urlid = 51:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/oneowner.gif';

    //        case urlid = 52:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/twoowner.gif';

    //        case urlid = 53:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/threeowner.gif';

    //        case urlid = 54:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/fourowner.gif';

    //        case urlid = 55:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/fourplusowner.png';

    //        case urlid = 60:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/bbg.png';

    //        case urlid = 70:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/noofservice.GIF';

    //        case urlid = 80:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/no_VIN.gif';

    //        case urlid = 90:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/exception.gif';

    //        default:
    //            return '../../angular/src/assets/ImagesCarfax/CarFaxIcons/default.gif';
             
           
    //    }

    //}

    OnCarfaxReport() {

        this.kbbServiceService.GetCarfaxReportFromAPI(this.vehicleparams).subscribe(
            (result: CarfaxAutockeck) => {
                (this.CarfaxAutockeckDetails.btnReportPurchaseEdit = result.btnReportPurchaseEdit,
                    this.CarfaxAutockeckDetails.imbCarfaxIcon = result.imbCarfaxIcon,
                    this.CarfaxAutockeckDetails.imbCarfaxIconJavascript = result.imbCarfaxIconJavascript,
                    this.CarfaxAutockeckDetails.imbCarfaxIconImageUrl = result.imbCarfaxIconImageUrl,
                    this.CarfaxAutockeckDetails.lblErrorText = result.lblErrorText,
                    this.CarfaxAutockeckDetails.lblErrorVisible = result.lblErrorVisible                                      
                    );
            },
            (error: Response | any) => this.errorHandler.handleError(error));

       
    }

    OnAutocheckReport() {

        this.kbbServiceService.GetAutcCheckReportFromAPI(this.vehicleparams).subscribe(
            (result: CarfaxAutockeck) => {
                (this.CarfaxAutockeckDetails.imbAutocheckImageUrl = result.imbAutocheckImageUrl,
                    this.CarfaxAutockeckDetails.imbAutocheck = result.imbAutocheck,
                    this.CarfaxAutockeckDetails.btnAutocheckPurchase = result.btnAutocheckPurchase,
                    this.CarfaxAutockeckDetails.imbAutocheckJavascript = result.imbAutocheckJavascript,
                    this.CarfaxAutockeckDetails.lblErrorText = result.lblErrorText,
                    this.CarfaxAutockeckDetails.lblErrorVisible = result.lblErrorVisible
                    );
            },
            (error: Response | any) => this.errorHandler.handleError(error));
    }
      
    
}
   
