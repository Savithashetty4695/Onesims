import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'app-book-value-table',
    templateUrl: './book-value-table.component.html',
    styleUrls: ['./book-value-table.component.css']
})
export class BookValueTableComponent implements OnInit {
    @Input() selectedBook: string;
    showBlackBook: boolean;
    showManheim: boolean;
    showNADA: boolean;
    showKBB: boolean;
    @Input() booksTableJson: any;
    constructor() {
        this.booksTableJson = this.booksTableJson;
    }

    ngOnInit() {
        if (this.selectedBook == 'BlackBook') {
            this.showBlackBook = true;
        } else if (this.selectedBook == 'Manheim') {
            this.showManheim = true;
        } else if (this.selectedBook == 'NADA') {
            this.showNADA = true;
        } else if (this.selectedBook == 'KBB') {
            this.showKBB = true;
        }
    }

}
