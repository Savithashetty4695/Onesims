// import { Observable } from 'rxjs/Observable';
import {Response} from '@angular/http';
import 'rxjs/add/operator/catch';
export class ErrorHandler {
    public handleError(error: Response | any) {
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            if (body != undefined) {
                if (body.data != null)
                    console.error(body.data.Message + '\n' + body.data.ExceptionMessage + '\n' + body.data.ExceptionType + '\n' + body.data.StackTrace);
                else
                    console.error(body.statusCode + '\n' + body.message);
            }
        } else {
            errMsg = error.message ? error.message : error.toString();
            console.error(errMsg +'\n'+error.stack );
        }

    }
}
