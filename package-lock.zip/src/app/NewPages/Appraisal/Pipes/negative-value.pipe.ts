import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'negativeValuePipe'
})
export class NegativeValuePipe implements PipeTransform {

    transform(value: string, args?: any): any {
        if (value != null && value != 'undefined') {
            if (value.indexOf('-') != -1)
                return `(${value.replace('-', '')})`;
        }
        return value;
    }

}
