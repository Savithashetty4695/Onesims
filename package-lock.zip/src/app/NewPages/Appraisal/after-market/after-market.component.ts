import { Response } from '@angular/common/esm5/http';
import { Component, OnInit, ElementRef, Input, ViewChild } from '@angular/core';
import { KBBServiceService } from '../Services/kbbservice.service';
import { HttpServiceService } from '../Services/http-service.service';
import { Questions } from '../Model/Questions.model';
import { VehicleParams } from '../Model/vehicle-params.model';
import { ErrorHandler } from '../common/error-handler';
import { LinkEnum } from '../model/link-enum.enum';
import { AnswerModel, Answer } from '../model/answer-model';
import { SIMSResponseData } from '../model/simsresponse-data';
import { AfterFactoryOptionsKBB } from './Model/After-factory-option-get';
import { AfterVehicleFactoryOptionsKBB } from './Model/After-factory-option-post';
import { AfterMarketComments } from './Model/after-factory-option-comment';
import { Subscription } from 'rxjs';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

declare var Close: any;

@Component({
    selector: 'app-after-market',
    templateUrl: './after-market.component.html',
    styleUrls: ['./after-market.component.css']
})
export class AfterMarketComponent implements OnInit {

    params: VehicleParams;
    questions: Questions[];
    answer: Answer[];
    aftermarket: AfterFactoryOptionsKBB;
    listfactory: AfterFactoryOptionsKBB[];
    afterMarketFactoryOptions: AfterFactoryOptionsKBB[];
    afterfactoryoptionpost: AfterVehicleFactoryOptionsKBB;
    answerModel = AnswerModel;
    response: Answer;
    aftermarketcomments: AfterMarketComments;
    public comment: string;
    comments: string;
    isKBBfailure: boolean;
    errorHandler: ErrorHandler;
    errorLabel: string;
    checkIfOthersAreSelected: boolean;
    @Input() showSaveCloseButtons: boolean;
    @Input() kbbEditObject: string;
    editParams: any;
    SACStatusID: number;
    isCCAVehicle: boolean = false;
    reqResubmit: boolean = false;
    editMode: boolean = false;
    @ViewChild('resubmitpopup') resubmitpopup: any;
    busyA: Subscription;
    busyB: Subscription;
    busyC: Subscription;
    busyD: Subscription;
    current: number;
    disableSavebtn: boolean;
    IsDDCVehicle: boolean;
    KbbDecodeVehicleSource: any;
    constructor(public kbbServiceService: KBBServiceService, public httpService: HttpServiceService, private elRef: ElementRef, private modalService: NgbModal) {
        this.params = new VehicleParams();
        this.afterMarketFactoryOptions = new Array<AfterFactoryOptionsKBB>();
        this.afterfactoryoptionpost = new AfterVehicleFactoryOptionsKBB();
        this.questions = new Array<Questions>();
        this.answer = new Array<Answer>();
        this.aftermarketcomments = new AfterMarketComments();
        this.answerModel.prototype = new AnswerModel();
        this.answerModel.prototype.Answers = this.answer;
        this.errorHandler = new ErrorHandler();
        this.listfactory = new Array<AfterFactoryOptionsKBB>();
        this.KbbDecodeVehicleSource = HttpServiceService.KbbDecodeVehicleSource;
    }

    toggle = [];
    show = 'Side';
    AfterMarketQuestion: any = [];
    processData(data) {


        let afterMarketRaw: JSON = data;
        let afterMarketArray = Object.keys(afterMarketRaw).map(function (k) { return afterMarketRaw[k] });
        var groups = {};
        for (var i = 0; i < afterMarketArray.length; i++) {
            let groupName: any = afterMarketArray[i].vehicleConditionCategoryName;
            if (!groups[groupName]) {
                groups[groupName] = [];
            }
            groups[groupName].push({
                label: afterMarketArray[i].label,
                vehicleConditionCategoryName: afterMarketArray[i].vehicleConditionCategoryName,
                questionId: afterMarketArray[i].questionId,
                questionType: afterMarketArray[i].questionType,
                maxStringLength: afterMarketArray[i].questionType,
                maximumValue: afterMarketArray[i].maximumValue,
                minimumValue: afterMarketArray[i].minimumValue,
                enumChoices: [afterMarketArray[i].enumChoices],
                comment: afterMarketArray[i].comment,
                tags: afterMarketArray[i].tags,
                acceptsComment: afterMarketArray[i].acceptsComment,
                value: afterMarketArray[i].value != null ? afterMarketArray[i].value.toLocaleLowerCase() == 'yes' ? true : false : false,
                vehicleConditionCategory: afterMarketArray[i].vehicleConditionCategory,
                vehicleSectionId: afterMarketArray[i].vehicleSectionId,
                vehicleSectionName: afterMarketArray[i].vehicleSectionName
            });
        }

        for (var groupName in groups) {
            this.AfterMarketQuestion.push({
                categoryName: groupName, categoryId: Math.random(), Questions: groups[groupName]
            });
        }
    }

    //Open-Close one card
    HideShowAfterMarket(ind): any {
        if (ind == 255) {
            var contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont255');
            var icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon255');
            this.ShowHide(icon, contentDiv);
            //for ipad issues and close all and open issue commented 24/04/2018
            //for (var i = 0; i < this.AfterMarketQuestion.length; i++) {
            //    let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont' + i);
            //    let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon' + i);
            //    if (contentDiv != undefined) {
            //        contentDiv.classList.add('collapse');
            //        icon.classList.add('fa-plus-square');
            //        icon.classList.remove('fa-minus-square');
            //    }
            //}
        } else {
            for (var i = 0; i < this.AfterMarketQuestion.length; i++) {
                if (i == ind) {
                    let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont' + ind);
                    let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon' + ind);
                    this.ShowHide(icon, contentDiv);

                }
                //else {

                //    let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont' + i);
                //    let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon' + i);
                //    if (contentDiv != undefined) {
                //        contentDiv.classList.add('collapse');
                //        icon.classList.add('fa-plus-square');
                //        icon.classList.remove('fa-minus-square');
                //    }
                // }
            }
            //for ipad issues and close all and open issue commented 24/04/2018
            //let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont255');
            //let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon255');
            //contentDiv.classList.add('collapse');
            //icon.classList.add('fa-plus-square');
            //icon.classList.remove('fa-minus-square');
        }

    }

    ShowHide(icon: any, contentDiv: any): void {
        if (contentDiv.classList.contains('collapse')) {
            contentDiv.classList.remove('collapse');
            icon.classList.add('fa-minus-square');
            icon.classList.remove('fa-plus-square');

        } else {
            contentDiv.classList.add('collapse');
            icon.classList.add('fa-plus-square');
            icon.classList.remove('fa-minus-square');

        }
    }
    SaveAndNext() {
        this.afterfactoryoptionpost.InvtrId = this.params.InventoryId;
        this.afterfactoryoptionpost.StoreId = this.params.StoreId;
        this.afterfactoryoptionpost.VehicleId = this.params.VehicleId;
        this.afterfactoryoptionpost.UserName = this.params.UserName;
        var counter = 0;
        this.isKBBfailure = this.params.IsKbbFailure;
        //this.isKBBfailure = true;
        this.aftermarketcomments.Comments = this.comments;
        this.aftermarketcomments.InvtrId = this.params.InventoryId
        this.aftermarketcomments.StoreId = this.params.StoreId;
        this.aftermarketcomments.UserName = this.params.UserName;
        this.aftermarketcomments.VehicleId = this.params.VehicleId;


        for (var itema of this.afterMarketFactoryOptions) {
            this.aftermarket = new AfterFactoryOptionsKBB();
            this.aftermarket.AfterMarketOptionId = itema.AfterMarketOptionId;
            this.aftermarket.Description = itema.Description;
            this.aftermarket.OptionKindId = itema.OptionKindId;
            this.aftermarket.Is_AfterMarketOption_Select = itema.Is_AfterMarketOption_Select;


            if (this.aftermarket.Is_AfterMarketOption_Select == true) {
                this.listfactory.push(this.aftermarket);
                counter++;
            }

        }
        //if (counter == 0) {
        //    this.errorLabel = 'Please select at least one option from Sonic Aftermarket';
        //    window.scrollTo(0, 0);
        //    return false;
        //}
        if (counter == 0) {
            this.aftermarket = new AfterFactoryOptionsKBB();
            this.aftermarket.AfterMarketOptionId = 1;
            this.aftermarket.Description = 'None';
            this.aftermarket.OptionKindId = 'AMFO';
            this.aftermarket.Is_AfterMarketOption_Select = true;
            this.listfactory.push(this.aftermarket);
        }


        this.afterfactoryoptionpost.AlternateFactoryOptionsLst = this.listfactory;
        // in edit mode check sacstatus
        if (this.editMode == true && this.SACStatusID == 403 && this.isCCAVehicle == true) {
            let options: NgbModalOptions = { backdrop: 'static', keyboard: false, windowClass: 'custom-modals' }
            this.modalService.open(this.resubmitpopup, options);
            return false;
        }
        else {
            this.SaveDataToDB();
            return true;
        }
    }

    setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    private SaveDataToDB() {
        this.kbbServiceService.SaveAfterFactoryOptions(this.afterfactoryoptionpost).subscribe(
            (result: SIMSResponseData) => result,
            (error: Response | any) => this.errorHandler.handleError(error));

        for (var question of this.AfterMarketQuestion)
            for (var item of question.Questions) {
                this.response = new Answer();
                this.response.label = item.label;
                this.response.questionId = item.questionId;
                this.response.questionType = item.questionType;
                this.response.tags = item.tags;
                this.response.value = item.value ? 'Yes' : 'false';
                this.response.vehicleConditionCategory = item.vehicleConditionCategory;
                this.response.vehicleConditionCategoryName = item.vehicleConditionCategoryName;
                this.response.vehicleSectionId = item.vehicleSectionId;
                this.response.vehicleSectionName = item.vehicleSectionName;
                this.response.comment = item.comment;
                this.answer.push(this.response);
            }

        this.answerModel.prototype.Answers = this.answer;
        this.answerModel.prototype.InvtrID = this.params.InventoryId;
        this.answerModel.prototype.StoreID = this.params.StoreId
        this.answerModel.prototype.VehicleID = this.params.VehicleId;
        this.answerModel.prototype.UserName = this.params.UserName;
        if (!this.isKBBfailure) {
            this.kbbServiceService.SaveResponse(this.answerModel.prototype, LinkEnum.SaveAfterMarket).subscribe(
                (result: SIMSResponseData) => this.Saved(result),
                (error: Response | any) => this.errorHandler.handleError(error));
        }
        //V3
        if (this.isKBBfailure || this.KbbDecodeVehicleSource.toString().split(',').includes(this.params.SourceType.toString()))// this.params.SourceType==110)
        {
            this.kbbServiceService.SaveAfterMarketComments(this.aftermarketcomments).subscribe(
                (result: SIMSResponseData) => this.Saved(result),
                (error: Response | any) => this.errorHandler.handleError(error));
        }
        //V3
        if (!this.isKBBfailure) {
            this.busyA = this.kbbServiceService.Getafterfactoryoption(this.params).subscribe(
                (result: AfterFactoryOptionsKBB[]) => {
                    this.afterMarketFactoryOptions = result;
                },
                (error: Response | any) => this.errorHandler.handleError(error));
        }
        if (this.editMode == true) {
            Close(0);
        }
    }

    //Resubmit changes
    ResubmitYes() {
        this.reqResubmit = true;
        this.SaveDataToDB();
        
        return true;
    }

    ngOnInit() {
        this.params = this.kbbServiceService.getVehicleParameters();
        if (this.kbbEditObject != null) {
            this.params = new VehicleParams();
            this.params = JSON.parse(this.kbbEditObject.replace(/'/g, '"'));
            this.editMode = true;
            this.SACStatusID = parseInt(this.params.SACStatusID.toString());
            this.isCCAVehicle = this.params.isCCAVehicle;
        }

        this.isKBBfailure = this.params.IsKbbFailure;
        if (this.KbbDecodeVehicleSource.includes(Number(this.params.SourceType))) {
            this.IsDDCVehicle = true;
        }
        //this.isKBBfailure = true;
        let cachedafterFactoryOptions = this.kbbServiceService.GetAfterFactoryOptionsFromCache(this.params);
        if (cachedafterFactoryOptions != null && cachedafterFactoryOptions.length > 0)
            this.afterMarketFactoryOptions = cachedafterFactoryOptions;
        else
            this.busyB = this.kbbServiceService.Getafterfactoryoption(this.params).subscribe(
                (result: AfterFactoryOptionsKBB[]) => {
                    this.afterMarketFactoryOptions = result;
                    this.persistsonicAfterMarketOptionsData();
                },
                (error: Response | any) => this.errorHandler.handleError(error));
        if (this.isKBBfailure) {
            let cachedaftermarketComments = this.kbbServiceService.GetAfterFactoryCommnetsFromCache(this.params);
            if (cachedaftermarketComments != null)
                this.comments = cachedaftermarketComments.Comments;
            else
                this.busyD = this.kbbServiceService.Getaftermarketcommnet(this.params).subscribe(
                    (result: AfterMarketComments) => {
                        this.comments = result.Comments;
                        this.persistAfterCommentsData();
                        this.kbbServiceService.isAfterMarketEnable.next(true);
                    },
                    (error: Response | any) => this.errorHandler.handleError(error));

        }
        if (!this.isKBBfailure) {
            let cachedAfterMarketOptions = this.kbbServiceService.GetQuestionsFromCache(this.params, LinkEnum.GetAfterMarket);
            if (cachedAfterMarketOptions != null && cachedAfterMarketOptions.length > 0) {
                this.AfterMarketQuestion = cachedAfterMarketOptions;
            }
            else
                this.busyC = this.kbbServiceService.GetQuestionsfromAPI(this.params, LinkEnum.GetAfterMarket).subscribe(
                    (result: Questions[]) => {
                        this.processData(this.questions = result)
                        this.persistAfterMarketOptionsData();
                        this.kbbServiceService.isAfterMarketEnable.next(true);
                    },
                    (error: Response | any) => this.errorHandler.handleError(error));
        }
    }

    persistAfterMarketOptionsData() {
        this.kbbServiceService.setData(this.AfterMarketQuestion, LinkEnum.GetAfterMarket);

    }
    persistAfterCommentsData() {
        this.kbbServiceService.setData(this.aftermarketcomments, LinkEnum.GetAftermarketComment);
    }
    persistsonicAfterMarketOptionsData() {
        this.kbbServiceService.setData(this.afterMarketFactoryOptions, LinkEnum.GetAftermarketoption);

    }
    onAfterMarketSelectioonChange(selectedIndex, selectedValue) {
        if (selectedValue != "None") {
            if (this.afterMarketFactoryOptions.filter(x => x.Description == "None").length > 0) {
                this.afterMarketFactoryOptions = this.afterMarketFactoryOptions.slice(1, 4);
                this.persistsonicAfterMarketOptionsData();
            }
        }

        //if (selectedIndex == 0 && selectedValue) {
        //    this.afterMarketFactoryOptions.filter(x => x.Description != "None").forEach(x => {
        //        x.Disabled = false;
        //        x.Is_AfterMarketOption_Select = false;
        //    })
        //}
        //else {
        //    this.afterMarketFactoryOptions.filter(x => x.Description == "None").forEach(x => {
        //        x.Disabled = false;
        //        x.Is_AfterMarketOption_Select = false;

        //    });

        //}


        //check if any item is checked. If so hide the error label
        //this.afterMarketFactoryOptions.forEach(x => {
        //    if (x.Is_AfterMarketOption_Select)
        //        this.errorLabel = '';
        //});

        //// if there is a error msg disable the save button in edit mode
        //if (this.errorLabel != '' && this.showSaveCloseButtons) {
        //    this.disableSavebtn = true;
        //}
        //else {
        //    this.disableSavebtn = false;
        //}
    }


    Saved(data) {
        //Data saved sucessfully.
        //Add after save stuffs here.
        if (this.editMode == true) {
            if (this.reqResubmit) {
                this.kbbServiceService.ResubmitSACRecord(this.params, LinkEnum.ResubmitSACRecord).subscribe(
                    (result: SIMSResponseData) => result,
                    (error: Response | any) => this.errorHandler.handleError(error));
            }
            else if (this.SACStatusID == 403 && this.isCCAVehicle == true) {
                this.setCookie("IsResubmit-" + this.params.VehicleId + "-" +
                    this.params.StoreId + "-" +
                    this.params.InventoryId, 1, 1);
            }
        }
    }
    collapseAll(): any {
        let closeTextToggle = this.elRef.nativeElement.querySelector('.closeAll');
        if (closeTextToggle.innerText == 'CLOSE ALL') {
            for (var i = 0; i < this.AfterMarketQuestion.length; i++) {
                let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont' + i);
                let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon' + i);
                if (contentDiv != undefined) {
                    contentDiv.classList.add('collapse');
                    closeTextToggle.innerText = 'OPEN ALL';
                    icon.classList.add('fa-plus-square');
                    icon.classList.remove('fa-minus-square');
                }
            }
            let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont255');
            let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon255');
            contentDiv.classList.add('collapse');
            closeTextToggle.innerText = 'OPEN ALL';
            icon.classList.add('fa-plus-square');
            icon.classList.remove('fa-minus-square');
        } else {
            for (var i = 0; i < this.AfterMarketQuestion.length; i++) {
                let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont' + i);
                let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon' + i);
                if (contentDiv != undefined) {
                    contentDiv.classList.remove('collapse');
                    closeTextToggle.innerText = 'CLOSE ALL';
                    icon.classList.add('fa-minus-square');
                    icon.classList.remove('fa-plus-square');
                }
            }
            let contentDiv = this.elRef.nativeElement.querySelector('#AfterMarketCont255');
            let icon = this.elRef.nativeElement.querySelector('#AfterMarketIcon255');
            contentDiv.classList.remove('collapse');
            closeTextToggle.innerText = 'CLOSE ALL';
            icon.classList.add('fa-minus-square');
            icon.classList.remove('fa-plus-square');
        }

    }

    trackAfterMarketBlock(index, afterMarketBlock) {
        return afterMarketBlock ? afterMarketBlock.categoryId : undefined;
    }
    trackAfterMarketQuestion(index, afterMarketQuestion) {
        return afterMarketQuestion ? afterMarketQuestion.questionId : undefined;
    }
}
