export class AfterMarketComments {
    InvtrId: number;
    StoreId: number;
    VehicleId: number;
    UserName: string;
    Comments: string;

}

