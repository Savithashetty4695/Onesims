export class AfterFactoryOptionsKBB {
    AfterMarketOptionId: number;
    Description: string;
    Is_AfterMarketOption_Select: boolean;
    OptionKindId: string;
    Disabled: boolean;
}


