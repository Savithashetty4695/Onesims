export class AfterVehicleFactoryOptionsKBB {
    InvtrId: number;
    StoreId: number;
    VehicleId: number;
    UserName: string;
    AlternateFactoryOptionsLst: AfterFactoryOptionsKBB[];
}

export class AfterFactoryOptionsKBB {
    AfterMarketOptionId: number;
    Description: string;
    Is_AfterMarketOption_Select: boolean;
    OptionKindId: string;
}

