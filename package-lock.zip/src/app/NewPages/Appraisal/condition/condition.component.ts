import { Response, Headers } from '@angular/http';
import { Component, OnInit, ViewEncapsulation, ElementRef, Input, HostBinding, ViewChild, AfterViewInit } from '@angular/core';
import { KBBServiceService } from '../Services/kbbservice.service';
import { HttpServiceService } from '../Services/http-service.service';
import { VehicleParams } from '../Model/vehicle-params.model';
import { ErrorHandler } from '../common/error-handler';
import { LinkEnum, DecodeType } from '../model/link-enum.enum';
import { AnswerModel, Answer } from '../model/answer-model';
import { Vehicle } from '../Model/vehicle';
import { SIMSResponseData } from '../model/simsresponse-data';
import { Subscription } from 'rxjs';
import { MatTabsModule } from '@angular/material/tabs';
import { UploadFileComponent } from '../upload-file/upload-file.component';
import { PhotoUploadParams } from '../model/photo-upload-params';
import { ReconQuestionModel } from '../Model/recon-question-model';
//Added for carousel
import { NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
//Added for carousel

//inject service
//import ImageCompressor from 'image-compressor.js';

declare var $: any;
declare var ImageCompressor: any;
declare var Close: any;

@Component({
    selector: 'app-condition',
    templateUrl: './condition.component.html',
    styleUrls: ['./condition.component.css'],
    encapsulation: ViewEncapsulation.None,

})
export class ConditionComponent implements OnInit, AfterViewInit {
    disabled: boolean = true;
    answer: Answer[];
    answerModel = AnswerModel;
    response: Answer;
    selectedOption: string;
    params: VehicleParams;
    errorHandler: ErrorHandler;

    vinVehicleDetails: Vehicle;
    @Input() kbbEditObject: string;
    @Input() showSaveCloseButtons: boolean;
    editParams: any;
    busyA: Subscription;
    wearAndTear: string[];
    mechanical: string[];
    serious: string[];
    hasMarketingPhoto: boolean = false;
    AppraisalStatus: number[] = [101, 102];
    MarketingStatus: number[] = [201, 202, 203, 204, 205, 214, 215, 216, 217, 218, 219, 221, 232, 236, 238];
    SaleStatus: number[] = [301, 302, 303, 305];
    //Added for Latest photo
    DsLatestThumbnail: string;
    DsLatestWheelThumbnail: string;
    DsLatestAdditionalThumbnail: string;

    FrontLatestThumbnail: string
    FrontLatestAdditionalThumbnail: string;

    PsLatestThumbnail: string;
    PsLatestWheelThumbnail: string;
    PsLatestAdditionalThumbnail: string;

    RearLatestThumbnail: string;
    RearLatestAdditionalThumbnail: string;

    VinLatestThumbnail: string;
    DashboardLatestWheelThumbnail: string;
    OdometerLatestAdditionalThumbnail: string;
    FrontSeatLatestThumbnail: string;
    BackSeatLatestThumbnail: string;
    InteriorLatestAdditionalThumbnail: string;

    vehicleType: string;

    //Added for Latest photo

    // sum up the recon		
    ConditionQuestion: ReconQuestionModel;
    TotalRecon: string;
    DefaultInspection: string;
    TotalEstimate: string;
    IsSightUnseen: boolean = false;
    SourceType: number;
    SACStatusID: number;
    reqResubmit: boolean = false;
    // for below source types, photo and recon amt is not mandatory
    ListSourceType: number[] = [20, 40, 110,120];
    // for validate the user input /photupload
    VehicleSections: string;
    Modalheader: string;
    @ViewChild('ValidateInput') ValidateInput: any;
    @ViewChild('resubmitpopup') resubmitpopup: any;
    KbbDecodeVehicleSource: any;
    constructor(public kbbServiceService: KBBServiceService, public httpService: HttpServiceService, private elRef: ElementRef, private modalService: NgbModal) {
        this.params = new VehicleParams();
        this.answer = new Array<Answer>();
        this.answerModel.prototype = new AnswerModel();
        this.answerModel.prototype.Answers = this.answer;
        this.errorHandler = new ErrorHandler();
        this.wearAndTear = new Array<string>();
        this.mechanical = new Array<string>();
        this.serious = new Array<string>();
        this.wearAndTear = [];
        this.mechanical = [];
        this.serious = [];
        this.ConditionQuestion = new ReconQuestionModel();

        kbbServiceService.DsLatestThumbnail.subscribe((value) => { this.DsLatestThumbnail = value; });
        kbbServiceService.DsLatestWheelThumbnail.subscribe((value) => { this.DsLatestWheelThumbnail = value; });
        kbbServiceService.DsLatestAdditionalThumbnail.subscribe((value) => { this.DsLatestAdditionalThumbnail = value; });

        kbbServiceService.FrontLatestThumbnail.subscribe((value) => { this.FrontLatestThumbnail = value; });
        kbbServiceService.FrontLatestAdditionalThumbnail.subscribe((value) => { this.FrontLatestAdditionalThumbnail = value; });

        kbbServiceService.PsLatestThumbnail.subscribe((value) => { this.PsLatestThumbnail = value; });
        kbbServiceService.PsLatestWheelThumbnail.subscribe((value) => { this.PsLatestWheelThumbnail = value; });
        kbbServiceService.PsLatestAdditionalThumbnail.subscribe((value) => { this.PsLatestAdditionalThumbnail = value; });

        kbbServiceService.RearLatestThumbnail.subscribe((value) => { this.RearLatestThumbnail = value; });
        kbbServiceService.RearLatestAdditionalThumbnail.subscribe((value) => { this.RearLatestAdditionalThumbnail = value; });

        kbbServiceService.VinLatestThumbnail.subscribe((value) => { this.VinLatestThumbnail = value; });
        kbbServiceService.DashboardLatestWheelThumbnail.subscribe((value) => { this.DashboardLatestWheelThumbnail = value; });
        kbbServiceService.OdometerLatestAdditionalThumbnail.subscribe((value) => { this.OdometerLatestAdditionalThumbnail = value; });
        kbbServiceService.FrontSeatLatestThumbnail.subscribe((value) => { this.FrontSeatLatestThumbnail = value; });
        kbbServiceService.BackSeatLatestThumbnail.subscribe((value) => { this.BackSeatLatestThumbnail = value; });
        kbbServiceService.InteriorLatestAdditionalThumbnail.subscribe((value) => { this.InteriorLatestAdditionalThumbnail = value; });
        this.KbbDecodeVehicleSource = HttpServiceService.KbbDecodeVehicleSource;
    }

    errorMessage: string;
    toggle = [];
    show = 'Side';
    editMode: boolean = false;

    // to find the view mode
    showWireframe: boolean = true;

    //Open-Close one card
    bScreen: boolean;
    sScreen: boolean;

    SaveAndNext() {

        let isContinue: boolean = false;
        if (!this.IsPhotsAndReconAmtmandatory()) {
            isContinue = true;
        }
        else {
            if (this.validateReconAmount()) {
                if (this.validatePhotos()) {
                    isContinue = true;
                }
                else { isContinue = false; }
            }
            else
                isContinue = false;
        }
        if (isContinue) {
            this.SaveDataToDB();
            return true;
        }
        else {
            return false;
        }
    }

    SaveDataToDB() {
        var vm = this;
        for (var section of this.ConditionQuestion.Sections) {
            for (var category of section.Categories) {
                for (var subCat of category.SubCategories) {
                    for (var item of subCat.questions) {
                        let needToAdd: boolean = false;
                        if (item.questionType == "Boolean") {
                            if (item.value)
                                needToAdd = true
                        }
                        else {
                            if (item.value != null && item.value != item.minimumValue.toString()
                                && item.value != "0" && item.value != undefined && item.value != "")
                                needToAdd = true;
                        }
                        if (needToAdd) {
                            vm.response = new Answer();
                            vm.response.label = item.label;
                            vm.response.questionId = item.questionId;
                            vm.response.questionType = item.questionType;
                            //vm.response.tags = item.tags;
                            this.response.value = item.questionType.toString().toLowerCase() == 'boolean' ?
                                item.value ? 'Yes' : 'false'
                                : item.value;
                            vm.response.value = item.value;
                            vm.response.comment = item.comment;
                            vm.response.vehicleConditionCategory = item.vehicleConditionCategory;
                            vm.response.vehicleConditionCategoryName = item.vehicleConditionCategoryName;
                            vm.response.vehicleSectionId = section.SectionId;
                            vm.response.vehicleSectionName = item.vehicleSectionName;
                            vm.response.vehicleConditionCategoryName = item.vehicleConditionCategoryName;
                            vm.response.vehicleConditionCategory = category.Id;
                            vm.response.maximumValue = item.maximumValue;

                            if (item.ReconAmt != null) {
                                vm.response.ReconAmt = item.ReconAmt;
                            }
                            else {
                                vm.response.ReconAmt = 0;
                            }

                            // vm.response.ReconAmt = item.ReconAmt;
                            vm.answer.push(vm.response);
                        }

                    }
                }
            }
        }
        this.persistReconQuestionData();
        this.answerModel.prototype.Answers = this.answer;
        this.answerModel.prototype.InvtrID = this.params.InventoryId;
        this.answerModel.prototype.StoreID = this.params.StoreId
        this.answerModel.prototype.VehicleID = this.params.VehicleId;
        this.answerModel.prototype.UserName = this.params.UserName;
        this.kbbServiceService.SaveResponse(this.answerModel.prototype, LinkEnum.SaveRecon).subscribe(
            (result: SIMSResponseData) => this.Saved(result),
            (error: Response | any) => this.errorHandler.handleError(error));

    }

    //On edit save Fuction
    EditSave() {
        let isContinue: boolean = false;
        if (!this.IsPhotsAndReconAmtmandatory()) {
            isContinue = true;
        }
        else {
            if (this.validateReconAmount()) {
                if (this.validatePhotos()) {
                    isContinue = true;
                }
                else { isContinue = false; }
            }
            else
                isContinue = false;
        }

        if (isContinue) {

            // in edit mode check sacstatus            
            let options: NgbModalOptions = { backdrop: 'static', keyboard: false, windowClass: 'custom-modal' }
            if (this.editMode = true && (this.SACStatusID == 403 || this.SACStatusID == 407)) {
                this.modalService.open(this.resubmitpopup, options);
                return false;
            }
            else {
                this.SaveDataToDB();
                return true;
            }

        }
        else {
            return false;
        }

    }

    //Resubmit chagnes
    ResubmitYes() {
        this.reqResubmit = true;
        this.SaveDataToDB();

        return true;
    }


    IsPhotsAndReconAmtmandatory(): boolean {
        if (this.IsSightUnseen) {
            return false;
        }
        else if (this.ListSourceType.includes(Number(this.SourceType)) || this.params.Decode_Type == DecodeType.KBB_Book_Decode) {
            return false;
        }
        else
            return true;
    }

    validatePhotos(): boolean {

        let arePhotosuploaded: boolean = true;
        this.VehicleSections = '';
        this.Modalheader = "There are one or more photos missing in one or more of the sections.";
        if (this.DsLatestThumbnail == undefined && this.DsLatestThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Driver side, ";
        }
        if (this.DsLatestWheelThumbnail == undefined && this.DsLatestWheelThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Driver side wheel, ";
        }
        if (this.FrontLatestThumbnail == undefined && this.FrontLatestThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Front, ";
        }
        if (this.PsLatestThumbnail == undefined && this.PsLatestThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Passenger side, ";
        }
        if (this.PsLatestWheelThumbnail == undefined && this.PsLatestWheelThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Passenger side wheel, ";
        }
        if (this.RearLatestThumbnail == undefined && this.RearLatestThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Rear, ";
        }
        if (this.VinLatestThumbnail == undefined && this.VinLatestThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "VIN, ";
        }
        if (this.DashboardLatestWheelThumbnail == undefined && this.DashboardLatestWheelThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Dashboard, ";
        }
        if (this.OdometerLatestAdditionalThumbnail == undefined && this.OdometerLatestAdditionalThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Odometer, ";
        }
        if (this.FrontSeatLatestThumbnail == undefined && this.FrontSeatLatestThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Front seat, ";
        }
        if (this.BackSeatLatestThumbnail == undefined && this.BackSeatLatestThumbnail == null) {
            arePhotosuploaded = false;
            this.VehicleSections += "Back seat,";
        }
        if (!arePhotosuploaded) {
            let lastCommaIndex = this.VehicleSections.lastIndexOf(",");
            this.VehicleSections = this.VehicleSections.slice(0, lastCommaIndex);
            this.modalService.open(this.ValidateInput, { windowClass: 'customModalCondition' });
        }

        return arePhotosuploaded;

    }

    validateReconAmount(): boolean {

        let areAmountEntered: boolean = true;
        this.VehicleSections = '';
        this.Modalheader = "Recon amount is missing in below sections!";
        for (var section of this.ConditionQuestion.Sections) {
            let AmtEntered: boolean = true;
            for (var category of section.Categories) {
                for (var subCat of category.SubCategories) {
                    for (var item of subCat.questions) {
                        if (item.value != null && item.value != "" && item.value != "0") {
                            let reconAmtField = document.getElementById('txtReconAmt_' + item.questionId);
                            if (item.ReconAmt == null || item.ReconAmt == 0) {
                                if (reconAmtField != null && !reconAmtField.classList.contains('invalidAmt'))
                                    reconAmtField.classList.add('invalidAmt');
                                areAmountEntered = false;
                                AmtEntered = false;
                            }
                            else {
                                if (reconAmtField != null && reconAmtField.classList.contains('invalidAmt'))
                                    reconAmtField.classList.remove('invalidAmt');
                            }
                        }
                    }
                }
            }

            if (!AmtEntered) {
                switch (section.SectionName) {
                    case 'DriverSide':
                        this.VehicleSections += ' Driver Side,';
                        break;
                    case 'Front':
                        this.VehicleSections += ' Front,';
                        break;
                    case 'PassengerSide':
                        this.VehicleSections += ' Passenger Side,';
                        break;
                    case 'Rear':
                        this.VehicleSections += ' Rear,';
                        break;
                    case 'Interior':
                        this.VehicleSections += ' Interior,';
                        break;
                    case 'Mechanical':
                        this.VehicleSections += ' Mechanical,';
                        break;
                }
            }
            // reset flag
            AmtEntered = true;

        } // end of loop

        if (!areAmountEntered) {
            let lastCommaIndex = this.VehicleSections.lastIndexOf(",");
            this.VehicleSections = this.VehicleSections.slice(0, lastCommaIndex);
            this.modalService.open(this.ValidateInput, { windowClass: 'customModalCondition' });
        }

        return areAmountEntered;

    }

    ngOnInit() {

        // not show wireframe if it is not Ipad and webclient
        this.showWireframe = window.innerWidth < 576 ? false : true;

        this.bScreen = window.innerWidth > 992 ? true : false;
        this.sScreen = window.innerWidth <= 768 ? true : false;
        this.vehicleType = this.kbbServiceService.vehicleType;

        this.params = this.kbbServiceService.getVehicleParameters();

        if (this.kbbEditObject != null) {
            this.params = JSON.parse(this.kbbEditObject.replace(/'/g, '"'));
            this.kbbServiceService.setVehicleParameters(this.params);
            let StatusId: number = this.params.StatusId;
            this.hasMarketingPhoto = this.MarketingStatus.lastIndexOf(StatusId) > -1 ? true : false;
            //this.isDDCAppraisal = this.KbbDecodeVehicleSource.includes(Number(this.params.SourceType))? true : false;
            this.IsSightUnseen = this.params.IsSightUnseen;
            this.SourceType = this.params.SourceType;
            this.editMode = true;
            this.SACStatusID = parseInt(this.params.SACStatusID.toString());
        }

        let cachedVinVehicleDetails = this.kbbServiceService.GetVehicleDetailsFromCache(this.params);
        if (cachedVinVehicleDetails != undefined) {
            this.vinVehicleDetails = cachedVinVehicleDetails;
            let StatusId: number = this.vinVehicleDetails.StatusID;
            this.hasMarketingPhoto = this.MarketingStatus.lastIndexOf(StatusId) > -1 ? true : false;
            //this.isDDCAppraisal = this.KbbDecodeVehicleSource.includes(Number(this.params.SourceType)) ? true : false;
            this.IsSightUnseen = this.vinVehicleDetails.SightUnseen;
            this.SourceType = parseInt(this.vinVehicleDetails.SourceType);
            // this.SACStatusID = parseInt(this.params.SACStatusID.toString());   
        }

        let cachedReconQuestionsData = this.kbbServiceService.GetReconQuestionFromCache();

        if (cachedReconQuestionsData != null && cachedReconQuestionsData.Sections.length > 0) {
            this.ConditionQuestion = cachedReconQuestionsData;
            // set total recon
            this.sumReconAmounts();
        }
        else {
            this.busyA = this.kbbServiceService.GetQuestionsfromAPI(this.params, LinkEnum.GetRecon).subscribe(
                (result: any) => {
                    this.processData(result);
                    this.kbbServiceService.isConditionEnable.next(true);
                },
                (error: Response | any) => this.errorHandler.handleError(error));
        }

    }

    processData(data: any) {
        this.ConditionQuestion = data;

        // here revert recon amt with formated
        for (var section of this.ConditionQuestion.Sections) {
            for (var category of section.Categories) {
                for (var subCat of category.SubCategories) {
                    for (var item of subCat.questions) {
                        //var num = item.ReconAmt.toString().replace(/,/g, '');
                        //let strAmt: string = this.addCommas(num);
                        //item.ReconAmt = strAmt;
                        if (item.ReconAmt.toString() == "") {

                            item.ReconAmt = null;
                        }
                    }
                }
            }
        }

        // set total recon
        this.sumReconAmounts();

        this.persistReconQuestionData();
    }

    persistReconQuestionData() {
        this.kbbServiceService.setData(this.ConditionQuestion, LinkEnum.GetRecon);
    }

    setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    Saved(data) {
        //Data saved sucessfully.
        //Add after save stuffs here.
        if (this.showSaveCloseButtons) {
            if (this.reqResubmit) {
                this.kbbServiceService.ResubmitSACRecord(this.params, LinkEnum.ResubmitSACRecord).subscribe(
                    (result: SIMSResponseData) => result,
                    (error: Response | any) => this.errorHandler.handleError(error));
                this.reqResubmit = false;
            }
            else if (this.editMode = true && this.SACStatusID == 403) {
                this.setCookie("IsResubmit-" + this.kbbServiceService.vehicleParams.VehicleId + "-" +
                    this.kbbServiceService.vehicleParams.StoreId + "-" +
                    this.kbbServiceService.vehicleParams.InventoryId, 1, 1);
            }
            Close(0);
        }
    }

    //New Changes Starts
    //isMultiple: boolean = false;
    fileExtension: any;
    QuestionsOnSection: any;
    @ViewChild('fileUpload') fileUpload: any;
    isMultiple: boolean = false;
    photoGuide: string;
    busyB: Subscription;
    uploadImage(flag: string) {
        this.photoGuide = flag;
        document.getElementById('upldImage').click();
    }
    //isDDCAppraisal: boolean;

    fileChange(event) {
        this.kbbServiceService.isConditionEnable.next(true);
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            var totalFileLength = 0;
            let isLengthExceeded: boolean = false;
            for (var i = 0; i <= fileList.length - 1; i++) {
                var fsize = fileList.item(i).size;
                var maxLength = Math.round((fsize / 1024));
                totalFileLength = totalFileLength + maxLength;
                if (maxLength > 102400 || totalFileLength > 102400) {
                    isLengthExceeded = true;
                    break;
                }
            }
            if (isLengthExceeded) {
                document.getElementById('errMsgPhotoUpload').innerHTML = 'Uploaded image size exceeds 100MB';
                this.fileUpload.nativeElement.value = "";
                return false;
            }
            else {
                document.getElementById('errMsgPhotoUpload').innerHTML = "";
            }
            var count = 0;
            var allowedExtensions = ["jpg", "jpeg", "png", "PNG", "JPG", "JPEG", "JFIF", "jfif", "BMP", "SVG", "svg", "bmp"];
            for (let i = 0; i < fileList.length; i++) {
                this.fileExtension = fileList[i].name.split('.').pop();

                if (!this.isInArray(allowedExtensions, this.fileExtension)) {
                    count++;
                }
                if (count > 0) {
                    document.getElementById('errMsgPhotoUpload').innerHTML = "Only photos are allowed!!"
                    this.fileUpload.nativeElement.value = "";
                    this.kbbServiceService.isConditionEnable.next(true);
                    return false;
                }
                else {
                    document.getElementById('errMsgPhotoUpload').innerHTML = "";
                }
            }

            debugger;
            var parentObject = this;
            if (fileList[0].size >= 600000) {

                var imageCompressor = new ImageCompressor();
                var compressorSettings = {
                    toWidth: 650,
                    mimeType: 'image/jpeg',
                    mode: 'strict',
                    quality: 0.6,
                    speed: 'low',
                    condComp: this
                };
                var reader = new FileReader();
                reader.onload = function () {
                    var dataURL = reader.result;
                    imageCompressor.run(dataURL, compressorSettings, parentObject.saveImage);
                };
                reader.readAsDataURL(fileList[0]);
            }
            else {
                var reader = new FileReader();
                reader.onload = function () {
                    var dataURL = reader.result;
                    let VehicleParam: PhotoUploadParams = {
                        VehicleID: parentObject.params.VehicleId,
                        StoreID: parentObject.params.StoreId,
                        InvtrID: parentObject.params.InventoryId,
                        PhotoCat: 10,
                        UserName: parentObject.params.UserName,
                        PhotoGuide: parentObject.photoGuide,
                        Base64StringImage: dataURL.toString()
                    };
                    parentObject.kbbServiceService.SaveAppraisalPhotos(VehicleParam).subscribe(
                        (result: SIMSResponseData) => {
                            //parentObject.Saved(result);
                            parentObject.fileUpload.nativeElement.value = "";
                            parentObject.kbbServiceService.PhotoUploadCompleted();
                            // this.kbbServiceService.isConditionEnable.next(true);
                        },
                        (error: Response | any) => parentObject.errorHandler.handleError(error));
                };
                reader.readAsDataURL(fileList[0]);

            }
        }
    }
    parentObject: any;
    saveImage(imgFile: string) {
        debugger;

        let VehicleParam: PhotoUploadParams = {
            VehicleID: this.parentObject.params.VehicleId,
            StoreID: this.parentObject.params.StoreId,
            InvtrID: this.parentObject.params.InventoryId,
            PhotoCat: 10,
            UserName: this.parentObject.params.UserName,
            PhotoGuide: this.parentObject.photoGuide,
            Base64StringImage: imgFile
        };
        this.parentObject.kbbServiceService.SaveAppraisalPhotos(VehicleParam).subscribe(
            (result: SIMSResponseData) => {
                //this.parentObject.Saved(result);
                this.parentObject.fileUpload.nativeElement.value = "";
                this.parentObject.kbbServiceService.PhotoUploadCompleted();
                // this.kbbServiceService.isConditionEnable.next(true);
            },
            (error: Response | any) => this.parentObject.errorHandler.handleError(error));
    }

    isInArray(array, word) {
        return array.indexOf(word.toLowerCase()) > -1;
    }

    modelheader;
    modelbody;
    modelSection;
    modelCategoryId;
    modellist;
    modelreferance: NgbModalRef;
    catId;
    // open popup
    areaClicked(event, sectionName, Id, categoryName: any) {

        //if (!this.isMobile.any()) {
        //    this.isPopupTriggered = true;
        //} else {
        //    // if it is a mobile then create canvas on click 
        //    if (this.hdc != null) {
        //        const can: any = document.getElementById('canvas' + sectionName);
        //        this.hdc.clearRect(0, 0, can.width, can.height);
        //    }
        //    this.createCanvas(sectionName);
        //    this.isPopupTriggered = true;
        //}
        this.catId = Id;
        let section: string;
        switch (sectionName) {
            case 'DriverSide':
                section = 'Driver Side';
                break;
            case 'Front':
                section = 'Front';
                break;
            case 'PassengerSide':
                section = 'Passenger Side';
                break;
            case 'Rear':
                section = 'Rear';
                break;
            case 'Interior':
                if (Id == 3)
                    Id = 1;
                else if (Id == 4)
                    Id = 2
                this.catId = Id;
                section = 'Interior';
                break;
        }

        this.modelheader = section + ' - ' + event.target.title;
        let item = this.ConditionQuestion.Sections.find(i => i.SectionName === sectionName);
        this.modelSection = sectionName;
        this.modelCategoryId = Id;
        this.modellist = JSON.parse(JSON.stringify(item.Categories.find(cat => cat.Id === Id)));
        this.modelbody = item.Categories.find(cat => cat.Id === Id);



        let options: NgbModalOptions = { backdrop: 'static', keyboard: false, windowClass: 'modal-content-sm' }
        this.modelreferance = this.modalService.open(categoryName, options);

    }

    SaveModal(modelbody: any) {
        let isAmtvalid: boolean = true;
        for (var subCat of modelbody.SubCategories) {
            for (var item of subCat.questions) {
                if (item.value != null && item.value != "" && item.value != "0") {
                    let reconAmtField = document.getElementById('txtReconAmt_' + item.questionId);
                    if (item.ReconAmt == null || item.ReconAmt == "" || item.ReconAmt == "0") {
                        isAmtvalid = false;

                        if (reconAmtField != null && !reconAmtField.classList.contains('invalidAmt'))
                            reconAmtField.classList.add('invalidAmt');
                    }
                    else {
                        if (reconAmtField != null && reconAmtField.classList.contains('invalidAmt'))
                            reconAmtField.classList.remove('invalidAmt');
                    }
                }
            }
        }
        if (!this.IsPhotsAndReconAmtmandatory()) {
            this.modelreferance.close();
            // sum the recon amount
            this.sumReconAmounts();
        }
        else if (isAmtvalid) {
            this.modelreferance.close();
            // sum the recon amount
            this.sumReconAmounts();
        }


    }

    CloseModal(modelbody: any) {
        let sec = this.ConditionQuestion.Sections.find(i => i.SectionName === this.modelSection);
        let cat = sec.Categories.find(cat => cat.Id === this.catId);
        let secIndex = this.ConditionQuestion.Sections.indexOf(sec);
        let catIndex = this.ConditionQuestion.Sections[secIndex].Categories.indexOf(cat);
        // revert into initial status.
        this.ConditionQuestion.Sections[secIndex].Categories[catIndex] = this.modellist;

        // sum of the recon
        this.sumReconAmounts();

        this.modelreferance.close();
    }

    SetData(questionId, sender, limit, event, sectionName, categoryId) {
        let clickedButton: string = event.currentTarget.id;//"md-button-toggle-73"
        let id: number = parseInt(clickedButton.substring(clickedButton.lastIndexOf('-') + 1, clickedButton.length));

        let section = this.ConditionQuestion.Sections.find(i => i.SectionName === sectionName);
        let category = section.Categories.find(cat => cat.Id === categoryId);

        for (var subcat of category.SubCategories) {
            for (var item of subcat.questions) {
                if (item.questionId == questionId) {
                    let val: number = (item.value == null || item.value == "") ? 0 : parseInt(item.value);
                    if (sender == 'plus' && val < limit) {
                        val++;
                    }
                    else if (sender == 'minus' && val > limit) {
                        val--;
                    }
                    item.value = val.toString();
                    break;
                }
            }
        }


    }

    // for Ipad View
    HideShowCategory(id, SectionName) {
        let item = this.ConditionQuestion.Sections.find(i => i.SectionName === SectionName);

        for (var category of item.Categories) {
            if (category.Id == id) {
                let contentDiv = this.elRef.nativeElement.querySelector('#CatCont' + id);
                let icon = this.elRef.nativeElement.querySelector('#CatIcon' + id);
                this.ShowHide(icon, contentDiv);
            }
            else {

                let contentDiv = this.elRef.nativeElement.querySelector('#CatCont' + category.Id);
                let icon = this.elRef.nativeElement.querySelector('#CatIcon' + category.Id);
                if (contentDiv != undefined) {
                    contentDiv.classList.add('collapse');
                    icon.classList.add('fa-plus-square');
                    icon.classList.remove('fa-minus-square');
                }
            }
        }
    }

    ShowHide(icon: any, contentDiv: any): void {
        if (contentDiv.classList.contains('collapse')) {
            contentDiv.classList.remove('collapse');
            icon.classList.add('fa-minus-square');
            icon.classList.remove('fa-plus-square');

        } else {
            contentDiv.classList.add('collapse');
            icon.classList.add('fa-plus-square');
            icon.classList.remove('fa-minus-square');

        }
    }

    //image Resize
    currentSection: string = "WireFrame";
    imageResize(sectionName) {
        //this.bScreen = window.innerWidth > 992 ? true : false;
        //this.sScreen = window.innerWidth <= 768 ? true : false;
        let image: HTMLElement = document.getElementById('img' + sectionName);
        if (image != null) {

            //let imageWidth: number = 1105;
            //let imageHeight: number = 455;
            let imageWidth: number = this.ConditionQuestion.Width;
            let imageHeight: number = this.ConditionQuestion.Height;

            let changedWidth: number = image.clientWidth;
            let changedHeight: number = image.clientHeight;
            var changedWidthPercentage = image.clientWidth / 100;
            var changedHeightPercentage = image.clientHeight / 100;

            for (var section of this.ConditionQuestion.Sections) {
                if (section.SectionName != "Mechanical") {
                    var counter: number = 0;
                    for (var category of section.Categories) {
                        let area: HTMLElement = document.getElementById('area_' + section.SectionName + '_' + counter);
                        if (area.getAttribute("originalcoordinates") == null)
                            area.setAttribute("originalcoordinates", category.MappingCoordinates.toString());
                        console.log(section.SectionName + ':' + category.CategoryName + ':' + area.getAttribute("originalcoordinates"));
                        var coords = area.getAttribute("originalcoordinates").split(',');
                        //var coords = category.MappingCoordinates.split(',');
                        var coordsPercent = new Array(coords.length);
                        for (var i = 0; i < coordsPercent.length; ++i) {
                            if (i % 2 === 0) {
                                let t: number = parseInt(coords[i]);
                                let t1: number = (t / imageWidth) * 100;
                                let t2: number = t1 * changedWidthPercentage;
                                let x = parseInt(t2.toString(), 10);
                                coordsPercent[i] = x.toString();

                                //let x = parseInt(coords[i], 10) * changedWidthPercentage;
                                //coordsPercent[i] = parseInt(x.toString(), 10);
                            }
                            else {
                                let t: number = parseInt(coords[i]);
                                let t1: number = (t / imageHeight) * 100;
                                let t2: number = t1 * changedHeightPercentage;
                                let y = parseInt(t2.toString(), 10);
                                coordsPercent[i] = y.toString();
                                //let y = (parseInt(coords[i], 10) * changedHeightPercentage) - 20;
                                //coordsPercent[i] = parseInt(y.toString(), 10);
                            }
                        }
                        category.MappingCoordinates = coordsPercent.toString();
                        counter++;
                    }
                }
            }
        }
    }

    onTabChange(event: any) {

        if (event.index <= 2) {
            let elemet = document.getElementById('errMsgPhotoUpload');
            if (elemet != null || elemet != undefined)
                document.getElementById('errMsgPhotoUpload').innerHTML = "";
            switch (event.index) {
                case 0: this.currentSection = "WireFrame";
                    break;
                case 1: this.currentSection = "Mechanical";
                    break;
            }

            // no need of below line
            //this.imageResize(this.currentSection);
            $(document).ready(function (e) {
                $('img[usemap]').rwdImageMaps();
            });


        }


        if (this.IsPhotsAndReconAmtmandatory) {
            // when switch tab happens need to add invalid css for reconamt fiels in perticular section
            for (var sec of this.ConditionQuestion.Sections) {
                for (var category of sec.Categories) {
                    for (var subCat of category.SubCategories) {
                        for (var item of subCat.questions) {
                            if (item.value != null && item.value != "") {
                                let reconAmtField = document.getElementById('txtReconAmt_' + item.questionId);
                                if (item.ReconAmt == null || item.ReconAmt == 0) {
                                    if (reconAmtField != null && !reconAmtField.classList.contains('invalidAmt'))
                                        reconAmtField.classList.add('invalidAmt');
                                }
                                else {
                                    if (reconAmtField != null && reconAmtField.classList.contains('invalidAmt'))
                                        reconAmtField.classList.remove('invalidAmt');
                                }
                            }

                        }
                    }
                }
            }
        }


    }



    collapseAll(sectionName): any {
        let closeTextToggle = this.elRef.nativeElement.querySelector('.closeAll');
        let item = this.ConditionQuestion.Sections.find(i => i.SectionName === sectionName);

        if (closeTextToggle.innerText == 'CLOSE ALL') {
            for (var category of item.Categories) {

                let contentDiv = this.elRef.nativeElement.querySelector('#CatCont' + category.Id);
                let icon = this.elRef.nativeElement.querySelector('#CatIcon' + category.Id);
                if (contentDiv != undefined) {
                    contentDiv.classList.add('collapse');
                    closeTextToggle.innerText = 'OPEN ALL';
                    icon.classList.add('fa-plus-square');
                    icon.classList.remove('fa-minus-square');
                }
            }
        } else {
            for (var category of item.Categories) {
                let contentDiv = this.elRef.nativeElement.querySelector('#CatCont' + category.Id);
                let icon = this.elRef.nativeElement.querySelector('#CatIcon' + category.Id);
                if (contentDiv != undefined) {
                    contentDiv.classList.remove('collapse');
                    closeTextToggle.innerText = 'CLOSE ALL';
                    icon.classList.add('fa-minus-square');
                    icon.classList.remove('fa-plus-square');
                }
            }
        }

    }

    // create canvas on hover effect
    hdc: any;
    createCanvas(sectionName) {
        // get the target image by section name    
        let img: HTMLElement = document.getElementById('img' + sectionName);

        let x, y, w, h;

        // get it's position and width+height
        x = img.offsetLeft;
        y = img.offsetTop;
        w = img.clientWidth;
        h = img.clientHeight;

        // move the canvas, so it's contained by the same parent as the image
        let imgParent = img.parentNode;

        // get the can by id by section name
        const can: any = document.getElementById('canvas' + sectionName);

        imgParent.appendChild(can);

        // place the canvas in front of the image    
        can.style.zIndex = 1;

        // position it over the image
        can.style.left = x + 'px';
        can.style.top = y + 'px';

        // make same size as the image
        can.setAttribute('width', w + 'px');
        can.setAttribute('height', h + 'px');

        // get it's context    
        this.hdc = can.getContext('2d');

        // set opacity of canvas
        this.hdc.globalAlpha = 0.2;

        // set the 'default' values for the colour/width of fill/stroke operations
        this.hdc.fillStyle = '#62A60A';
        this.hdc.strokeStyle = '#62A60A';
        this.hdc.lineWidth = 2;
    }

    // Area mousehover and area mouseout

    areaHover(wireFrame, sectionName, Id, element) {
        this.createCanvas(wireFrame);
        let coordStr = element.target.coords;
        let areaType = element.target.shape;
        this.drawShape(areaType, coordStr);

        //If interior section then both side seats should highlight
        if (sectionName == 'Interior') {
            let item, cat;
            switch (Id) {
                case 1:
                    item = this.ConditionQuestion.Sections.find(i => i.SectionName === sectionName);
                    cat = item.Categories.find(cat => cat.Id == 3);
                    areaType = cat.Shape;
                    coordStr = cat.MappingCoordinates;
                    break;
                case 2:
                    item = this.ConditionQuestion.Sections.find(i => i.SectionName === sectionName);
                    cat = item.Categories.find(cat => cat.Id == 4);
                    areaType = cat.Shape;
                    coordStr = cat.MappingCoordinates;
                    break;
                case 3:
                    item = this.ConditionQuestion.Sections.find(i => i.SectionName === sectionName);
                    cat = item.Categories.find(cat => cat.Id == 1);
                    areaType = cat.Shape;
                    coordStr = cat.MappingCoordinates;
                    break;
                case 4:
                    item = this.ConditionQuestion.Sections.find(i => i.SectionName === sectionName);
                    cat = item.Categories.find(cat => cat.Id == 2);
                    areaType = cat.Shape;
                    coordStr = cat.MappingCoordinates;
                    break;
            }
            this.drawShape(areaType, coordStr);

        }
    }

    // Area mousehover and area mouseout
    drawShape(areaType, coordStr) {
        //target.title        
        switch (areaType) {
            case 'polygon':
            case 'poly':
                this.drawPoly(coordStr, this.hdc);
                break;
            case 'rect':
                this.drawRect(coordStr, this.hdc);
                break;
            case 'circle':
                this.drawCircle(coordStr, this.hdc);
        }

    }


    // are mouse leave
    areaLeave(sectionName, element) {
        //if (!this.isMobile.any()) {
        if (this.hdc != null) {
            const can: any = document.getElementById('canvas' + sectionName);
            this.hdc.clearRect(0, 0, can.width, can.height);
        }
        //}
    }

    // takes a string that contains coords eg - "227,307,261,309, 339,354, 328,371, 240,331"
    // draws a line from each co-ord pair to the next - assumes starting point needs to be repeated as ending point.
    drawPoly(coOrdStr, ctx) {
        let mCoords = coOrdStr.split(',');
        let i, n;
        n = mCoords.length;

        ctx.beginPath();
        ctx.moveTo(mCoords[0], mCoords[1]);
        for (i = 2; i < n; i += 2) {
            ctx.lineTo(mCoords[i], mCoords[i + 1]);
        }
        ctx.lineTo(mCoords[0], mCoords[1]);
        ctx.fill();
        ctx.stroke();
    }

    drawRect(coOrdStr, ctx) {
        let mCoords = coOrdStr.split(',');
        let top, left, bot, right;
        left = mCoords[0];
        top = mCoords[1];
        right = mCoords[2];
        bot = mCoords[3];
        ctx.fillRect(left, top, right - left, bot - top);
        ctx.strokeRect(left, top, right - left, bot - top);

    }

    drawCircle(coOrdStr, ctx) {
        let mCoords = coOrdStr.split(',');
        let x, y, r;
        x = mCoords[0];
        y = mCoords[1];
        r = mCoords[2];
        ctx.beginPath();
        ctx.arc(x, y, r, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
    }

    ngAfterViewInit() {
        $(document).ready(function (e) {
            //  $('img[usemap]').rwdImageMaps();   
            //  $('.map').maphilight({
            //  fillColor: '62A60A', strokeColor: '62A60A', strokeWidth: 2, alwaysOn: true
            //  });
        });
    }

    // code for identify the requested device
    isMobile = {
        Android: function () {
            return navigator.userAgent.match(/Android/i);
        },
        BlackBerry: function () {
            return navigator.userAgent.match(/BlackBerry/i);
        },
        iOS: function () {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
        },
        Opera: function () {
            return navigator.userAgent.match(/Opera Mini/i);
        },
        Windows: function () {
            return navigator.userAgent.match(/IEMobile/i);
        },
        any: function () {
            return (this.Android() || this.BlackBerry() || this.iOS() || this.Opera() || this.Windows());
        }
    }

    // create canvas on loading intially to show all clickable areas
    // this method not using now, due to it not supporting in Ipad.
    createCanvasOnload(sectionName) {

        // get the target image by section name
        let img: HTMLElement = document.getElementById('img' + sectionName);
        if (img != null) {
            var x, y, w, h;
            // get it's position and width+height
            x = img.offsetLeft;
            y = img.offsetTop;
            w = img.clientWidth;
            h = img.clientHeight;

            // move the canvas, so it's contained by the same parent as the image
            let imgParent = img.parentNode;
            if (document.getElementById("_CANVAS" + sectionName) != null) {
                document.getElementById("_CANVAS" + sectionName).remove();
            }
            // get the can by id by section name
            const can: any = document.createElement("CANVAS");
            can.setAttribute('id', "_CANVAS" + sectionName);
            imgParent.appendChild(can);

            // place the canvas in front of the image    
            can.style.zIndex = 1;
            // position it over the image
            can.style.left = x + 'px';
            can.style.top = y + 'px';

            // make same size as the image
            can.setAttribute('width', w + 'px');
            can.setAttribute('height', h + 'px');

            // get it's context    
            let ctx = can.getContext('2d');

            // set opacity of canvas
            ctx.globalAlpha = 0.2;
            // set the 'default' values for the colour/width of fill/stroke operations
            ctx.fillStyle = '#62A60A';
            ctx.strokeStyle = '#62A60A';
            ctx.lineWidth = 5;

            // area tags count
            for (var section of this.ConditionQuestion.Sections) {
                // let item = this.ConditionQuestion.Sections.find(i => i.SectionName === section.SectionName);
                let counter: number = 0;
                for (let category of section.Categories) {
                    let area: HTMLElement = document.getElementById('area_' + sectionName + '_' + counter);
                    let coordStr = area.getAttribute('coords');
                    let areaType = area.getAttribute('shape');
                    switch (areaType) {
                        case 'polygon':
                        case 'poly':
                            this.drawPoly(coordStr, ctx);
                            break;

                        case 'rect':
                            this.drawRect(coordStr, ctx);
                            break;
                        case 'circle':
                            this.drawCircle(coordStr, ctx);

                    }
                    counter++;
                }
            }
        }
    }

    // close popup not using may need in phase 2
    ClosePopup(sectionName) {
        if (this.hdc != null) {
            const can: any = document.getElementById('canvas' + sectionName);
            this.hdc.clearRect(0, 0, can.width, can.height);
        }

    }

    // extimate recon
    ReconAmtToggleShow(Question) {
        if (Question.questionType == 'Boolean') {
            if (Question.value) {
                return true;
            }
            else {
                Question.ReconAmt = null;
                return false;
            }
        }
        else if (Question.questionType == 'Integer') {
            if (Question.value == null || Question.value == Question.minimumValue) {
                Question.ReconAmt = null;
                return false;
            }
            else {
                return true;
            }
        }
    }

    ReconAmtKeyPress(event: any, question) {
        let charCode;
        charCode = (event.which) ? event.which : event.keyCode;
        if ((charCode != 46 && charCode > 31
            && (charCode < 48 || charCode > 57)) || charCode == 13 || charCode == 46) {
            return false;
        }
        else {
            return true;
        }
    }

    ReconAmtKeyUp(event: any, Question) {
        event = event || window.event;
        var ReconValue = event.currentTarget.value;

        // in case user long press on same number need to reduce the length        
        if (ReconValue.replace(/,/g, '').length >= 6) {
            ReconValue = ReconValue.substring(0, 5);
        }
        //end here


        if (ReconValue != null && ReconValue != "" && ReconValue != 0) {
            var num = ReconValue.replace(/,/g, '');
            let strAmt: string = this.addCommas(+num);
            Question.ReconAmt = num;
            event.currentTarget.value = strAmt;
            event.target.classList.remove('invalidAmt'); // To Remove

        }
        else {
            if (this.IsPhotsAndReconAmtmandatory()) {
                if (!event.target.classList.contains('invalidAmt'))
                    event.target.classList.add('invalidAmt'); // add if not contains
            }
            event.currentTarget.value = '';
            Question.ReconAmt = '';
        }

        // reset recon 
        this.sumReconAmounts();

    }

    ReconAmtBlur(event: any, Question) {
        event = event || window.event;
        var ReconValue = event.currentTarget.value;

        if (ReconValue != null && ReconValue != "" && ReconValue != 0) {
            var num = ReconValue.replace(/,/g, '');
            let strAmt: string = this.addCommas(+num);
            Question.ReconAmt = num;
            event.currentTarget.value = strAmt;
            event.target.classList.remove('invalidAmt'); // To Remove
        }
        else {
            if (this.IsPhotsAndReconAmtmandatory()) {
                if (!event.target.classList.contains('invalidAmt'))
                    event.target.classList.add('invalidAmt'); // add if not contains
            }
            event.currentTarget.value = '';
            Question.ReconAmt = '';
        }
    }

    addCommas(n) {
        var rx = /(\d+)(\d{3})/;
        return String(n).replace(/^\d+/, function (w) {
            while (rx.test(w)) {
                w = w.replace(rx, '$1,$2');
            }
            return w;
        });
    }

    sumReconAmounts() {
        let ttlReconAmt: number = 0;
        for (var section of this.ConditionQuestion.Sections) {
            for (var category of section.Categories) {
                for (var subCat of category.SubCategories) {
                    for (var item of subCat.questions) {
                        if (item.value != null && (item.value || parseInt(item.value) > item.minimumValue)) {
                            if (item.ReconAmt != null && item.ReconAmt != 0) {
                                //var num = item.ReconAmt.replace(/,/g, '');
                                var num = item.ReconAmt;
                                let amt = +num;
                                ttlReconAmt = ttlReconAmt + amt;
                            }
                        }
                    }
                }
            }
        }

        this.TotalEstimate = this.addCommas(ttlReconAmt);
        this.TotalRecon = this.addCommas(ttlReconAmt + this.ConditionQuestion.DefaultInspectionAmount);
        this.DefaultInspection = this.addCommas(this.ConditionQuestion.DefaultInspectionAmount);

    }


}