export class VehicleParams {

    public VehicleId: number;
    public StoreId: number;
    public InventoryId: number;
    public TrimId: number;
    public ProspectId: string;
    public CurrStoreID: string;
    public UserName: string;
    public VIN: string;
    public Mileage: number;
    public InventoryType: number;
    public BookID: number;
    public StatusId: number;
    public SourceType: number;
    public IsKbbVehicle: boolean;
    public editMode: boolean;
    public isPendingAppraisal: boolean;
    public Kiosk_Req: string;
    public IsKbbFailure: boolean = false; 
    public IsSightUnseen: boolean = false;
    public chromeTrimID: string; // for chrome option
    public SACStatusID: number;
    public Decode_Type: number;
    public isStep5Exists: boolean = false;
    public isCCAVehicle: boolean = false;
    public ManagerNote: string;
}

