import {VehiclePhoto} from './vehicle-photo';
import {VehicleMediaUrl} from './vehicle-media-url';
import {MarketingText} from './marketing-text';
import {AdTextConfiguration} from './ad-text-configuration';
import {MarketingPhotoUrl} from './marketing-photo-url';
export class VehiclePhotoDetails {
    public VehicleID: number;
    public StoreID: number;
    public InventoryId: number;
    public AppraisalPhotos: VehiclePhoto[];
    public MarketingPhotos: VehiclePhoto[];
    public MediaURL: VehicleMediaUrl[];
    public MarketingText: MarketingText;
    public AdTextIDs: MarketingText[];
    public PreDefAdTexts: AdTextConfiguration[];
    public MarketingComments: string;
    public CurrStatusId: number;
    public NoOfPhotos: number;
    public NoOfClicks: number;
    public IsMarketReady: boolean;
    public MarketingPhotoUrl: MarketingPhotoUrl[];
    public ATClickCount: number;
    public DDCClickCount: number;

}

export class VehiclePhotoWrapper {
    public DriverSide: VehiclePhoto[];
    public Front: VehiclePhoto[];
    public PassengerSide: VehiclePhoto[];
    public Rear: VehiclePhoto[];
    public Interior: VehiclePhoto[];

    public MarketingPhotos: VehiclePhoto[];
    public DDCAdditionalPhotos: VehiclePhoto[];
    public DsLatestThumbnail: string;
    public DsLatestWheelThumbnail: string;
    public DsLatestAdditionalThumbnail: string;
               
    public FrontLatestThumbnail :string  
    public FrontLatestAdditionalThumbnail: string; 
               
    public PsLatestThumbnail: string; 
    public PsLatestWheelThumbnail: string;
    public PsLatestAdditionalThumbnail: string;
               
    public RearLatestThumbnail: string;
    public RearLatestAdditionalThumbnail: string;
               
    public VinLatestThumbnail: string;
    public DashboardLatestWheelThumbnail: string;
    public OdometerLatestAdditionalThumbnail: string;
    public FrontSeatLatestThumbnail: string;
    public BackSeatLatestThumbnail: string;
    public InteriorLatestAdditionalThumbnail: string;
    }               
