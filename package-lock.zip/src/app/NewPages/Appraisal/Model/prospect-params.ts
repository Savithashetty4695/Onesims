export class ProspectParams {
    public  yearId :number;
    public  makeId :number;
    public  modelId:number;
    public trimId: number;
    public transmissionId: number;
    public engineId: number;
    public drivetrainId: number;
    public colorId: number;
    public vin :string;
    public mileage: number;
    public dealerId: number;
    public currStoreId: string;
}
