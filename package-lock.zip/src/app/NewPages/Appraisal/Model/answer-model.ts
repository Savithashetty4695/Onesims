export class AnswerModel {
    public VehicleID: number;
    public StoreID: number;
    public InvtrID: number;
    public UserName: string;
    public Answers: Answer[];
}
export class Answer {
    public value: string;
    public questionId: string;
    public tags: string[];
    public questionType: string;
    public label: string;
    public comment: string;
    public vehicleSectionName: string;
    public vehicleSectionId: number;
    public vehicleConditionCategoryName: string;
    public vehicleConditionCategory: number;
    public maximumValue: number;
    public minimumValue: number;
    public ReconAmt: number;
}

