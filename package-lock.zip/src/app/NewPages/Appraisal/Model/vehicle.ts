
export class Vehicle {
    public Trim: string;
    public ExtColor: string;
    public KBBColorId: string;
    public IntColor: string;
    public Transmission: string;
    public IntrType: string;
    public Engine: string;
    public Fuel: string;
    public Mileage: number;
    public Payoff: number;
    public ManagerNote: string;
    public SightUnseen: boolean;
    public DMVType: string;
    public Year: number;
    public MakeID: string;
    public ModelID: string;
    public Make: string;
    public Model: string;
    public TrimID: string;
    public Classification: string;
    public DMVClassification: string;
    public VehicleType: string;
    public InvtrType: string;
    public ModelCode: string;
    public DealerShipOptions: string;
    public AdditionalDealershipOptions: string;
    public IsDemo: boolean;
    public IsLoaner: boolean;
    public LoanerDate: any;
    public DemoAssignedTo: string;
    public DemoDate: any;
    public ModelCodeID: string;
    public PurchaseUnder: string;
    public AcquisitionType: string;
    public VehicleStatus: string;
    public WizardPage: number;
    public IsMarketReady: boolean;
    public StatusID: number;
    public ServiceDate: any;
    public displacement: string;
    public DriveTrain: string;
    public BodyStyle: string;
    public NetTorqueRPM: number;
    public NetTorqueValue: number;
    public HorsepowerRPM: number;
    public HorsepowerValue: number;
    public FuelEfficiencyCity: number;
    public FuelEfficiencyHwy: number;
    public LaneId: number;
    public SourceName: string;
    public Parking: string;
    public VIN: string;
    public VehicleID: number;
    public SourceType: string;
    public IsKbbVehicle: boolean;
    public StoreID: number;
    public InvtrID: number;
    public ProspectId: string;
    public KBBTrimId: number;


   
    public SalesPerson: string;
    public AcquiredValue: number;
    public AcquisitionDate: Date;
    public LastUpdatedDate: Date;
    public LastUpdatedBy: string;
    public AppraisedBy: string;
    public AppraisedDate: Date;
    public AppraisalValue: number;
    public Purchaser:string ;
    public StockNumber: string;
    public CreatedDate: Date;
    
    //Added properties for KBB Details

  //  public KBBYearId: string;
    public KBBMakeId: number;
    public KBBModelId: number;
    public KBBTransmissionId: number;
    public KBBEngineId: number;
    public KBBDrivetrainId: number;
   // public KBBDealerId: number;
    public ChromeTrim: string;
    public Odometer: string;

    public IsKbbFailure: boolean;
}














