export class KioskLane {
    public LaneId :number;
    public LaneName: string;
}
