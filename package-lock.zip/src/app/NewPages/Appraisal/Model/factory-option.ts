export class FactoryOptions {
    public optionId: string;
    public isSelected: string;
    public displayName: string;
    public categoryName: string;
}
