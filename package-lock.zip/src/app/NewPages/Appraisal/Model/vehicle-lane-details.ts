export class VehicleLaneDetails {
    public vehicleId: number;
    public storeId: number;
    public LaneId: number;
    public vin: string;
    public firstName: string;
    public lastName: string;
    public invtrId: number;
}