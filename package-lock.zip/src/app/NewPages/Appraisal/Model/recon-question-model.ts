import { Questions } from "./Questions.model";

export class ReconQuestionModel {
    public Type: string;
    public Sections: VehicleSection[];
    public DefaultInspectionAmount: number;
    public ImageURL: string;
    public Width: number;
    public Height: number;
}

export class SubCategory {
    public SubCategoryName: string;
    public questions: Questions[];
}

export class Category {
    public CategoryName: string;
    public Id: number;
    public MappingCoordinates: string;
    public XCordinate: number;
    public YCordinate: number;
    public Shape: string;
    public SubCategories: SubCategory[];
    public Cordinates: string;
}

export class VehicleSection {
    public SectionName: string;
    public Categories: Category[];
    public SectionId: number;
}