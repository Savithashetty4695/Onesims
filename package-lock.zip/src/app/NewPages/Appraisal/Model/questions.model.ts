export class Questions {
    public questionId: string;
    public questionType: string;
    public label: string;
    public maxStringLength: number;
    public maximumValue: number;
    public minimumValue: number;
    public enumChoices: string[];
    public comment: string;
    public tags: string[];
    public acceptsComment: boolean;
    public value: string;
    public vehicleSectionName: string;
    public vehicleSectionId: number;
    public vehicleConditionCategoryName: string;
    public vehicleConditionCategory: number;
    public Caption: string;
    public SubCaption: string;
    public ReconAmt: number;
}
