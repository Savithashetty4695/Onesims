export class VehiclePhoto {
    public Photo_ID: number;
    public Vehicle_ID: number;
    public Store_ID: number;
    public Invtr_ID: number;
    public Photo_Cat: number;
    public Photo: Blob;
    public ThumbnailPhoto: Blob;
    public Overlay_Photo: Blob;
    public Photo_Overlay_ID: number;
    public Photo_Order: number;
    public PhotoCaption: string;
    public Created_By: string;
    public IsDeleteTempImage: boolean;
    public Media_Photo_Url: string;
    public Media_Thumbnail_Url: string;
    public PhotoUrl: string;
    public PhotoGuide: string;

}
