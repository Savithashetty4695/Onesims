export class SIMSResponseData {
    public Data: string;
    public Message: string;
    public StatusCode: string;
}
