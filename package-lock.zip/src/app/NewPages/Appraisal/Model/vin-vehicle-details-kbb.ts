import { VinVehicleDetails } from '../Model/vin-vehicle-details';

export class VinVehicleDetailsKBB {
    public DecodeVinVehicleDetails: VinVehicleDetails;

    public KBBVinVehicleDetails: RootObject;

    public IsKbbFailure: boolean;
}

export class RootObject {
    public data: Data;
    }

    export class Data {
        public possibilities: Possibility[];
    }

    export class Possibility {
        public year: Year;
        public make: Make;
        public model: Model;
        public trim: Trim;
        public drivetrains: Drivetrain[];
        public engines : Engine[];
        public transmissions: Transmission[];
        public color: color;
    }

       export class Year {
            public yearId: number;
            public displayName: string;
    }

       export class Make {
            public makeId: number;
            public displayName: string;
    }
       
         export class Model {
            public modelId : number;
            public displayName: string;
    }

         export class Trim {
            public trimId: number;
            public displayName: string;
    }
       
         export class Drivetrain {
            public drivetrainId: number;
            public displayName: string;
    }

         export class Engine {
            public engineId: number;
            public displayName: string;
    }
        
         export class Transmission {
            public transmissionId: number;
            public displayName : string;
    }

         export class color {
            public colorId: number;
    }