export class PhotoUploadParams {
    public VehicleID: number;
    public StoreID: number;
    public InvtrID: number;
    public PhotoCat: number;
    public UserName: string;
    public PhotoGuide: string;
    public Base64StringImage: string;
}
