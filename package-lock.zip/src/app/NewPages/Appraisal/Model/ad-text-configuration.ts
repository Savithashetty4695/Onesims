export class AdTextConfiguration {
    public Ad_Text_ID: number;
    public Ad_Text: string;
    public Is_Act: boolean;
    public Created_By: string;
    public Inventory_Type: number;
}
