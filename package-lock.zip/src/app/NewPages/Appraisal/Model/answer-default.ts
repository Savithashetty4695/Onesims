export class AnswerDefault {
    public IsOriginalOwnor: string;
    public IsClearHistory: string;
    public IsRentalCar: string;
    public IsServiceRecordAvailable: string;
    public IsAutoAction: string;
    public IsSmoke: string;
}