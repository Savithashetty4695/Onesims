export class IDValues {
    public ID: string;
    public Value: string;
    public Selected: boolean;
    public Code: string;
}