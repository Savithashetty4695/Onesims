export class KbbColors {
    public data:Datum[];
}

export class Datum {
    public colorId: number;
    public displayName: string;
}