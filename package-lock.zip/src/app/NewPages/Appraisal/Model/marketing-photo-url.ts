export class MarketingPhotoUrl {
    public PhotoIdentifier: string;
    public Vehicle_ID: number;
    public Store_ID: number;
    public Invtr_ID: number;
    public Url: string
    public ThumbnailUrl: string
    public Photo: Blob;
    public ThumbnailPhoto: Blob;
    public Positionstring: number;
    public PhotoGuide: string
}
