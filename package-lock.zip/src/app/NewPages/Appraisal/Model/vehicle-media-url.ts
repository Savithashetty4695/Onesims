export class VehicleMediaUrl {
    public Photo_ID: number;
    public Media_Photo_URL: string;
    public Media_Overlay_URL: string
    public Media_Thumbnail_URL: string
    public Vehicle_ID: number;
    public Store_ID: number;
    public Invtr_ID: number;
    public Photo_Cat: number;
    public Photo_Overlay_ID: number;
    public D_Rating: number;
    public IsUnitsMissing: boolean;
    public CurrStatusID: number;
    public PriceRvwLogID: number;
    public Is_DataMissing: boolean;
}
