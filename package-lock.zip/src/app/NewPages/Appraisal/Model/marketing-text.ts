export class MarketingText {
    public VehicleID: number;
    public StoreID: number;
    public InvtrID: number;
    public AdTextID: number;
    public AdText: string;
    public Is_Act: number;
    public IsSelected: number;
}
