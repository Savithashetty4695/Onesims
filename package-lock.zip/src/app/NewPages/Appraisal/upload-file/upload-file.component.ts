import { Component, OnInit, ViewChild  } from '@angular/core';
import {KBBServiceService} from '../Services/kbbservice.service';
import {Response, Headers} from '@angular/http';
import {SIMSResponseData} from '../model/simsresponse-data';
import {VehicleParams} from '../Model/vehicle-params.model';
import {ErrorHandler}from '../common/error-handler';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-upload-file',
    templateUrl: './upload-file.component.html',
    styleUrls: ['./upload-file.component.css']
})
export class UploadFileComponent implements OnInit {
    isUploadBtn: boolean = true;
    params: VehicleParams;
    errorHandler: ErrorHandler;
    AppraisalStatus: number[] = [101, 102];
    MarketingStatus: number[] = [201, 202, 203, 204, 205, 214, 215, 216, 217, 218, 219, 221, 232, 236, 238];
    SaleStatus: number[] = [301, 302, 303, 305];
    //uploadForm: FormGroup;
    fileExtension: any;
    busyA: Subscription;
    @ViewChild('fileUpload') fileUpload: any;   
    constructor(public kbbServiceService: KBBServiceService) {
        this.params = new VehicleParams();
        this.errorHandler = new ErrorHandler();
    }

    ngOnInit() {
        let SourceType: number = parseInt(this.kbbServiceService.GetVehicleDetailsFromCache(null).SourceType);
        let StatusId: number = this.kbbServiceService.GetVehicleDetailsFromCache(null).StatusID;
        this.params = this.kbbServiceService.getVehicleParameters();
        let VehicleParam = {
            VehicleID: this.params.VehicleId,
            StoreID: this.params.StoreId,
            InvtrID: this.params.InventoryId,
            PhotoCat: 10,
            UserName: this.params.UserName
        };
    }
    //fileChange(event) {
    //    this.kbbServiceService.isConditionEnable.next(false);
    //    let fileList: FileList = event.target.files;
    //    if (fileList.length > 0) {
    //        var totalFileLength = 0;
    //        let isLengthExceeded: boolean = false;
    //        for (var i = 0; i <= fileList.length - 1; i++) {
    //            var fsize = fileList.item(i).size;
    //            var maxLength = Math.round((fsize / 1024));
    //            totalFileLength = totalFileLength + maxLength;
    //            if (maxLength > 102400 || totalFileLength > 102400) {
    //                isLengthExceeded = true;
    //                break;
    //            }
    //        }
    //        if (isLengthExceeded) {
    //            document.getElementById('errMsgPhotoUpload').innerHTML = 'Uploaded image size exceeds 100MB';
    //            this.fileUpload.nativeElement.value = "";
    //            return false;
    //        }
    //        else {
    //            document.getElementById('errMsgPhotoUpload').innerHTML = "";
    //        }
    //        var count = 0;
    //        var allowedExtensions = ["jpg", "jpeg", "png", "PNG", "JPG", "JPEG", "JFIF","jfif", "BMP", "SVG", "svg" , "bmp"];
    //        for (let i = 0; i < fileList.length; i++) {
    //            this.fileExtension = fileList[i].name.split('.').pop();

    //            if (!this.isInArray(allowedExtensions, this.fileExtension)) {
    //                count++;
    //            }
    //            if (count > 0) {
    //                document.getElementById('errMsgPhotoUpload').innerHTML = "Only photos are allowed!!"
    //                this.fileUpload.nativeElement.value = "";
    //                this.kbbServiceService.isConditionEnable.next(true);
    //                return false;
    //            }
    //            else {
    //                document.getElementById('errMsgPhotoUpload').innerHTML = "";
    //            }
    //        }

    //        let VehicleParam = {
    //            VehicleID: this.params.VehicleId,
    //            StoreID: this.params.StoreId,
    //            InvtrID: this.params.InventoryId,
    //            PhotoCat: this.AppraisalStatus.indexOf(this.params.StatusId) != -1 ? 10 :
    //                this.MarketingStatus.indexOf(this.params.StatusId) != -1 ? 20 : 30,
    //            UserName: this.params.UserName
    //        };
    //        let formData: FormData = new FormData();
    //        formData.append('VehicleParam', JSON.stringify(VehicleParam));
    //        for (let i = 0; i < fileList.length; i++) {
    //            let file: File = fileList[i];
    //            formData.append('file_' + i, file, file.name);
    //        }
    //        this.busyA = this.kbbServiceService.SaveAppraisalPhotos(formData).subscribe(
    //            (result: SIMSResponseData) => {
    //                this.Saved(result);
    //                this.fileUpload.nativeElement.value = "";
    //                this.kbbServiceService.PhotoUploadCompleted();
    //                this.kbbServiceService.isConditionEnable.next(true);
    //            },
    //            (error: Response | any) => this.errorHandler.handleError(error));
    //    }
    //}
    Saved(data) {
        //Data saved sucessfully.
        //Add after save stuffs here.
    }
    isInArray(array, word) {
        return array.indexOf(word.toLowerCase()) > -1;
    }
}
