import { Component, OnInit, Output, EventEmitter, Input, ElementRef, ViewChild, HostListener, TemplateRef } from '@angular/core';
import {Response} from '@angular/common/esm5/http';
import { Pipe, PipeTransform } from '@angular/core';
import { MatDialogModule, MatDialogRef } from '@angular/material';
import {KBBServiceService} from '../Services/kbbservice.service';
import {VinVehicleDetails} from '../Model/vin-vehicle-details';
import {VinVehicleDetailsKBB} from '../Model/vin-vehicle-details-kbb';
import {HttpServiceService} from '../Services/http-service.service';
import {VehicleParams} from '../Model/vehicle-params.model';
import {Vehicle} from '../Model/vehicle';
import {ProspectParams} from '../Model/prospect-params';
import {ErrorHandler}from '../common/error-handler';
import {KbbColors} from '../Model/kbb-colors';
import {IDValues} from '../Model/id-values';
import { LinkEnum, DecodeType } from '../Model/link-enum.enum';
import {KioskLane } from '../model/kiosk-lane';
import {VehicleLaneDetails} from '../model/vehicle-lane-details';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { ValuationData } from '../book-values/Model/valuation-data';
import { BookValueRequestPost } from '../book-values/model/book-value-request-post';
// import { forEach } from '@angular/router/src/utils/collection';
import { forEach } from '@angular/router/esm5/src/utils/collection';
import { SIMSResponseData } from '../Model/simsresponse-data';
declare var Close: any;



@Component({
    selector: 'app-vehicle-info',
    templateUrl: './vehicle-info.component.html',
    styleUrls: ['./vehicle-info.component.css'],
})
export class VehicleInfoComponent implements OnInit {


    @Input() appraisalPayload: any;
    indexCounter: number;
    decodeVinVehicleDetails: VinVehicleDetails;
    decodeVinVehicleDetailsKBB: VinVehicleDetailsKBB;
    vinVehicleDetails: Vehicle;
    vehicleparams: VehicleParams;
    prospectparams: ProspectParams;
    errorHandler: ErrorHandler;
    decodeapiVehicleResult: VinVehicleDetails;
    showDecodeVin: boolean;
    vehFormInvalid: boolean;
    kbbColors: KbbColors;
    newTrimId: number;
    selectedOption: string;
    iDValues: IDValues;
    editMode: boolean;
    disableSightUnseen: boolean;
    @Input() showSaveCloseButtons: boolean;
    @Input() kbbEditObject: string;
    editParams: any;
    SACStatusID: number;
    isCCAVehicle: boolean = false;
    reqResubmit:boolean= false;
    @ViewChild('resubmitpopup',{static: false}) resubmitpopup: any;
    body: any;
    busyA: Subscription;
    busyB: Subscription;
    busyC: Subscription;
    isKeyPressed: Boolean;
    mileageInvalid: boolean;
    newMileage: number;
    who: any;
    temp: any;
    temp1: any;
    htmlMileageElement: any;
    prevTrimId: number;
    enteredMileageValue: number;
    @ViewChild('content',{static: false}) content: any;
    userName: string;
    error: string;
    whoPayoff: any;
    tempPayoff: any;
    temp1Payoff: any;
    htmlPayoffElement: any;
    isPayoffKeyPressed: Boolean;
    enteredPayoffValue: number;
    showAcquisitionInformation: boolean;
    showAcquisitionInformationText: boolean;
    decodeVinDetails: VinVehicleDetails;
    LaneDetails: KioskLane[];
    vehicleLaneDetails: VehicleLaneDetails;
    isMiddleDivVisible: boolean = true;
    @ViewChild('ddc',{static: false}) laneContent: any;
    //@ViewChild('mileageModal') mileageModal: any;
    showlanepopup: boolean;
    kbbModelArray: IDValues[];
    KbbSeriesTrimId: number;
    initialKbbSuccessStatus: boolean;
    IsDDCVehicle: boolean = false;
    KBBvaluationData: ValuationData;
    bookValueRequestPost: BookValueRequestPost;
    KbbDecodeVehicleSource: any;
    constructor(public kbbService: KBBServiceService, public httpService: HttpServiceService, public dialog: MatDialogModule, public modalService: NgbModal) {
        if (this.decodeVinVehicleDetailsKBB == null)
            this.decodeVinVehicleDetailsKBB = new VinVehicleDetailsKBB();
        if (this.decodeVinVehicleDetails == null)
            this.decodeVinVehicleDetails = new VinVehicleDetails();
        if (this.vinVehicleDetails == null)
            this.vinVehicleDetails = new Vehicle();
        if (this.decodeVinDetails == null)
            this.decodeVinDetails = new VinVehicleDetails();
        if (this.decodeVinVehicleDetails.Series == null)
            this.decodeVinVehicleDetails.Series = new Array<IDValues>();
        if (this.decodeVinVehicleDetails.ChromeTrim == null)
            this.decodeVinVehicleDetails.ChromeTrim = new Array<IDValues>();
        this.prospectparams = new ProspectParams();
        this.vehicleparams = new VehicleParams();
        this.errorHandler = new ErrorHandler();
        this.KBBvaluationData = new ValuationData();
        this.bookValueRequestPost = new BookValueRequestPost();
        if (this.vehicleLaneDetails == null) {
            this.vehicleLaneDetails = new VehicleLaneDetails();
        }
        this.KbbDecodeVehicleSource = HttpServiceService.KbbDecodeVehicleSource;
    }

    ngOnInit() {
        this.isMiddleDivVisible = true;
        this.showlanepopup = false;
        this.addMileageEventListeners();
        this.vehicleparams = this.kbbService.getVehicleParameters();
        if ((this.appraisalPayload != null || this.appraisalPayload != undefined) && this.vehicleparams == undefined) {
            let appraisalPayloadJson: any = JSON.parse(this.appraisalPayload);
            this.vehicleparams = new VehicleParams();
            this.vehicleparams.VIN = appraisalPayloadJson.vin;
            this.vehicleparams.Mileage = appraisalPayloadJson.mileage;
            this.vehicleparams.StoreId = appraisalPayloadJson.storeId;
            this.vehicleparams.InventoryType = appraisalPayloadJson.inventoryType;
            this.vehicleparams.VehicleId = appraisalPayloadJson.vehicleId;
            this.vehicleparams.InventoryId = appraisalPayloadJson.invtrId;
            this.vehicleparams.UserName = appraisalPayloadJson.userName;
            this.vehicleparams.SourceType = appraisalPayloadJson.sourceType;
            this.vehicleparams.Kiosk_Req = (appraisalPayloadJson.Kiosk_Req != null || appraisalPayloadJson.Kiosk_Req !== undefined) ? appraisalPayloadJson.Kiosk_Req : '';
            this.userName = appraisalPayloadJson.userName;
            this.vehicleparams.IsKbbVehicle = appraisalPayloadJson.isKbbVehicle;
            this.vehicleparams.CurrStoreID = appraisalPayloadJson.currStoreId;
            this.vehicleparams.Decode_Type = appraisalPayloadJson.Decode_Type;
            this.vehicleparams.isStep5Exists = appraisalPayloadJson.isStep5Exists;
            this.vehicleparams.ManagerNote = "";
            if (appraisalPayloadJson.isPendingAppraisal != false) {
                this.vehicleparams.isPendingAppraisal = appraisalPayloadJson.isPendingAppraisal;
            }
            this.kbbService.setVehicleParameters(this.vehicleparams);
        }



        this.disableSightUnseen = false;
        this.showDecodeVin = true;
        this.vehFormInvalid = false;
        this.mileageInvalid = false;
        this.enteredMileageValue = 0;
        

        this.decodeVinVehicleDetails.Series = null;



        if (this.kbbEditObject != null && this.kbbEditObject != undefined) {
            this.vehicleparams = JSON.parse(this.kbbEditObject.replace(/'/g, '"'));
            this.vehicleparams.InventoryType = 10;
            this.editMode = this.vehicleparams.editMode;
            this.SACStatusID = parseInt(this.vehicleparams.SACStatusID.toString());
            this.isCCAVehicle = this.vehicleparams.isCCAVehicle;
        }


        // added below condition here to avoid null check in edit mode
        if (this.vehicleparams.Kiosk_Req == 'Yes') {
            this.showlanepopup = true;
            this.isMiddleDivVisible = false;
            this.kbbService.GetStoreForLanes(this.vehicleparams).subscribe(
                (result: KioskLane[]) => {
                    let count = result.length;
                    let kioskDetails: KioskLane;
                    this.LaneDetails = new Array<KioskLane>();
                    for (let i = 0; i < count; i++) {
                        kioskDetails = new KioskLane();
                        kioskDetails.LaneId = result[i].LaneId;
                        kioskDetails.LaneName = result[i].LaneName;
                        this.LaneDetails.push(kioskDetails);
                    }
                    //this.laneContent.elementRef.nativeElement
                    //this.open(this.laneContent);
                },
                (error: Response | any) => this.errorHandler.handleError(error));


        }

        if (this.KbbDecodeVehicleSource.toString().split(',').includes(this.vehicleparams.SourceType.toString()))//this.vehicleparams.SourceType == 110 || this.vehicleparams.SourceType==120
            this.IsDDCVehicle = true;
        if (this.vehicleparams.Decode_Type == DecodeType.KBB_Book_Decode) {
            this.IsDDCVehicle = true;
        }
        else {
            this.IsDDCVehicle = false;
        }

        this.getVehicleData();
    }


    sightUnseenStatus() {
        if (this.kbbService.vinVehicleDetails.SightUnseen == true) {
            this.kbbService.vinVehicleDetails.SightUnseen = false;
        }
    }

    changeMileage() {
        if (this.vinVehicleDetails.Mileage != null) {
            this.newMileage = this.vinVehicleDetails.Mileage;
            this.vinVehicleDetails.Mileage = null;
            this.kbbService.vinVehicleDetails.Mileage = null;
        }
    }

    getVehicleData() {
        let cachedVinVehicleDetails = this.kbbService.GetVehicleDetailsFromCache(this.vehicleparams);
        if (cachedVinVehicleDetails != undefined) {
            this.vinVehicleDetails = cachedVinVehicleDetails;

            this.kbbService.VehicleInfoGetCompleted();
            let cachedDecodeVehicleDetails = this.kbbService.DecodeVinFromCache(this.vehicleparams);
            if (cachedDecodeVehicleDetails != undefined) {
                this.decodeVinVehicleDetailsKBB = cachedDecodeVehicleDetails;
                this.decodeVinVehicleDetails = this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails;
                this.showAcquisitonDetails();
                // Chrome change
                this.initialKbbSuccessStatus = cachedDecodeVehicleDetails.IsKbbFailure;
                // end

                this.getKBBDecodeVinData();
            }
            else {
                if (this.vinVehicleDetails.Make == "BAD_VIN") {
                    this.showDecodeVin = false;
                }
                else {
                    this.getDecodeVinData();
                }
            }
            this.checkdisableSightUnseen(this.vinVehicleDetails);
        }

        else {
            this.busyA = this.kbbService.GetVehicleDetailsFromAPI(this.vehicleparams).subscribe(
                (result: Vehicle) => {
                    this.vinVehicleDetails = result;
                    // chekcing 0 mileage condition #1784
                    this.vinVehicleDetails.Mileage = this.vinVehicleDetails.Mileage == 0 ? null : this.vinVehicleDetails.Mileage;
                    //Popup Changes For Complete Edit Page Starts
                    this.SeriesTrim = this.vinVehicleDetails.Trim;
                    this.KbbSeriesTrimId = this.vinVehicleDetails.KBBTrimId;
                    this.VehicleType = this.vinVehicleDetails.VehicleType;
                    this.kbbService.vehicleType = this.vinVehicleDetails.VehicleType;
                    this.Mileage = this.vinVehicleDetails.Mileage;
                    this.ChromeTrim = this.vinVehicleDetails.ChromeTrim;

                    this.initialKbbSuccessStatus = this.vinVehicleDetails.IsKbbFailure;

                    if ((this.vinVehicleDetails.Transmission == null && this.vinVehicleDetails.DriveTrain == null) || (this.vinVehicleDetails.Transmission == '' && this.vinVehicleDetails.DriveTrain == '')) {
                        this.vinVehicleDetails.Engine = null;
                    }
                    //Popup Changes For Complete Edit Page ends
                    if ((this.vinVehicleDetails.KBBTrimId == null || this.vinVehicleDetails.KBBTrimId == 0) && (!this.vinVehicleDetails.IsKbbFailure)) {

                        this.vinVehicleDetails.Engine = null;
                        this.vinVehicleDetails.Trim = null;
                        this.vinVehicleDetails.Transmission = null;
                        this.vinVehicleDetails.DriveTrain = null;
                    }

                    this.vinVehicleDetails.ManagerNote === '' ? null : this.vinVehicleDetails.ManagerNote;
                    this.vehicleparams.ManagerNote = this.vinVehicleDetails.ManagerNote;
                    this.persistentVehicleData();
                    if (this.vinVehicleDetails.SightUnseen == true && this.editMode == true) {
                        this.open(this.content);
                    }
                    if (this.vinVehicleDetails.SightUnseen == true) {
                        this.changeMileage();
                    }
                    this.vehicleparams.UserName = this.userName;
                    this.vehicleparams.SourceType = parseInt(this.vinVehicleDetails.SourceType);
                    this.kbbService.setVehicleParameters(this.vehicleparams);
                    this.kbbService.VehicleInfoGetCompleted();

                    let cachedDecodeVehicleDetails = this.kbbService.DecodeVinFromCache(this.vehicleparams);
                    if (cachedDecodeVehicleDetails != undefined) {
                        this.decodeVinVehicleDetailsKBB = cachedDecodeVehicleDetails;
                    }
                    else {

                        if (this.vinVehicleDetails.Make == "BAD_VIN") {
                            this.showDecodeVin = false;
                        }
                        else {
                            this.getDecodeVinData();
                            this.checkdisableSightUnseen(this.vinVehicleDetails);
                        }
                    }


                },
                (error: Response | any) => this.errorHandler.handleError(error));
        }



        if (this.vinVehicleDetails.StatusID == 101 || this.vinVehicleDetails.StatusID == 102
            || this.vinVehicleDetails.StatusID == 103) {

            this.vinVehicleDetails.StockNumber = "";
        }



        if (this.vinVehicleDetails.StatusID == 201 || this.vinVehicleDetails.StatusID == 202
            || this.vinVehicleDetails.StatusID == 203 || this.vinVehicleDetails.StatusID == 204
            ||   this.vinVehicleDetails.StatusID == 205 || this.vinVehicleDetails.StatusID == 234) {
            this.disableSightUnseen = true;
        }



    }
    checkdisableSightUnseen(data) {
        if (data.StatusID == 201 || data.StatusID == 202 ||
            data.StatusID == 203 || data.StatusID == 204 ||
            data.StatusID == 205 || data.StatusID == 234) {
            this.disableSightUnseen = true;
        }
    }
    showAcquisitonDetails() {

        if (this.vinVehicleDetails.StatusID == 101 || this.vinVehicleDetails.StatusID == 102 || this.vinVehicleDetails.StatusID == 103) {
            this.showAcquisitionInformation = false;
            this.showAcquisitionInformationText = false;
            this.vinVehicleDetails.AcquisitionType = "Tradein";
            this.persistentVehicleData();
        }
        else {
            this.showAcquisitionInformation = true;
            this.showAcquisitionInformationText = true;

        }
    }

    getDecodeVinDataFromAPI(VIN: any) {

        this.vehicleparams.VIN = VIN;
        this.kbbService.vehicleParams.VIN = VIN;
        this.getDecodeVinData();
    }



    getDecodeVinData() {

        this.busyB = this.kbbService.DecodeVin(this.vehicleparams).subscribe(
            (result: VinVehicleDetailsKBB) => {
                this.decodeVinVehicleDetailsKBB = result;
                this.decodeVinVehicleDetails = result.DecodeVinVehicleDetails;

                //IsKbbFailure start
                this.kbbService.vehicleParams.IsKbbFailure = this.decodeVinVehicleDetailsKBB.IsKbbFailure;
                this.vinVehicleDetails.IsKbbFailure = this.decodeVinVehicleDetailsKBB.IsKbbFailure;
                this.kbbService.vinVehicleDetails.IsKbbFailure = this.vinVehicleDetails.IsKbbFailure;

                //If Vehicle inserted year as 0  updating chorme or KBB year value 
                if (this.vinVehicleDetails.Year == 0) {
                    if (this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.Year != 0) {
                        this.vinVehicleDetails.Year = this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.Year;
                    }
                    else {
                        this.vinVehicleDetails.Year = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[0].year.yearId;
                    }
                }

                
                //IsKbbFailureEnd

                if (this.vehicleparams.Kiosk_Req == "otherReq") {
                    this.decodeVinVehicleDetails.ClassOfVehicle.splice(2, 1);
                }

                this.persistentKbbDecodeVin();
                this.showAcquisitonDetails();

                if (this.vinVehicleDetails.Make == "BAD_VIN") {

                    this.kbbService.vinVehicleDetails.Year = this.decodeVinVehicleDetails.Year;
                    this.kbbService.vinVehicleDetails.Make = this.decodeVinVehicleDetails.Make[0].Value;
                    this.kbbService.vinVehicleDetails.Model = this.decodeVinVehicleDetails.Model[0].Value;
                }                
            
                if (this.decodeVinVehicleDetails.Series.length == 1) {
                    let chromeIdValues: IDValues;
                    chromeIdValues = new IDValues();
                    chromeIdValues.ID = this.decodeVinVehicleDetails.Series[0].ID;
                    this.vinVehicleDetails.TrimID = this.decodeVinVehicleDetails.Series[0].ID;
                    this.kbbService.vinVehicleDetails.TrimID = this.vinVehicleDetails.TrimID;
                    this.vinVehicleDetails.ChromeTrim = this.decodeVinVehicleDetails.Series[0].Value;
                    this.kbbService.vinVehicleDetails.ChromeTrim = this.vinVehicleDetails.ChromeTrim;
                    chromeIdValues.Value = this.decodeVinVehicleDetails.Series[0].Value;
                    chromeIdValues.Code = this.decodeVinVehicleDetails.Series[0].Code;

                    // Remove ICO - reseting series to chrome array
                    if (this.decodeVinVehicleDetails.ChromeTrim == null)
                        this.decodeVinVehicleDetails.ChromeTrim = new Array<IDValues>();

                    this.decodeVinVehicleDetails.ChromeTrim[0] = chromeIdValues;
                    this.decodeVinVehicleDetails.Series = new Array<IDValues>();
                }
                else {
                    var getTrimCount = this.decodeVinVehicleDetails.Series.length;
                    var count;

                    this.decodeVinVehicleDetails.ChromeTrim = [];
                    let chromeIdValues: IDValues;
                    for (count = 0; count < getTrimCount; count++) {
                        chromeIdValues = new IDValues();
                        chromeIdValues.ID = this.decodeVinVehicleDetails.Series[count].ID;
                        chromeIdValues.Code = this.decodeVinVehicleDetails.Series[count].Code;
                        chromeIdValues.Value = this.decodeVinVehicleDetails.Series[count].Value;
                        this.decodeVinVehicleDetails.ChromeTrim.push(chromeIdValues);
                    }
                    this.decodeVinVehicleDetails.Series = new Array<IDValues>();
                }

                this.getKBBDecodeVinData();
                this.showDecodeVin = true;
                this.vinVehicleDetails.VIN = this.decodeVinVehicleDetails.VIN;
                this.error = null;

                if (this.decodeVinVehicleDetailsKBB.IsKbbFailure) {
                    this.kbbService.KbbDecodeCompleteChange.next(true);
                }
            },
            (error: Response | any) => {
                this.errorHandler.handleError(error);
                this.error = "Call Decode VIN failed";
                this.showDecodeVin = false;
            });
    }

    //@Output()
    //notify: EventEmitter<Vehicle> = new EventEmitter<Vehicle>();

    //@Output()
    //notifyDecodeVin: EventEmitter<VinVehicleDetails> = new EventEmitter<VinVehicleDetails>();
    onKeyChange(event: any) {// without type info
        if (this.isKeyPressed)
            event.preventDefault();
        this.isKeyPressed = true;


        let charCode = (event.which) ? event.which : event.keyCode;
        if ((charCode != 46 && charCode != 13 && charCode > 31
            && (charCode < 48 || charCode > 57)) || charCode == 13 || charCode == 46) {
            return false;
        }
        var numKey = +event.key;
        this.enteredMileageValue += numKey;
        var vinMileageValue = (<HTMLInputElement>document.getElementById("txtMileage")).value;

        if (this.enteredMileageValue == 0 && vinMileageValue == '') {
            this.vinVehicleDetails.Mileage = null;
            this.htmlMileageElement.className += " ng-Invalid";
            this.mileageInvalid = true;
            return false;
        }

        return true;
    }

    addCommas(n) {
        var rx = /(\d+)(\d{3})/;
        return String(n).replace(/^\d+/, function (w) {
            while (rx.test(w)) {
                w = w.replace(rx, '$1,$2');
            }
            return w;
        });
    }
    // return integers and decimal numbers from input
    // optionally truncates decimals- does not 'round' input
    validDigits(n: any): any {
        n = n.replace(/[^\d\.]+/g, '');
        var ax1 = n.indexOf('.'), ax2 = -1;
        if (ax1 != -1) {
            ++ax1;
            ax2 = n.indexOf('.', ax1);
            if (ax2 > ax1) n = n.substring(0, ax2);
        }
        var num = parseInt(n);
        if (num == 0) {
            n = "";
        }
        if (n <= 0) {
            n = "";
        }
        return n;
    }
    addMileageEventListeners() {
        this.htmlMileageElement = document.getElementById('txtMileage');
        this.htmlPayoffElement = document.getElementById('txtPayoff');
        this.htmlMileageElement.value = '';
    }


    onKeyUp(event: any) {

        this.isKeyPressed = false;
        event = event || window.event;

        var enteredMileage = parseInt(event.currentTarget.value);
        if (enteredMileage == 0 || this.vinVehicleDetails.Mileage == 0) {
            this.vinVehicleDetails.Mileage = null;
            this.mileageInvalid = true;
            this.htmlMileageElement.className += " ng-Invalid";
        }

        this.who = event.target || event.srcElement, this.temp;
        if (this.who != undefined && this.who != null) {
            this.temp = this.validDigits(this.who.value);
            if (this.temp <= 0 || this.temp == 0) {
                this.vinVehicleDetails.Mileage = null;
                this.htmlMileageElement.className += " ng-Invalid";
                this.mileageInvalid = true;
            }
            else {
                this.who.value = this.addCommas(this.temp);
            }
        }

        this.updateMileageField(event.currentTarget.value);

    }

    onBlur() {
        if (this.validDigits(this.htmlMileageElement.value) == "") {
            this.vinVehicleDetails.Mileage = null;
            this.mileageInvalid = true;
        }
        else {
            this.temp1 = parseFloat(this.validDigits(this.htmlMileageElement.value));

            if (this.temp1) this.htmlMileageElement.value = this.addCommas(this.temp1);
        }

        this.updateMileageField(this.htmlMileageElement.value);
    }

    getKBBDecodeVinData() {
        this.vinVehicleDetails.KBBMakeId = this.decodeVinVehicleDetails.KBBMakeId;
        // this.vinVehicleDetails.KBBModelId = this.decodeVinVehicleDetails.KBBModelId;

        if (this.decodeVinVehicleDetails.Series.length == 0) {

            this.decodeVinVehicleDetails.Series = new Array<IDValues>();
        }

        //extapp vehicle or Remove ICO
        if (this.IsDDCVehicle) {

            //year
            if (this.decodeVinVehicleDetails.Years != null) {
                let Years = this.decodeVinVehicleDetails.Years;
                if (Years.length == 1) {
                    this.vinVehicleDetails.Year = parseInt(Years[0].Value);
                }
                else {
                    //set the selected value for year
                    if (this.vinVehicleDetails.Year != null) {
                        let yearId: string = this.vinVehicleDetails.Year.toString();
                        let selectedYear = this.decodeVinVehicleDetails.Years.find(i => i.ID == yearId);
                        if (selectedYear != null) {
                            this.vinVehicleDetails.Year = parseInt(selectedYear.Value);
                        }
                        else {
                            this.vinVehicleDetails.Year = null;
                        }

                    }
                }
            }

            //make
            if (this.decodeVinVehicleDetails.Make != null) {
                if (this.decodeVinVehicleDetails.Make.length == 1) {
                    this.vinVehicleDetails.Make = this.decodeVinVehicleDetails.Make[0].Value;
                    this.vinVehicleDetails.MakeID = this.decodeVinVehicleDetails.Make[0].ID;
                    this.vinVehicleDetails.KBBMakeId =parseInt(this.decodeVinVehicleDetails.Make[0].ID);
                }
                else {
                    //drop down with setting saved value
                    if (this.vinVehicleDetails.Make != null && this.vinVehicleDetails.MakeID != null) {
                        let makeId: string = this.vinVehicleDetails.MakeID;
                        let selectedMake = this.decodeVinVehicleDetails.Make.find(i => i.ID == makeId);
                        if (selectedMake != null) {
                            this.vinVehicleDetails.Make = selectedMake.Value;
                            this.vinVehicleDetails.MakeID = selectedMake.ID;
                            this.vinVehicleDetails.KBBMakeId = parseInt(this.vinVehicleDetails.MakeID);
                        }
                        else {
                            this.vinVehicleDetails.Make = null;
                            this.vinVehicleDetails.KBBMakeId = null;
                            this.vinVehicleDetails.MakeID = null;
                        }
                    }
                    else {
                        this.vinVehicleDetails.Make = null;
                        this.vinVehicleDetails.KBBMakeId = null;
                        this.vinVehicleDetails.MakeID = null;
                    }


                    this.vinVehicleDetails.Make = this.decodeVinVehicleDetails.Make[0].Value;
                    this.vinVehicleDetails.MakeID = this.decodeVinVehicleDetails.Make[0].ID;
                    this.vinVehicleDetails.KBBMakeId =parseInt(this.vinVehicleDetails.MakeID)
                }
            }
           
            //model
            if (this.decodeVinVehicleDetails.Model != null) {
                if (this.decodeVinVehicleDetails.Model.length == 1) {
                    this.vinVehicleDetails.Model = this.decodeVinVehicleDetails.Model[0].Value;                    
                    this.vinVehicleDetails.ModelID = this.decodeVinVehicleDetails.Model[0].ID;
                    this.vinVehicleDetails.KBBModelId = parseInt(this.decodeVinVehicleDetails.Model[0].ID);
                }
                else {
                    //drop down with setting saved value
                    if (this.vinVehicleDetails.Model != null && this.vinVehicleDetails.ModelID != null) {
                        let modelId: string = this.vinVehicleDetails.ModelID;
                        let selectedModel = this.decodeVinVehicleDetails.Model.find(i => i.ID == modelId);
                        if (selectedModel != null) {
                            this.vinVehicleDetails.Model = selectedModel.Value;
                            this.vinVehicleDetails.ModelID = selectedModel.ID;
                            this.vinVehicleDetails.KBBModelId = parseInt(this.vinVehicleDetails.ModelID);
                        }
                        else {
                            this.vinVehicleDetails.Model = null;
                            this.vinVehicleDetails.KBBModelId = null;
                            this.vinVehicleDetails.ModelID = null;
                        }
                    }
                    else {
                        this.vinVehicleDetails.Model = null;
                        this.vinVehicleDetails.KBBModelId = null;
                        this.vinVehicleDetails.ModelID = null;
                    }
                    
                }
            }    

            //series (series are stored in chromeTrim)
            if (this.decodeVinVehicleDetails.ChromeTrim != null) {
                if (this.decodeVinVehicleDetails.ChromeTrim.length==1) {
                    this.vinVehicleDetails.TrimID = this.decodeVinVehicleDetails.ChromeTrim[0].ID;                  
                    this.vinVehicleDetails.ChromeTrim = this.decodeVinVehicleDetails.ChromeTrim[0].Value;                    
                    this.vinVehicleDetails.KBBTrimId = parseInt(this.vinVehicleDetails.TrimID);                   
                }
                else {
                    if (this.vinVehicleDetails.ChromeTrim != null && this.vinVehicleDetails.KBBTrimId != null) {
                        let seriesId: string = this.vinVehicleDetails.KBBTrimId.toString();
                        let selectedSeries = this.decodeVinVehicleDetails.ChromeTrim.find(i => i.ID == seriesId);
                        if (selectedSeries != null) {
                            this.vinVehicleDetails.TrimID = selectedSeries.ID;                           
                            this.vinVehicleDetails.ChromeTrim = selectedSeries.Value;                            
                            this.vinVehicleDetails.KBBTrimId = parseInt(this.vinVehicleDetails.TrimID);
                        }
                        else {
                            this.vinVehicleDetails.TrimID = null;                            
                            this.vinVehicleDetails.ChromeTrim = null;                            
                            this.vinVehicleDetails.KBBTrimId = null;
                        }
                    }
                    else {
                        this.vinVehicleDetails.TrimID = null;
                        this.vinVehicleDetails.ChromeTrim = null;
                        this.vinVehicleDetails.KBBTrimId = null;
                    }
                }                
            }

            //Engin
            if (this.decodeVinVehicleDetails.Engine != null)
            {
                if (this.decodeVinVehicleDetails.Engine.length == 1) {
                    this.vinVehicleDetails.Engine = this.decodeVinVehicleDetails.Engine[0].Value;                    
                    this.vinVehicleDetails.KBBEngineId = parseInt(this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.Engine[0].ID);
                }
                else {
                    if (this.vinVehicleDetails.Engine != null && this.vinVehicleDetails.KBBEngineId!=null) {
                        let engineId: string = this.vinVehicleDetails.KBBEngineId.toString();
                        let selectedEngine = this.decodeVinVehicleDetails.Engine.find(i => i.ID == engineId);
                        if (selectedEngine != null) {
                            this.vinVehicleDetails.Engine = selectedEngine.Value;                            
                            this.vinVehicleDetails.KBBEngineId = parseInt(selectedEngine.ID);
                        }
                        else {
                            this.vinVehicleDetails.Engine = null;
                            this.vinVehicleDetails.KBBEngineId = null;                            
                        }
                    }
                    else {
                        this.vinVehicleDetails.Engine = null;
                        this.vinVehicleDetails.KBBEngineId = null;
                    }
                }
            }

            //Transmission
            if (this.decodeVinVehicleDetails.Transmission != null) {
                if (this.decodeVinVehicleDetails.Transmission.length == 1) {
                    this.vinVehicleDetails.Transmission = this.decodeVinVehicleDetails.Transmission[0].Value;                    
                    this.vinVehicleDetails.KBBTransmissionId = parseInt(this.decodeVinVehicleDetails.Transmission[0].ID);
                }
                else {
                    if (this.vinVehicleDetails.Transmission != null && this.vinVehicleDetails.KBBTransmissionId != null) {
                        let transmissionId: string = this.vinVehicleDetails.KBBTransmissionId.toString();
                        let selectedTransmission = this.decodeVinVehicleDetails.Transmission.find(i => i.ID == transmissionId);
                        if (selectedTransmission != null) {
                            this.vinVehicleDetails.Transmission = selectedTransmission.Value;
                            this.vinVehicleDetails.KBBTransmissionId = parseInt(selectedTransmission.ID);                            
                        }
                        else {
                            this.vinVehicleDetails.Transmission = null;
                            this.vinVehicleDetails.KBBTransmissionId = null;                            
                        }
                    }
                    else {
                        this.vinVehicleDetails.Transmission = null;
                        this.vinVehicleDetails.KBBTransmissionId = null;                        
                    }
                }
                
            }

            //DriveTrain 
            if (this.decodeVinVehicleDetails.DriveTrain != null) {
                if (this.decodeVinVehicleDetails.DriveTrain.length==1) {
                    this.vinVehicleDetails.DriveTrain = this.decodeVinVehicleDetails.DriveTrain[0].Value;                    
                    this.vinVehicleDetails.KBBDrivetrainId = parseInt(this.decodeVinVehicleDetails.DriveTrain[0].ID)
                }
                else {
                    if (this.vinVehicleDetails.DriveTrain != null && this.vinVehicleDetails.KBBDrivetrainId != null) {
                        let driveTrainId: string = this.vinVehicleDetails.KBBDrivetrainId.toString();
                        let selectedDriveTrain = this.decodeVinVehicleDetails.DriveTrain.find(i => i.ID == driveTrainId);
                        if (selectedDriveTrain != null) {
                            this.vinVehicleDetails.DriveTrain = selectedDriveTrain.Value;
                            this.vinVehicleDetails.KBBDrivetrainId = parseInt(selectedDriveTrain.ID);                            
                        }
                        else {
                            this.vinVehicleDetails.DriveTrain = null;
                            this.vinVehicleDetails.KBBDrivetrainId = null;                            
                        }
                    }
                    else {
                        this.vinVehicleDetails.DriveTrain = null;
                        this.vinVehicleDetails.KBBDrivetrainId = null;                        
                    }
                }

                
            }

        }



        // added for IsKbbFailure or chromedecode vehicle and not extapp vehicle
        if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data == null || this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length == 0) {
            if (!this.IsDDCVehicle) {
                this.LoadChromeDropdownData();
            }
        }

        this.persistentDecodeVehicleDetails();
        //If chrome decode vehicle and not extapp vehicle
        if (this.vinVehicleDetails.ChromeTrim != null && this.vinVehicleDetails.ChromeTrim != "") {
            if (!this.IsDDCVehicle) {
                this.kbbService.vinVehicleDetails.ChromeTrim = this.vinVehicleDetails.ChromeTrim;
                this.setChromeDropdownData(this.vinVehicleDetails.ChromeTrim);
            }
        }



        if (!this.vinVehicleDetails.IsKbbFailure) {
            this.LoadModelData();
        }

        //if ICO vehilce
        if (this.vinVehicleDetails.Model != null && !this.vinVehicleDetails.IsKbbFailure && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length > 1) {
            this.kbbService.vinVehicleDetails.Model = this.vinVehicleDetails.Model;
            this.setModels(this.vinVehicleDetails.Model, false);
        }
        //if ICO vehicle
        if ((this.vinVehicleDetails.Trim != null && !this.vinVehicleDetails.IsKbbFailure && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length > 1) || (this.initialKbbSuccessStatus != this.vinVehicleDetails.IsKbbFailure && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data != null))  {
            this.kbbService.vinVehicleDetails.Trim = this.vinVehicleDetails.Trim;
            this.prevTrimId = this.kbbService.vinVehicleDetails.KBBTrimId;
            this.setDropdownData(this.vinVehicleDetails.Trim, false);
        }

        this.persistentVehicleData();

    }

    // added for IsKbbFailure
    LoadChromeDropdownData() {
        
        if (this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.Engine.length == 1) {
            this.vinVehicleDetails.Engine = this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.Engine[0].Value;
            this.kbbService.vinVehicleDetails.Engine = this.vinVehicleDetails.Engine;
        }
        if (this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.Transmission.length == 1) {
            this.vinVehicleDetails.Transmission = this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.Transmission[0].Value;
            this.kbbService.vinVehicleDetails.Transmission = this.vinVehicleDetails.Transmission;
        }
        if (this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.DriveTrain.length == 1) {
            this.vinVehicleDetails.DriveTrain = this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails.DriveTrain[0].Value;
            this.kbbService.vinVehicleDetails.DriveTrain = this.vinVehicleDetails.DriveTrain;
        }
    }

    LoadModelData() {

        if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data != null && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length == 1) {

            this.vinVehicleDetails.KBBTrimId = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[0].trim.trimId;
            this.vinVehicleDetails.Trim = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[0].trim.displayName;
            this.vinVehicleDetails.KBBModelId = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[0].model.modelId;
            this.kbbService.vinVehicleDetails.Trim = this.vinVehicleDetails.Trim;
            this.kbbService.vinVehicleDetails.KBBTrimId = this.vinVehicleDetails.KBBTrimId;
            this.vinVehicleDetails.Model = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[0].model.displayName;
            this.kbbService.vinVehicleDetails.KBBModelId = this.vinVehicleDetails.KBBModelId;
            this.kbbService.vinVehicleDetails.Model = this.vinVehicleDetails.Model;
            this.decodeVinVehicleDetails.Series = new Array<IDValues>();
            let idValues: IDValues;
            idValues = new IDValues();
            idValues.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[0].trim.trimId.toString();
            idValues.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[0].trim.displayName;
            this.decodeVinVehicleDetails.Series[0] = idValues;


            if (this.vinVehicleDetails.KBBTrimId != null) {
                this.vehicleparams.TrimId = this.vinVehicleDetails.KBBTrimId;
                this.kbbService.vehicleParams.TrimId = this.vehicleparams.TrimId;
                this.kbbService.vinVehicleDetails.KBBTrimId = this.vinVehicleDetails.KBBTrimId;
                this.prevTrimId = this.vehicleparams.TrimId;
            }


            if (this.decodeVinVehicleDetails.Engine.length > 0) {
                this.decodeVinVehicleDetails.Engine = [];
            }
            if (this.decodeVinVehicleDetails.Transmission.length > 0) {
                this.decodeVinVehicleDetails.Transmission = [];
            }
            if (this.decodeVinVehicleDetails.DriveTrain.length > 0) {
                this.decodeVinVehicleDetails.DriveTrain = [];
            }
            if (this.decodeVinVehicleDetails.ExteriorColor.length > 0) {
                this.decodeVinVehicleDetails.ExteriorColor = [];
            }

            this.LoadDropdownData(0);
            this.LoadKbbColorDetails(this.vehicleparams.TrimId);
            //this.prevTrimId = this.vehicleparams.TrimId;
        }
        else if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data != null && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length > 1) {
            var getModelPossibilities = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length;
            this.decodeVinVehicleDetails.Model = new Array<IDValues>();
            var model;
            this.kbbModelArray = [];
            let idValue: IDValues;
            for (model = 0; model < getModelPossibilities; model++) {
                idValue = new IDValues();
                idValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[model].model.displayName;
                idValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[model].model.modelId.toString();
                this.kbbModelArray.push(idValue);
            }

            this.decodeVinVehicleDetails.Model = this.removeDuplicates(this.kbbModelArray);

            if (this.decodeVinVehicleDetails.Model.length == 1) {

                this.setModels(this.decodeVinVehicleDetails.Model[0].Value, false);
                this.vinVehicleDetails.KBBModelId = parseInt(this.decodeVinVehicleDetails.Model[0].ID);
            }

        }

    }

    removeDuplicates(arr: any) {
        var flags = [], outputArray = [], l = arr.length, i;
        for (i = 0; i < l; i++) {
            if (flags[arr[i].Value]) continue;
            flags[arr[i].Value] = true;
            outputArray.push(arr[i]);
        }
        return outputArray;
    }
    setModels(model: string, isModelChanged: boolean) {
        let modelCount = this.decodeVinVehicleDetails.Model.length;

        if (modelCount == 1) {
            this.vinVehicleDetails.Model = model;
            this.kbbService.vinVehicleDetails.Model = this.vinVehicleDetails.Model;
            this.getTrimsFromModel(isModelChanged);
            if (this.vinVehicleDetails.Trim != null && !this.vinVehicleDetails.IsKbbFailure) {
                this.kbbService.vinVehicleDetails.Trim = this.vinVehicleDetails.Trim;
                if (isModelChanged) {
                    this.kbbService.vinVehicleDetails.Transmission = null;
                    this.kbbService.vinVehicleDetails.Engine = null;
                    this.kbbService.vinVehicleDetails.DriveTrain = null;
                    this.kbbService.vinVehicleDetails.ExtColor = null;
                    this.kbbService.kbbColors = undefined;
                }
                // this.setDropdownData(null,this.vinVehicleDetails.Trim, false);
            }
        }
        else if (modelCount > 1) {
            for (var modelIndex = 0; modelIndex < modelCount; modelIndex++) {
                if (this.decodeVinVehicleDetails.Model[modelIndex].Value == model) {
                    this.vinVehicleDetails.KBBModelId = parseInt(this.decodeVinVehicleDetails.Model[modelIndex].ID);
                    this.vinVehicleDetails.Model = this.decodeVinVehicleDetails.Model[modelIndex].Value;
                    this.kbbService.vinVehicleDetails.Model = this.vinVehicleDetails.Model;
                    this.kbbService.vinVehicleDetails.KBBModelId = this.vinVehicleDetails.KBBModelId;

                    if (isModelChanged) {
                        this.kbbService.vinVehicleDetails.Transmission = null;
                        this.kbbService.vinVehicleDetails.Engine = null;
                        this.kbbService.vinVehicleDetails.DriveTrain = null;
                        this.kbbService.vinVehicleDetails.ExtColor = null;
                        this.kbbService.kbbColors = undefined;
                    }

                    this.getTrimsFromModel(isModelChanged);

                    if (this.vinVehicleDetails.Trim != null && !this.vinVehicleDetails.IsKbbFailure) {
                        this.kbbService.vinVehicleDetails.Trim = this.vinVehicleDetails.Trim;

                    }


                }
            }
        }

    }

    getTrimsFromModel(isModelChanged: boolean) {


        if (this.decodeVinVehicleDetails.ExteriorColor.length > 0) {
            this.decodeVinVehicleDetails.ExteriorColor = [];
        }
        if (this.decodeVinVehicleDetails.Engine.length > 0) {
            this.decodeVinVehicleDetails.Engine = [];
        }
        if (this.decodeVinVehicleDetails.DriveTrain.length > 0) {
            this.decodeVinVehicleDetails.DriveTrain = [];
        }
        if (this.decodeVinVehicleDetails.Transmission.length > 0) {
            this.decodeVinVehicleDetails.Transmission = [];
        }

        if (isModelChanged && this.vinVehicleDetails.Trim != null) {
            this.vinVehicleDetails.Trim = null;
        }

        this.decodeVinVehicleDetails.Series = [];
        let idValue: IDValues; let possibilityIndex;
        for (var possbility = 0; possbility < this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length; possbility++) {
            if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[possbility].model.displayName == this.vinVehicleDetails.Model) {
                idValue = new IDValues();
                idValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[possbility].trim.trimId.toString();
                idValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[possbility].trim.displayName;
                this.decodeVinVehicleDetails.Series.push(idValue);
                possibilityIndex = possbility;
            }
        }

        if (this.decodeVinVehicleDetails.Series.length == 1) {
            this.vinVehicleDetails.Trim = this.decodeVinVehicleDetails.Series[0].Value;
            this.vinVehicleDetails.KBBTrimId = parseInt(this.decodeVinVehicleDetails.Series[0].ID);
            this.kbbService.vinVehicleDetails.Trim = this.vinVehicleDetails.Trim;
            this.kbbService.vinVehicleDetails.KBBTrimId = this.vinVehicleDetails.KBBTrimId;
            this.vehicleparams.TrimId = this.vinVehicleDetails.KBBTrimId;
            this.prevTrimId = this.vehicleparams.TrimId;

            this.LoadDropdownData(possibilityIndex);



            this.LoadKbbColorDetails(this.vinVehicleDetails.KBBTrimId);

            // this.prevTrimId = this.vinVehicleDetails.KBBTrimId;
        }


    }


    LoadDropdownData(j: number) {
        var i;

        if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data != null && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines.length == 1) {
            this.vinVehicleDetails.KBBEngineId = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines[0].engineId;
            this.kbbService.vinVehicleDetails.KBBEngineId = this.vinVehicleDetails.KBBEngineId;
            this.vinVehicleDetails.Engine = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines[0].displayName;
            let IdValue: IDValues;
            IdValue = new IDValues();
            IdValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines[0].engineId.toString();
            IdValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines[0].displayName;
            this.decodeVinVehicleDetails.Engine.push(IdValue);
        }
        else {
            let engineIdValue: IDValues;
            for (i = 0; i < this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines.length; i++) {
                engineIdValue = new IDValues();
                engineIdValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines[i].engineId.toString();
                engineIdValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].engines[i].displayName;
                this.decodeVinVehicleDetails.Engine.push(engineIdValue);
            }

        }

        if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data != null && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains.length == 1) {

            this.vinVehicleDetails.KBBDrivetrainId = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains[0].drivetrainId;
            this.vinVehicleDetails.DriveTrain = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains[0].displayName;
            this.kbbService.vinVehicleDetails.KBBDrivetrainId = this.vinVehicleDetails.KBBDrivetrainId;
            let IdValue: IDValues;
            IdValue = new IDValues();
            IdValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains[0].drivetrainId.toString();
            IdValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains[0].displayName;
            this.decodeVinVehicleDetails.DriveTrain.push(IdValue);
        }
        else {
            let IdValue: IDValues;
            for (i = 0; i < this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains.length; i++) {
                IdValue = new IDValues();

                IdValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains[i].drivetrainId.toString();
                IdValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].drivetrains[i].displayName;
                this.decodeVinVehicleDetails.DriveTrain.push(IdValue);

            }
        }

        if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data != null && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions.length == 1) {
            this.vinVehicleDetails.KBBTransmissionId = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions[0].transmissionId;
            this.vinVehicleDetails.Transmission = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions[0].displayName;
            this.kbbService.vinVehicleDetails.KBBTransmissionId = this.vinVehicleDetails.KBBTransmissionId;
            let IdValue: IDValues;
            IdValue = new IDValues();
            IdValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions[0].transmissionId.toString();
            IdValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions[0].displayName;
            this.decodeVinVehicleDetails.Transmission.push(IdValue);
        }
        else {
            let IdValue: IDValues;
            for (i = 0; i < this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions.length; i++) {
                IdValue = new IDValues();
                IdValue.ID = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions[i].transmissionId.toString();
                IdValue.Value = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[j].transmissions[i].displayName;
                this.decodeVinVehicleDetails.Transmission.push(IdValue);
            }

        }


    }


    persistentVehicleData() {

        this.kbbService.setData(this.vinVehicleDetails, LinkEnum.GetVehicle);
        // this.notify.emit(this.vinVehicleDetails);
    }

    persistentDecodeVehicleDetails() {
        this.kbbService.setData(this.decodeVinVehicleDetails, LinkEnum.DecodeVin);
        //this.notifyDecodeVin.emit(this.decodeVinVehicleDetails);
    }

    persistentKbbDecodeVin() {

        this.kbbService.setData(this.decodeVinVehicleDetailsKBB, LinkEnum.DecodeVinKBB);
    }

    persistentKbbColors() {

        this.kbbService.setData(this.kbbColors, LinkEnum.GetKbbColors);

    }

    persistentVehicleLaneDetails() {
         this.kbbService.setData(this.vehicleLaneDetails, LinkEnum.VehicleLaneDetails);
    }
    setChromeDropdownData(chromeTrim) {
        let trimCount = this.decodeVinVehicleDetails.ChromeTrim.length;
        for (var trimIndex = 0; trimIndex < trimCount; trimIndex++) {
            if (this.decodeVinVehicleDetails.ChromeTrim[trimIndex].Value == chromeTrim) {

                this.vinVehicleDetails.TrimID = this.decodeVinVehicleDetails.ChromeTrim[trimIndex].ID;
                this.kbbService.vinVehicleDetails.TrimID = this.vinVehicleDetails.TrimID;
                if (this.decodeVinVehicleDetails.ChromeTrim[trimIndex].Code != undefined && this.decodeVinVehicleDetails.ChromeTrim[trimIndex].Code != null) {
                    this.vinVehicleDetails.ModelID = this.decodeVinVehicleDetails.ChromeTrim[trimIndex].Code;
                    this.kbbService.vinVehicleDetails.ModelID = this.vinVehicleDetails.ModelID;
                }
            }
        }
    }
    setDropdownData(Trim, isTrimChanged) {

        let index;
        var TrimId;
        //if (event != null) {
        //    TrimId = event.source._selectionModel._selected[0]._element.nativeElement.dataset.somedata;
        //}
        //else if (this.vinVehicleDetails.KBBTrimId != null) {
        //    TrimId = this.vinVehicleDetails.KBBTrimId;
        //}

        for (item = 0; item < this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities.length; item++) {
            if (this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[item].trim.displayName == Trim && this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[item].model.modelId == this.kbbService.vinVehicleDetails.KBBModelId) {
                TrimId = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[item].trim.trimId;
                index = item;
            }
        }

        this.vinVehicleDetails.Trim = Trim;
        this.kbbService.vinVehicleDetails.Trim = Trim;

        if (TrimId != null) {
            this.newTrimId = parseInt(TrimId);
            this.vehicleparams.TrimId = this.newTrimId;
        }

        var item;
        //for (item = 0; item < this.decodeVinVehicleDetails.Series.length; item++) {
        //    if (this.decodeVinVehicleDetails.Series[item].ID == TrimId.toString())
        //        index = item;
        //}

        if (this.decodeVinVehicleDetails.Engine.length > 0 && isTrimChanged == true) {
            this.vinVehicleDetails.Engine = null;
        }

        this.decodeVinVehicleDetails.Engine = [];
        this.vinVehicleDetails.KBBEngineId = 0;

        if (this.decodeVinVehicleDetails.Transmission.length > 0 && isTrimChanged == true) {
            this.vinVehicleDetails.Transmission = null;
        }

        if (this.decodeVinVehicleDetails.ExteriorColor.length > 0 && isTrimChanged == true) {
            this.vinVehicleDetails.ExtColor = null;
        }

        this.decodeVinVehicleDetails.Transmission = [];
        this.vinVehicleDetails.KBBTransmissionId = 0;

        if (this.decodeVinVehicleDetails.DriveTrain.length > 0 && isTrimChanged == true) {
            this.vinVehicleDetails.DriveTrain = null;
        }

        this.decodeVinVehicleDetails.DriveTrain = [];
        this.vinVehicleDetails.KBBDrivetrainId = 0;

        this.vinVehicleDetails.KBBColorId = "";
        //if (this.prevTrimId != this.newTrimId) {
        //    this.decodeVinVehicleDetails.ExteriorColor = [];
        //    this.LoadKbbColorDetails(this.newTrimId);
        //}

        if (this.decodeVinVehicleDetails.ExteriorColor.length > 0) {
            this.decodeVinVehicleDetails.ExteriorColor = [];
        }

        this.LoadKbbColorDetails(this.newTrimId);

        // this.vinVehicleDetails.Trim = Trim;
        this.kbbService.vinVehicleDetails.KBBTrimId = this.newTrimId;

        this.LoadDropdownData(index);

        //this.kbbService.vinVehicleDetails.Model = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[index].model.displayName;
        //this.vinVehicleDetails.Model = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[index].model.displayName;
        //this.kbbService.vinVehicleDetails.KBBModelId = this.decodeVinVehicleDetailsKBB.KBBVinVehicleDetails.data.possibilities[index].model.modelId;

        if (this.kbbService.vinVehicleDetails.Transmission != null) {
            this.setKBBTransmissionId(this.kbbService.vinVehicleDetails.Transmission);
        }

        if (this.kbbService.vinVehicleDetails.Engine != null) {
            this.setKBBEngineId(this.kbbService.vinVehicleDetails.Engine);
        }

        if (this.kbbService.vinVehicleDetails.DriveTrain != null) {
            this.setKBBDriveTrainId(this.kbbService.vinVehicleDetails.DriveTrain);
        }

        if (this.kbbService.vinVehicleDetails.ExtColor != null) {
            this.setKBBColor(this.kbbService.vinVehicleDetails.ExtColor);
        }

    }

    LoadKbbColorDetails(newTrim: number) {

        let cachedKbbColorDetails = this.kbbService.GetKbbColorsFromCache(this.vehicleparams);
        if (cachedKbbColorDetails != undefined && this.prevTrimId == newTrim) {
            this.kbbColors = cachedKbbColorDetails;
            let IdValue: IDValues;
            let i;
            if (newTrim == this.vinVehicleDetails.KBBTrimId) {
                if (this.kbbColors.data.length > 0) {
                    this.decodeVinVehicleDetails.ExteriorColor = [];
                    for (i = 0; i < this.kbbColors.data.length; i++) {
                        IdValue = new IDValues();
                        IdValue.ID = this.kbbColors.data[i].colorId.toString();
                        IdValue.Value = this.kbbColors.data[i].displayName;
                        this.decodeVinVehicleDetails.ExteriorColor.push(IdValue);
                    }
                }
            }
            else {
                if (this.newTrimId != undefined) {
                    this.vehicleparams.TrimId = this.newTrimId;
                }
                else {
                    this.vehicleparams.TrimId = newTrim;
                }
                this.kbbService.setVehicleParameters(this.vehicleparams);

                if (this.vinVehicleDetails.ExtColor != null) {
                    this.vinVehicleDetails.ExtColor = null;
                }
                //clearing facotry option changing trim 
                this.kbbService.setData(this.vinVehicleDetails, LinkEnum.ClearCacheFactory);
                this.GetKbbColors(this.vehicleparams);


            }
        }
        else {
            this.GetKbbColors(this.vehicleparams);

        }
    }
    //clearing recon information while changing car to truck 
    clearreconinformation() {
        this.kbbService.setData(this.vinVehicleDetails, LinkEnum.ClearCacheReconinfo);
    }
    GetKbbColors(vehicleparams: any) {
        this.busyC = this.kbbService.GetKbbColorsFromAPI(vehicleparams).subscribe(
            (result: KbbColors) => {
                this.kbbColors = result;
                let IdValue: IDValues, i;
                if (this.decodeVinVehicleDetails.ExteriorColor.length > 0) {
                    this.decodeVinVehicleDetails.ExteriorColor = [];
                }

                for (i = 0; i < this.kbbColors.data.length; i++) {
                    IdValue = new IDValues();

                    IdValue.ID = this.kbbColors.data[i].colorId.toString();
                    IdValue.Value = this.kbbColors.data[i].displayName;
                    this.decodeVinVehicleDetails.ExteriorColor.push(IdValue);

                    this.persistentKbbColors();

                }

                if (this.vinVehicleDetails.ExtColor != null) {
                    this.setKBBColor(this.vinVehicleDetails.ExtColor);
                }

                this.kbbService.KbbDecodeCompleteChange.next(true);

            });


    }

    setKBBColor(ExtColor) {
        if (this.decodeVinVehicleDetails.ExteriorColor.length == 1) {
            this.kbbService.vinVehicleDetails.KBBColorId = this.decodeVinVehicleDetails.ExteriorColor[0].ID;
            this.vinVehicleDetails.ExtColor = this.decodeVinVehicleDetails.ExteriorColor[0].Value;
            this.kbbService.vinVehicleDetails.ExtColor = this.vinVehicleDetails.ExtColor;
        }
        else {
            let selectedColor = this.decodeVinVehicleDetails.ExteriorColor.filter(function (eachColor) { return eachColor.Value == ExtColor });
            if (selectedColor != null && selectedColor.length > 0) {
                this.vinVehicleDetails.KBBColorId = selectedColor[0].ID;
                this.kbbService.vinVehicleDetails.KBBColorId = this.vinVehicleDetails.KBBColorId;
            }

        }
    }

    setKBBEngineId(Engine) {

        let selectedEngine = this.decodeVinVehicleDetails.Engine.filter(function (eachEngine) { return eachEngine.Value == Engine });
        if (selectedEngine != null && selectedEngine.length > 0) {
            this.vinVehicleDetails.KBBEngineId = parseInt(selectedEngine[0].ID);
            this.kbbService.vinVehicleDetails.Engine = Engine;
            this.kbbService.vinVehicleDetails.KBBEngineId = this.vinVehicleDetails.KBBEngineId;
        }
    }

    setKBBDriveTrainId(DriveTrain) {
        let selectedDriveTrain = this.decodeVinVehicleDetails.DriveTrain.filter(function (eachDriveTrain) { return eachDriveTrain.Value == DriveTrain });
        if (selectedDriveTrain != null && selectedDriveTrain.length > 0) {
            this.vinVehicleDetails.KBBDrivetrainId = parseInt(selectedDriveTrain[0].ID);
            this.kbbService.vinVehicleDetails.DriveTrain = DriveTrain;
            this.kbbService.vinVehicleDetails.KBBDrivetrainId = this.vinVehicleDetails.KBBDrivetrainId;
        }

    }


    setKBBTransmissionId(Transmission) {
        let selectedTransmission = this.decodeVinVehicleDetails.Transmission.filter(function (eachTransmission) { return eachTransmission.Value == Transmission });
        if (selectedTransmission != null && selectedTransmission.length > 0) {
            this.vinVehicleDetails.KBBTransmissionId = parseInt(selectedTransmission[0].ID);
            this.kbbService.vinVehicleDetails.Transmission = Transmission;
            this.kbbService.vinVehicleDetails.KBBTransmissionId = this.vinVehicleDetails.KBBTransmissionId;
        }

    }

    open(content, options: NgbModalOptions = { backdrop: 'static', keyboard: false }) {
        this.modalService.open(content, options);
    }
    validateForm() {
        //Check for valid form
        let vehForm = document.getElementById('VehicleInfoForm');
        if (vehForm.classList.contains('ng-invalid')) {
            this.vehFormInvalid = true;
        } else {
            this.vehFormInvalid = false;
        }

        let mileageField = document.getElementById('txtMileage');
        let mileageFieldValue = (<HTMLInputElement>document.getElementById("txtMileage")).value;
        //if (this.vinVehicleDetails.Mileage == null) {
        //    mileageField.className += ' ng-invalid';
        //}
        if (mileageFieldValue == '' || mileageFieldValue == undefined) {
            this.kbbService.vinVehicleDetails.Mileage = null;
            this.mileageInvalid = true;
            this.vehFormInvalid = true;
        } else {
            this.mileageInvalid = false;
            // this.vehFormInvalid = false;
        }
    }
    
    updateMileageField(mileage: any) {
        var mileageValue = +mileage;
        var actualNum = mileage.replace(',', '');
        if (mileageValue == 0) {
            this.mileageInvalid = true;
            this.htmlMileageElement.value = '';
            this.htmlMileageElement.className += " ng-Invalid";
            this.vinVehicleDetails.Mileage = null;
            return false;
        }
        if (actualNum == "" || +actualNum == 0) {
            this.mileageInvalid = true;
            this.vinVehicleDetails.Mileage = null;
            this.kbbService.vinVehicleDetails.Mileage = null;
        }
        else if (actualNum != null && actualNum != '') {
            var num = '';
            if (actualNum.length <= 6) {
                num = actualNum;
            }
            else if (actualNum.length > 6) {
                num = actualNum.substring(0, actualNum.length - 1);
            }

            this.kbbService.vinVehicleDetails.Mileage = +num;
        }

        else
            this.kbbService.vinVehicleDetails.Mileage = null;
    }

    saveVehicleInfo(flag: string) {

        if (flag != 'fullpage') {
            this.validateForm();
        }

        //IF form is valid 
        if (!this.vehFormInvalid) {

            // added for IsKbbFailure
            if (!this.kbbService.vehicleParams.IsKbbFailure) {
                this.prospectparams.modelId = this.kbbService.vinVehicleDetails.KBBModelId;
                this.prospectparams.makeId = this.kbbService.vinVehicleDetails.KBBMakeId;
                this.prospectparams.yearId = this.kbbService.vinVehicleDetails.Year;
                this.prospectparams.transmissionId = this.kbbService.vinVehicleDetails.KBBTransmissionId;
                this.prospectparams.engineId = this.kbbService.vinVehicleDetails.KBBEngineId;
                this.prospectparams.drivetrainId = this.kbbService.vinVehicleDetails.KBBDrivetrainId;
                this.prospectparams.trimId = this.kbbService.vinVehicleDetails.KBBTrimId;
                this.prospectparams.colorId = parseInt(this.kbbService.vinVehicleDetails.KBBColorId);
                this.prospectparams.vin = this.kbbService.vinVehicleDetails.VIN;
                this.prospectparams.mileage = this.kbbService.vinVehicleDetails.Mileage;
                this.prospectparams.dealerId = 54603407;
                this.prospectparams.currStoreId = this.kbbService.vehicleParams.CurrStoreID;

                let prospectbody = JSON.stringify(this.prospectparams);
                this.kbbService.GetProspectFromAPI(prospectbody).subscribe(
                    result => {
                        if (this.editMode == true) {
                            Close(0);
                        }
                        this.vinVehicleDetails.ProspectId = result;
                        this.kbbService.vehicleParams.ProspectId = result;
                        this.kbbService.IsProspectIdExistsChange.next(true);
                    },
                    (error: Response | any) => this.errorHandler.handleError(error));

            }
            if (this.kbbService.vinVehicleDetails.VehicleType != null) {
                this.kbbService.vinVehicleDetails.DMVClassification = this.kbbService.vinVehicleDetails.VehicleType;
                this.kbbService.vinVehicleDetails.DMVType = this.kbbService.vinVehicleDetails.VehicleType;
                this.kbbService.vinVehicleDetails.Classification = this.kbbService.vinVehicleDetails.VehicleType;
            }
            this.kbbService.vinVehicleDetails.IsKbbVehicle = true;
            this.body = JSON.stringify(this.kbbService.vinVehicleDetails);

            // in edit mode check sacstatus
            if (this.editMode == true && this.SACStatusID == 403 && this.isCCAVehicle == true) {
                let options: NgbModalOptions = { backdrop: 'static', keyboard: false, windowClass: 'custom-modals' }
                this.modalService.open(this.resubmitpopup, options);
                return false;
            }
            else {
                this.SaveDataToDB();
                return true;                
            }
        }
    }

    setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    private SaveDataToDB() {
        this.kbbService.SaveVehicleDetails(this.body).subscribe(
            result => {                
                this.Saved(result);
            },
            (error: Response | any) => this.errorHandler.handleError(error));
    }

    Saved(data) {
        //Data saved sucessfully.
        //Add after save stuffs here.
        if (this.editMode == true && this.kbbService.vehicleParams.IsKbbFailure) {
            if (this.reqResubmit) {
                this.kbbService.ResubmitSACRecord(this.vehicleparams, LinkEnum.ResubmitSACRecord).subscribe(
                    (result: SIMSResponseData) => result,
                    (error: Response | any) => this.errorHandler.handleError(error));
            }
            else if (this.SACStatusID == 403 && this.isCCAVehicle == true) {
                this.setCookie("IsResubmit-" + this.kbbService.vehicleParams.VehicleId + "-" +
                    this.kbbService.vehicleParams.StoreId + "-" +
                    this.kbbService.vehicleParams.InventoryId, 1, 1);
            }
            Close(0);
        }
    }

    
    //Resubmit changes
    ResubmitYes() {
        this.reqResubmit=true;
        this.SaveDataToDB();        
        return true;
    }

    closeLane() {
        this.showlanepopup = false;
        this.isMiddleDivVisible = true;
    }
    SaveLaneDetails(vehicleLaneDetails: any) {
        
        this.showlanepopup = false;
        this.isMiddleDivVisible = true;
        //let laneDetails = JSON.stringify(this.kbbService.vehicleLaneDetails);
        this.vehicleLaneDetails.LaneId = vehicleLaneDetails.LaneId;
        this.vehicleparams = this.kbbService.getVehicleParameters();
        this.vehicleLaneDetails.vin = this.vehicleparams.VIN;
        this.vehicleLaneDetails.storeId = this.vehicleparams.StoreId;
        this.vehicleLaneDetails.vehicleId = this.vehicleparams.VehicleId;
        this.vehicleLaneDetails.invtrId = this.vehicleparams.InventoryId;
        this.vehicleLaneDetails.firstName = this.vehicleparams.UserName;
        this.vehicleparams.Kiosk_Req = "NO";
        this.kbbService.SaveVehicleLaneDetails(vehicleLaneDetails).subscribe(
            result => result,
            (error: Response | any) => this.errorHandler.handleError(error));
    }

    disableNavigationMenu() {
        let wizardClasess: any = document.getElementsByClassName('wizard-step');
        if (wizardClasess != undefined || wizardClasess != null) {
            let wizardLength: number = wizardClasess.length;
            for (var i = 2; i <= wizardLength; i++) {
                let wizard: any = document.getElementById('wizardStep' + i);
                let wizardStep: any = wizard.getElementsByTagName('polygon')[0];
                wizardStep.classList = '';
            }
            this.kbbService.isWizardStep.next(true);
        }
    }

    //Edit Vehicle full page save changes starts here
    vinVehicleDetailsDummy: Vehicle;
    hdMessage: string = null;
    explanation: string = null;
    
    flag: string = null;
    hdnisGraphic: number;//if hdnisGraphic==1 or hdnisGraphic==2
    SeriesTrim: string;
    VehicleType: string;
    Mileage: number;
    ChromeTrim: string;
    saveFromEditPage(content) {

        this.hdnisGraphic = parseInt((<HTMLInputElement>document.getElementById("hdnisGraphic")).value);
        this.validateForm();
        let options: NgbModalOptions = { backdrop: 'static', keyboard: false }
        if (!this.vehFormInvalid) {
            if (this.hdnisGraphic == 1 || this.hdnisGraphic == 2) {
                //Need to confirm wheather KBBTrimId is same as Series/trim
                if ((this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || this.KbbSeriesTrimId != this.kbbService.vinVehicleDetails.KBBTrimId || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure)) ||
                    this.Mileage != this.kbbService.vinVehicleDetails.Mileage ||
                    this.VehicleType != this.kbbService.vinVehicleDetails.VehicleType) {
                    if ((this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || this.KbbSeriesTrimId != this.kbbService.vinVehicleDetails.KBBTrimId || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure)) &&
                        this.Mileage != this.kbbService.vinVehicleDetails.Mileage &&
                        this.VehicleType != this.kbbService.vinVehicleDetails.VehicleType) {
                        //Factory, Books and Recon values needs to be reentered.

                        this.hdMessage = "Confirm Series/Trim, Mileage and Vehicletype Changes";
                        this.explanation = "Series/Trim, Mileage and Vehicle Type information have been changed. Please edit the  factory options, book values and Recon information.Click Ok to continue.";
                        this.flag = 'book,factory,recon';
                        //show modal method call
                        this.modalService.open(content, options);

                    }
                    else if ((this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || this.KbbSeriesTrimId != this.kbbService.vinVehicleDetails.KBBTrimId || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure)) &&
                        this.Mileage != this.kbbService.vinVehicleDetails.Mileage) {
                        //Factory and Books  values needs to be reentered.
                        this.hdMessage = "Confirm Series/Trim and Mileage Changes";
                        this.explanation = "Series/Trim and Mileage information has been changed.Please edit the  factory options and book values.Click Ok to continue.";
                        this.flag = 'book,factory';
                        //show modal method call
                        this.modalService.open(content, options);

                    }

                    else if ((this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || this.KbbSeriesTrimId != this.kbbService.vinVehicleDetails.KBBTrimId || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure)) &&
                        this.VehicleType != this.kbbService.vinVehicleDetails.VehicleType) {
                        //Factory, Books and Recon values needs to be reentered.
                        this.hdMessage = "Confirm Series/Trim and Vehicle type Changes";
                        this.explanation = "Series / Trim and Vehicle Type information has been changed. Please edit the factory options, book values and Recon information.Click Ok to continue.";
                        this.flag = 'book,factory,recon';
                        //show modal method call
                        this.modalService.open(content, options);

                    }

                    else if (this.VehicleType != this.kbbService.vinVehicleDetails.VehicleType &&
                        this.Mileage != this.kbbService.vinVehicleDetails.Mileage) {
                        //Books and Recon values needs to be reentered.
                        this.hdMessage = "Mileage and Vehicle type Changes";
                        this.explanation = "Mileage and Vehicle Type information has been changed. Plese edit the book values and Recon information.Click Ok to continue.";
                        this.flag = 'book,recon';
                        //show modal method call
                        this.modalService.open(content, options);
                    }

                    else if (this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || this.KbbSeriesTrimId != this.kbbService.vinVehicleDetails.KBBTrimId || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure)) {
                        // Books and Factory values needs to be reentered.
                        this.hdMessage = "Confirm Series/Trim Changes";
                        this.explanation = "Series/ Trim information has been changed.Please edit the factory options and book values.Click Ok to continue.";
                        this.flag = 'book,factory';
                        this.modalService.open(content, options);
                        //show modal method call
                    }
                    else if (this.Mileage != this.kbbService.vinVehicleDetails.Mileage) {
                        // Books values needs to be reentered.
                        this.hdMessage = "Confirm Mileage Changes";
                        this.explanation = "Mileage information has been changed. Please edit the book values.Click Ok to continue.";
                        this.flag = 'book';
                        
                        this.modalService.open(content, options);
                        //show modal method call

                    }

                    else if (this.VehicleType != this.kbbService.vinVehicleDetails.VehicleType) {
                        // Recon values needs to be reentered.
                        this.hdMessage = "Confirm Vehicle Type Changes";
                        this.explanation = "Vehicle Type information has been changed.Please edit the Recon information.Click Ok to continue.";
                        this.flag = 'recon';
                        this.modalService.open(content, options);
                        //show modal method call

                    }

                }
                else {
                    this.saveVehicleInfo('fullpage');
                }
            }
            else {
                if (this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || this.KbbSeriesTrimId != this.kbbService.vinVehicleDetails.KBBTrimId || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure) || this.Mileage != this.kbbService.vinVehicleDetails.Mileage) {
                    if ((this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure)) &&
                        this.Mileage != this.kbbService.vinVehicleDetails.Mileage) {
                        //Factory and Books  values needs to be reentered.
                        this.hdMessage = "Confirm Series/Trim and Mileage Changes";
                        this.explanation = "Series/Trim and Mileage information has been changed.Please edit the factory options and book values.Click Ok to continue.";
                        this.flag = 'book,factory';
                        //show modal method call
                        this.modalService.open(content, options);
                    }
                    else if (this.SeriesTrim != this.kbbService.vinVehicleDetails.Trim || this.KbbSeriesTrimId != this.kbbService.vinVehicleDetails.KBBTrimId || (this.ChromeTrim != this.kbbService.vinVehicleDetails.ChromeTrim && this.kbbService.vehicleParams.IsKbbFailure)) {
                        // Books and Factory values needs to be reentered.
                        this.explanation = "Series/ Trim information has been changed.Please edit the factory options and book values.Click Ok to continue.";
                        this.hdMessage = "Confirm Series/Trim Changes";
                        this.flag = 'book,factory';
                        //show modal method call
                        this.modalService.open(content, options);
                    }
                    else if (this.Mileage != this.kbbService.vinVehicleDetails.Mileage) {
                        // Books values needs to be reentered.
                        this.hdMessage = "Confirm Mileage Changes";
                        this.explanation = "Mileage information has been changed.Please edit the book values.Click Ok to continue.";
                        this.flag = 'book';
                        //show modal method call
                        this.modalService.open(content, options);
                    }
                }
                else {
                    this.saveVehicleInfo('fullpage');
                }
            }
        }
    }

    Redirect() {

      
        this.saveVehicleInfo('fullpage');

        //call the javascript function to show the panel from the parent page;
    }
    //Ends Here

    getHeight() {
        if (this.decodeVinVehicleDetails.Series != null && this.decodeVinVehicleDetails.Series.length == 1 || this.decodeVinVehicleDetails.DriveTrain != null && this.decodeVinVehicleDetails.DriveTrain.length == 1 ||
            this.decodeVinVehicleDetails.Transmission != null && this.decodeVinVehicleDetails.Transmission.length == 1 || this.decodeVinVehicleDetails.Engine != null && this.decodeVinVehicleDetails.Engine.length == 1 || this.vinVehicleDetails.Mileage != null) {
            return "32px";
        }
    }

    updatePayoff(value: any) {
        var payoffValue = +value;
        if (payoffValue == 0) {
            this.vinVehicleDetails.Payoff = null;
            return false;
        }

        if (value != null && value != "") {
            var num = value.replace(/,/g, '');
            this.kbbService.vinVehicleDetails.Payoff = +num;
        }
        else {
            this.kbbService.vinVehicleDetails.Payoff = null;
        }

    }

    onKey(event: any) { // without type info

        if (this.isPayoffKeyPressed)
            event.preventDefault();
        this.isPayoffKeyPressed = true;

        let charCode;
        charCode = (event.which) ? event.which : event.keyCode;
        if ((charCode != 46 && charCode > 31
            && (charCode < 48 || charCode > 57)) || charCode == 13 || charCode == 46) {
            return false;
        }

        var numPayoffKey = parseInt(event.key);
        this.enteredPayoffValue += numPayoffKey;
        var vinpayOffValue = (<HTMLInputElement>document.getElementById("txtPayoff")).value;

        if (this.enteredPayoffValue == 0) {
            this.vinVehicleDetails.Payoff = null;
            return false;
        }
        return true;


    }


    onKeyUpEvent(event: any) {
        this.isPayoffKeyPressed = false;
        event = event || window.event;
        this.whoPayoff = event.target || event.srcElement, this.tempPayoff;
        if (this.whoPayoff != null && this.whoPayoff != undefined) {
            this.tempPayoff = this.validDigits(this.whoPayoff.value);
            this.whoPayoff.value = this.addCommas(this.tempPayoff);
        }
        this.updatePayoff(event.currentTarget.value);
    }

    onBlurEvent() {
        if (this.htmlPayoffElement != undefined && this.htmlPayoffElement != null) {
            this.temp1Payoff = parseFloat(this.validDigits(this.htmlPayoffElement.value));
            if (this.temp1Payoff) this.htmlPayoffElement.value = this.addCommas(this.temp1Payoff);
        }

        this.updatePayoff(this.htmlPayoffElement.value);
    }
    //validateMileage(event)
    //{
    //    if (!this.vehicleparams.IsKbbFailure) {
    //        let mileage = event.currentTarget.value.replace(",", "");
    //        let matFormField = document.querySelector("#milage mat-form-field");
    //        if (mileage != '' && mileage != null) {
    //            if (parseInt(mileage) > this.vehicleparams.KBBMileageLimit) {
    //                event.currentTarget.value = '';
    //                matFormField.classList.add("ng-invalid", "mat-input-invalid", "mat-form-field-invalid");
    //                matFormField.classList.remove("ng-valid");

    //                event.currentTarget.classList.remove("ng-valid");
    //                event.currentTarget.classList.add("ng-invalid");
    //                this.open(this.mileageModal);
    //            }
    //            else {
    //                matFormField.classList.remove("ng-invalid", "mat-input-invalid", "mat-form-field-invalid");
    //                matFormField.classList.add("ng-valid");

    //                event.currentTarget.classList.add("ng-valid");
    //                event.currentTarget.classList.remove("ng-invalid");
    //            }
    //        }
    //    }
    //}

    // Remove ICO EXT vehicle changes
    //year change
    GetKBBMakes(year) {
        //reset the decoded and vehicle objects 
        this.KBBvaluationData.make = null;
        this.KBBvaluationData.model = null;
        this.KBBvaluationData.series = null;
        this.KBBvaluationData.Engine = null;
        this.KBBvaluationData.Transmission = null;
        this.KBBvaluationData.DriveTrain = null;

        let tempYear: IDValues;
        tempYear = new IDValues();
        tempYear.ID = year;
        tempYear.Value = year;
        this.KBBvaluationData.Year = JSON.parse(JSON.stringify(tempYear));

        this.bookValueRequestPost.dealerId = this.decodeVinVehicleDetails.DealerId;
        this.bookValueRequestPost.RegionId = this.decodeVinVehicleDetails.RegionId;
        this.bookValueRequestPost.ProviderID = this.decodeVinVehicleDetails.ProviderId;
        this.bookValueRequestPost.valuationData = this.KBBvaluationData;

        this.kbbService.GetKBBMakesFromVI(this.bookValueRequestPost).subscribe(
            (result: SIMSResponseData) => {
                this.decodeVinVehicleDetails.Make = JSON.parse(JSON.stringify(result));

                if (this.decodeVinVehicleDetails.Make.length == 1) {
                    this.vinVehicleDetails.Make = this.decodeVinVehicleDetails.Make[0].Value;
                    this.vinVehicleDetails.MakeID = this.decodeVinVehicleDetails.Make[0].ID;
                    this.GetKBBModels(this.vinVehicleDetails.MakeID, year);
                }
                else {
                    //reverting the selected values of make               
                    this.vinVehicleDetails.Make = null;
                    this.vinVehicleDetails.MakeID = null;

                    // reset other dropdown
                    //model
                    this.vinVehicleDetails.Model = null;
                    this.vinVehicleDetails.ModelID = null;
                    this.decodeVinVehicleDetails.Model = null;
                    //series
                    this.vinVehicleDetails.TrimID = null;
                    this.vinVehicleDetails.Trim = null;
                    this.kbbService.vinVehicleDetails.TrimID = null;
                    this.vinVehicleDetails.ChromeTrim = null;
                    this.kbbService.vinVehicleDetails.ChromeTrim = null;
                    this.decodeVinVehicleDetails.Series = null;
                    this.decodeVinVehicleDetails.ChromeTrim = null;
                    this.vinVehicleDetails.KBBTrimId = 0;
                    this.kbbService.vinVehicleDetails.KBBTrimId = this.vinVehicleDetails.KBBTrimId; 
                    //engine
                    this.vinVehicleDetails.Engine = null;
                    this.vinVehicleDetails.KBBEngineId = 0;
                    this.kbbService.vinVehicleDetails.KBBEngineId = this.vinVehicleDetails.KBBEngineId;
                    this.decodeVinVehicleDetails.Engine = null;
                    //transmission
                    this.vinVehicleDetails.Transmission = null;
                    this.vinVehicleDetails.KBBTransmissionId = 0;
                    this.kbbService.vinVehicleDetails.Transmission = null;
                    this.kbbService.vinVehicleDetails.KBBTransmissionId = this.vinVehicleDetails.KBBTransmissionId;
                    this.decodeVinVehicleDetails.Transmission = null;
                    //drivetrain
                    this.vinVehicleDetails.DriveTrain = null;
                    this.vinVehicleDetails.KBBDrivetrainId = 0;
                    this.kbbService.vinVehicleDetails.DriveTrain = null;
                    this.kbbService.vinVehicleDetails.KBBDrivetrainId = this.vinVehicleDetails.KBBDrivetrainId;
                    this.decodeVinVehicleDetails.DriveTrain = null;
                }

                this.persistentDecodeVehicleDetails();
                this.persistentVehicleData();
            },
            (error: Response | any) => this.errorHandler.handleError(error));

    }

    // make change
    GetKBBModels(makeid, year) {
        //reset the decoded and vehicle objects 
        this.KBBvaluationData.make = null;
        this.KBBvaluationData.model = null;
        this.KBBvaluationData.series = null;
        this.KBBvaluationData.Engine = null;
        this.KBBvaluationData.Transmission = null;
        this.KBBvaluationData.DriveTrain = null;

        //year passing
        let tempYear: IDValues;
        tempYear = new IDValues();
        tempYear.ID = year;
        tempYear.Value = year;
        this.KBBvaluationData.Year = JSON.parse(JSON.stringify(tempYear));

        //make passing
        let tempMake: IDValues;
        tempMake = new IDValues();
        tempMake.ID = makeid;
        tempMake.Value = "";
        this.KBBvaluationData.make = JSON.parse(JSON.stringify(tempMake));

        this.bookValueRequestPost.dealerId = this.decodeVinVehicleDetails.DealerId;
        this.bookValueRequestPost.RegionId = this.decodeVinVehicleDetails.RegionId;
        this.bookValueRequestPost.ProviderID = this.decodeVinVehicleDetails.ProviderId;
        this.bookValueRequestPost.valuationData = this.KBBvaluationData;

        this.kbbService.GetKBBModelsFromVI(this.bookValueRequestPost).subscribe(
            (result: SIMSResponseData) => {
                //setting the make
                //this.vinVehicleDetails.MakeID
                let selectedMake = this.decodeVinVehicleDetails.Make.find(i => i.ID === makeid);
                this.vinVehicleDetails.Make = selectedMake.Value;
                this.vinVehicleDetails.MakeID = makeid;

                //reload model 
                this.decodeVinVehicleDetails.Model = JSON.parse(JSON.stringify(result));

                if (this.decodeVinVehicleDetails.Model.length == 1) {
                    this.vinVehicleDetails.Model = this.decodeVinVehicleDetails.Model[0].Value;
                    this.vinVehicleDetails.ModelID = this.decodeVinVehicleDetails.Model[0].ID;
                    this.GetKBBTrims(this.vinVehicleDetails.ModelID, year);
                }
                else {
                    //reverting the selected values of model
                    this.vinVehicleDetails.Model = null;
                    this.vinVehicleDetails.ModelID = null;

                    // reset other dropdown                                
                    //series
                    this.vinVehicleDetails.TrimID = null;
                    this.vinVehicleDetails.Trim = null;
                    this.kbbService.vinVehicleDetails.TrimID = null;
                    this.vinVehicleDetails.ChromeTrim = null;
                    this.kbbService.vinVehicleDetails.ChromeTrim = null;
                    this.decodeVinVehicleDetails.Series = null;
                    this.decodeVinVehicleDetails.ChromeTrim = null;
                    //engine
                    this.vinVehicleDetails.Engine = null;
                    this.vinVehicleDetails.KBBEngineId = 0;
                    this.kbbService.vinVehicleDetails.KBBEngineId = this.vinVehicleDetails.KBBEngineId;
                    this.decodeVinVehicleDetails.Engine = null;
                    //transmission
                    this.vinVehicleDetails.Transmission = null;
                    this.vinVehicleDetails.KBBTransmissionId = 0;
                    this.kbbService.vinVehicleDetails.Transmission = null;
                    this.kbbService.vinVehicleDetails.KBBTransmissionId = this.vinVehicleDetails.KBBTransmissionId;
                    this.decodeVinVehicleDetails.Transmission = null;
                    //drivetrain
                    this.vinVehicleDetails.DriveTrain = null;
                    this.vinVehicleDetails.KBBDrivetrainId = 0;
                    this.kbbService.vinVehicleDetails.DriveTrain = null;
                    this.kbbService.vinVehicleDetails.KBBDrivetrainId = this.vinVehicleDetails.KBBDrivetrainId;
                    this.decodeVinVehicleDetails.DriveTrain = null;
                }

                this.persistentDecodeVehicleDetails();
                this.persistentVehicleData();
            },
            (error: Response | any) => this.errorHandler.handleError(error));

    }

    //model chage
    GetKBBTrims(modelid, year) {
        //reset the decoded and vehicle objects 
        this.KBBvaluationData.make = null;
        this.KBBvaluationData.model = null;
        this.KBBvaluationData.series = null;
        this.KBBvaluationData.Engine = null;
        this.KBBvaluationData.Transmission = null;
        this.KBBvaluationData.DriveTrain = null;

        // pass both make and year
        let tempYear: IDValues;
        tempYear = new IDValues();
        tempYear.ID = year;
        tempYear.Value = year;
        this.KBBvaluationData.Year = JSON.parse(JSON.stringify(tempYear));

        let tempModel: IDValues;
        tempModel = new IDValues();
        tempModel.ID = modelid;
        tempModel.Value = "";
        this.KBBvaluationData.model = JSON.parse(JSON.stringify(tempModel));

        this.bookValueRequestPost.dealerId = this.decodeVinVehicleDetails.DealerId;
        this.bookValueRequestPost.RegionId = this.decodeVinVehicleDetails.RegionId;
        this.bookValueRequestPost.ProviderID = this.decodeVinVehicleDetails.ProviderId;
        this.bookValueRequestPost.valuationData = this.KBBvaluationData;

        this.kbbService.GetKBBTrimsFromVI(this.bookValueRequestPost).subscribe(
            (result: SIMSResponseData) => {
                //setting the model                
                let selectedModel = this.decodeVinVehicleDetails.Model.find(i => i.ID === modelid);
                this.vinVehicleDetails.Model = selectedModel.Value;                
                this.vinVehicleDetails.ModelID = selectedModel.ID;
                this.vinVehicleDetails.KBBModelId = parseInt(this.vinVehicleDetails.ModelID);
                this.kbbService.vinVehicleDetails.Model = this.vinVehicleDetails.Model;
                this.kbbService.vinVehicleDetails.ModelID = this.vinVehicleDetails.ModelID;
                this.kbbService.vinVehicleDetails.KBBModelId = this.vinVehicleDetails.KBBModelId;

              
                //reload series
                this.decodeVinVehicleDetails.Series = JSON.parse(JSON.stringify(result));
                this.decodeVinVehicleDetails.ChromeTrim = JSON.parse(JSON.stringify(result));

                if (this.decodeVinVehicleDetails.ChromeTrim.length == 1) {
                    this.vinVehicleDetails.TrimID = this.decodeVinVehicleDetails.ChromeTrim[0].ID;
                    this.vinVehicleDetails.Trim = this.decodeVinVehicleDetails.ChromeTrim[0].Value
                    this.kbbService.vinVehicleDetails.TrimID = this.vinVehicleDetails.TrimID;
                    this.vinVehicleDetails.ChromeTrim = this.vinVehicleDetails.Trim;
                    this.kbbService.vinVehicleDetails.ChromeTrim = this.vinVehicleDetails.Trim;
                    this.vinVehicleDetails.KBBTrimId = parseInt(this.vinVehicleDetails.Trim);
                    this.kbbService.vinVehicleDetails.KBBTrimId = this.vinVehicleDetails.KBBTrimId;                    
                    this.GetKBB_Eng_Tran_DrvTra(this.vinVehicleDetails.TrimID);
                }
                else {
                    // reset other dropdown                                
                    //series
                    this.vinVehicleDetails.TrimID = null;
                    this.vinVehicleDetails.Trim = null;
                    this.kbbService.vinVehicleDetails.TrimID = null;
                    this.vinVehicleDetails.ChromeTrim = null;
                    this.kbbService.vinVehicleDetails.ChromeTrim = null;
                    //engine
                    this.vinVehicleDetails.Engine = null;
                    this.vinVehicleDetails.KBBEngineId = 0;
                    this.kbbService.vinVehicleDetails.KBBEngineId = this.vinVehicleDetails.KBBEngineId;
                    this.decodeVinVehicleDetails.Engine = null;
                    //transmission
                    this.vinVehicleDetails.Transmission = null;
                    this.vinVehicleDetails.KBBTransmissionId = 0;
                    this.kbbService.vinVehicleDetails.Transmission = null;
                    this.kbbService.vinVehicleDetails.KBBTransmissionId = this.vinVehicleDetails.KBBTransmissionId;
                    this.decodeVinVehicleDetails.Transmission = null;
                    //drivetrain
                    this.vinVehicleDetails.DriveTrain = null;
                    this.vinVehicleDetails.KBBDrivetrainId = 0;
                    this.kbbService.vinVehicleDetails.DriveTrain = null;
                    this.kbbService.vinVehicleDetails.KBBDrivetrainId = this.vinVehicleDetails.KBBDrivetrainId;
                    this.decodeVinVehicleDetails.DriveTrain = null;
                }

                this.persistentDecodeVehicleDetails();
                this.persistentVehicleData();
            },
            (error: Response | any) => this.errorHandler.handleError(error));

    }

    //series /Trim changed
    GetKBB_Eng_Tran_DrvTra(trimId) {
        //reset the decoded and vehicle objects 
        this.KBBvaluationData.make = null;
        this.KBBvaluationData.model = null;
        this.KBBvaluationData.series = null;
        this.KBBvaluationData.Engine = null;
        this.KBBvaluationData.Transmission = null;
        this.KBBvaluationData.DriveTrain = null;

        //pass series
        let tempSeries: IDValues;
        tempSeries = new IDValues();
        tempSeries.ID = trimId;
        tempSeries.Value = "";
        this.KBBvaluationData.series = JSON.parse(JSON.stringify(tempSeries));

        this.bookValueRequestPost.dealerId = this.decodeVinVehicleDetails.DealerId;
        this.bookValueRequestPost.RegionId = this.decodeVinVehicleDetails.RegionId;
        this.bookValueRequestPost.ProviderID = this.decodeVinVehicleDetails.ProviderId;
        this.bookValueRequestPost.valuationData = this.KBBvaluationData;

        this.kbbService.GetKBB_Eng_Tran_DrvTraFromVI(this.bookValueRequestPost).subscribe(
            (result: SIMSResponseData) => {

                //setting the series/Trim    
                
                let selectedSeries = this.decodeVinVehicleDetails.ChromeTrim.find(i => i.ID === trimId);
                this.vinVehicleDetails.ChromeTrim = selectedSeries.Value;                
                this.vinVehicleDetails.Trim = selectedSeries.Value;                
                this.vinVehicleDetails.TrimID = selectedSeries.ID;                                                
                this.vinVehicleDetails.KBBTrimId = parseInt(this.vinVehicleDetails.TrimID);                
                //clearing KBB Factory option data because KBB factory options depending on Series trim
                this.kbbService.setData(this.vinVehicleDetails, LinkEnum.ClearCacheFactory);
                //reload engine,transmission and drivetrain
                let res = JSON.parse(JSON.stringify(result));
                this.decodeVinVehicleDetails.Engine = JSON.parse(JSON.stringify(res.Engine));
                this.decodeVinVehicleDetails.DriveTrain = JSON.parse(JSON.stringify(res.DriveTrain));
                this.decodeVinVehicleDetails.Transmission = JSON.parse(JSON.stringify(res.Transmission));

                // reset the values                              
                //engine
                if (this.decodeVinVehicleDetails.Engine.length == 1) {
                    this.vinVehicleDetails.Engine = this.decodeVinVehicleDetails.Engine[0].Value;
                    this.vinVehicleDetails.KBBEngineId = parseInt(this.decodeVinVehicleDetails.Engine[0].ID);
                    this.kbbService.vinVehicleDetails.KBBEngineId = this.vinVehicleDetails.KBBEngineId;
                }
                else {
                    this.vinVehicleDetails.Engine = null;
                    this.vinVehicleDetails.KBBEngineId = 0;
                    this.kbbService.vinVehicleDetails.KBBEngineId = this.vinVehicleDetails.KBBEngineId;
                }

                //transmission
                if (this.decodeVinVehicleDetails.Transmission.length == 1) {
                    this.vinVehicleDetails.Transmission = this.decodeVinVehicleDetails.Transmission[0].Value;
                    this.vinVehicleDetails.KBBTransmissionId = parseInt(this.decodeVinVehicleDetails.Transmission[0].ID);
                    this.kbbService.vinVehicleDetails.Transmission = this.vinVehicleDetails.Transmission;
                    this.kbbService.vinVehicleDetails.KBBTransmissionId = this.vinVehicleDetails.KBBTransmissionId;
                }
                else {
                    this.vinVehicleDetails.Transmission = null;
                    this.vinVehicleDetails.KBBTransmissionId = 0;
                    this.kbbService.vinVehicleDetails.Transmission = null;
                    this.kbbService.vinVehicleDetails.KBBTransmissionId = this.vinVehicleDetails.KBBTransmissionId;
                }
                //drivetrain
                if (this.decodeVinVehicleDetails.DriveTrain.length == 1) {
                    this.vinVehicleDetails.DriveTrain = this.decodeVinVehicleDetails.DriveTrain[0].Value;
                    this.vinVehicleDetails.KBBDrivetrainId = parseInt(this.decodeVinVehicleDetails.DriveTrain[0].ID);
                    this.kbbService.vinVehicleDetails.DriveTrain = this.vinVehicleDetails.DriveTrain;
                    this.kbbService.vinVehicleDetails.KBBDrivetrainId = this.vinVehicleDetails.KBBDrivetrainId;
                }
                else {
                    this.vinVehicleDetails.DriveTrain = null;
                    this.vinVehicleDetails.KBBDrivetrainId = 0;
                    this.kbbService.vinVehicleDetails.DriveTrain = null;
                    this.kbbService.vinVehicleDetails.KBBDrivetrainId = this.vinVehicleDetails.KBBDrivetrainId;
                }

                this.persistentDecodeVehicleDetails();
                this.persistentVehicleData();

            },
            (error: Response | any) => this.errorHandler.handleError(error));

    }

}
