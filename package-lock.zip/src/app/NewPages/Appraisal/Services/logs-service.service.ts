import { Injectable } from '@angular/core';
import { Response, Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
@Injectable()
export class LogsServiceService {
    constructor(private _http:  HttpClient) { }

    //GetAppraisalTesteVehiclesFromAPI(): Observable<Response> {
    //    return this._http.get("http://d1-epstgapp-01/SIMSAPI/KbbAppraisal/FetchAppraisalLog/0/101,102,103,104/Last%2030%20days/CreatedDate/DESC/7/2001?_=1555333010546");
    //}

    //DeleteAppraisalTesteVehiclesFromAPI(params:any): Observable<Response> {
    //    return this._http.get("http://d1-epstgapp-01/SIMSAPI/KbbAppraisal/DeleteAppraisalRecord/"+params.Vehicle_ID+"/"+params.Curr_Store_ID+"/"+params.Invtr_ID);
    //}

    GetAppraisalTesteVehiclesFromAPI(): Observable<Response> {
        return this._http.get("/simslogs/FetchTestAppraisals");
    }

    DeleteAppraisalTesteVehiclesFromAPI(params: any): Observable<Response> {
        return this._http.get("/simslogs/DeleteTestAppraisalRecord/" + params.Vehicle_ID + "/" + params.Store_ID + "/" + params.Invtr_ID);
    }
    
}

