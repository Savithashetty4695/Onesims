/// <reference path="../model/answer-default.ts" />
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { of} from 'rxjs';
import 'rxjs/add/observable/throw'; 
import { Questions } from '../Model/Questions.model';
import { VehicleFactoryOptionsKBB, FactoryOptionsKBB, KBBandChromeOptions} from '../factory-options/Model/factory-option-post';
import { LinkEnum } from '../model/link-enum.enum';
import { HttpServiceService } from './http-service.service';
import { KbbServiceHelper } from './kbb-service-helper';
import { VehicleParams } from '../Model/vehicle-params.model';
import { AnswerModel } from '../model/answer-model';
import { Vehicle } from '../Model/vehicle';
import { CarfaxAutockeck } from '../carfaxautocheck/model/carfaxautocheck-get';
import { AfterFactoryOptionsKBB } from '../after-market/Model/After-factory-option-get';
import { AfterVehicleFactoryOptionsKBB } from '../after-market/Model/After-factory-option-post';
import { pricing } from '../pricing/model/pricing-get';
import { pricingpost } from '../pricing/model/pricing-post';
import { VinVehicleDetails } from '../Model/vin-vehicle-details';
import {VinVehicleDetailsKBB} from '../Model/vin-vehicle-details-kbb';
import { BookDetailResponse } from '../book-values/model/book-detail-response';
import { VehicleBookParams } from '../book-values/model/vehicle-book-params';
import { BookValueSaveParams } from '../book-values/model/book-value-save-params';
import { SIMSResponseData } from '../model/simsresponse-data';
import { BookConfiguration } from '../book-values/model/book-configuration';
import { VinVehicleDetailBooks } from '../book-values/model/vin-vehicle-detail-books';
import { OptionValues } from '../book-values/model/option-values';
import { BookValue } from '../book-values/model/book-value';
import {KbbColors} from '../Model/kbb-colors';
import {VehiclePhotoWrapper } from '../model/vehicle-photo-details';
import {Subject} from 'rxjs/Subject'
import { BookValueRequestPost } from '../book-values/model/book-value-request-post';
import { IDValues, ValuationData } from '../book-values/model/valuation-data';
import { OptionValuesUVC } from '../book-values/model/option-values-uvc';
import { KBB_Eng_Tran_DrTr } from '../book-values/model/kbb-eng-tran-drtr';
import {AnswerDefault} from '../model/answer-default';
import {KioskLane } from '../model/kiosk-lane';
import {VehicleLaneDetails} from '../model/vehicle-lane-details';
import { PhotoUploadParams } from '../model/photo-upload-params'
import { AfterMarketComments } from '../after-market/Model/after-factory-option-comment';
import { ReconQuestionModel } from '../Model/recon-question-model';
declare var $: any;

@Injectable()
export class KBBServiceService {
    StoreId: number;

    private kbbServiceHelper: KbbServiceHelper;
    isWizardStep: Subject<boolean> = new Subject<boolean>();
    decodeVinVehicleDetails: VinVehicleDetails;
    decodeVinVehicleDetailsKBB: VinVehicleDetailsKBB;
    aftermarketCommentsData: AfterMarketComments;
    vinVehicleDetails: Vehicle;
    aftermarketpostDetails: AfterVehicleFactoryOptionsKBB[];
    aftermarketoptiondata: AfterFactoryOptionsKBB[];
    pricingdata: pricing;
    aftermarketComments: AfterMarketComments;
    kbbColors: KbbColors;
    CarfaxAutockeckDetails: CarfaxAutockeck;
    pricingDetails: pricing;
    pricingpostDetails: pricingpost;
    aftermarketDetails: AfterFactoryOptionsKBB[];
    BookDetailResponse: BookDetailResponse;
    private factoryOptionsData: FactoryOptionsKBB[];
    private rawFactoryOptionsData: any;
    private HistoryData: Questions[];
    private AfterMarketData: Questions[];
    //private ReconQuestionData: Questions[];
    private ReconQuestionData: ReconQuestionModel;
    public optionValues: OptionValues[];
    vehicleParams: VehicleParams;
    bookValueRequestPost: BookValueRequestPost;
    idValues: IDValues;
    BookValue: BookValue;
    comment: string;
    VinVehicleDetailBooks: VinVehicleDetailBooks;
    uploadCompleteSubject: Subject<number>;
    uploadComplete$: Observable<number>;
    VehicleInfoGetComplete: Subject<any>;
    VehicleInfoGet$: Observable<any>;
    bookConfiguration: BookConfiguration;
    BindBlackBook: BookValue;
    BindManheim: BookValue;
    BindNADA: BookValue;
    BindKBB: BookValue;
    SetBlackBook: ValuationData;
    SetMainhaim: ValuationData;
    SetNADA: ValuationData;
    SetKBB: ValuationData;
    answerdefault: AnswerDefault;
    ErrorBlackBook: boolean;
    ErrorMainhaim: boolean;
    ErrorNADA: boolean;
    ErrorMessageBlackBook: string;
    ErrorMessageMainhaim: string;
    ErrorMessageNADA: string;
    isSaveBlackBook: boolean;
    isSaveMainhaim: boolean;
    isSaveNADA: boolean;
    isSaveKBB: boolean;
    isRequiredBlackBook: boolean;
    isRequiredMainhaim: boolean;
    isRequiredNADA: boolean;
    isRequiredKBB: boolean;
    setBootstrap: number;
    suggestedPrice: string;
    IsProspectIdExists: boolean;
    IsProspectIdExistsChange: Subject<boolean> = new Subject<boolean>();
    isFinishEnable: Subject<boolean> = new Subject<boolean>();
    KbbDecodeCompleteChange: Subject<boolean> = new Subject<boolean>();
    isAfterMarketEnable: Subject<boolean> = new Subject<boolean>();
    isHistoryEnable: Subject<boolean> = new Subject<boolean>();
    isConditionEnable: Subject<boolean> = new Subject<boolean>();
    isFinishBookDisable: Subject<boolean> = new Subject<boolean>();
    isFinishPriceDisable: Subject<boolean> = new Subject<boolean>();
    vehicleType: string;
    vehicleLaneDetails: VehicleLaneDetails;
    showManagerNotes: boolean;
    managerNotesText: string;
    InServiceDate: Date;

    //Added for latest Thumbnail
    DsLatestThumbnail: Subject<string>=new Subject<string>();
    DsLatestWheelThumbnail: Subject<string> = new Subject<string>();
    DsLatestAdditionalThumbnail: Subject<string> = new Subject<string>();

    FrontLatestThumbnail: Subject<string> = new Subject<string>();
    FrontLatestAdditionalThumbnail: Subject<string> = new Subject<string>();

    PsLatestThumbnail: Subject<string> = new Subject<string>();
    PsLatestWheelThumbnail: Subject<string> = new Subject<string>();
    PsLatestAdditionalThumbnail: Subject<string> = new Subject<string>();

    RearLatestThumbnail: Subject<string> = new Subject<string>();
    RearLatestAdditionalThumbnail: Subject<string> = new Subject<string>();

    VinLatestThumbnail: Subject<string> = new Subject<string>();
    DashboardLatestWheelThumbnail: Subject<string> = new Subject<string>();
    OdometerLatestAdditionalThumbnail: Subject<string> = new Subject<string>();
    FrontSeatLatestThumbnail: Subject<string> = new Subject<string>();
    BackSeatLatestThumbnail: Subject<string> = new Subject<string>();
    InteriorLatestAdditionalThumbnail: Subject<string> = new Subject<string>();
    LaneDetails: KioskLane[];
    //Added for latest Thumbnail
    hideFactoryOption: Subject<boolean> = new Subject<boolean>(); // added for IsKbbFailure
    kbbAndChromeOptiondata: KBBandChromeOptions;
    reqGallery: boolean = false;
    constructor(private httpService: HttpServiceService) {
        this.kbbServiceHelper = new KbbServiceHelper();
        this.factoryOptionsData = new Array<FactoryOptionsKBB>();
        this.HistoryData = new Array<Questions>();
        this.AfterMarketData = new Array<Questions>();
        this.optionValues = new Array<OptionValues>();
        this.aftermarketComments = new AfterMarketComments();
        this.BookValue = new BookValue();
        this.uploadCompleteSubject = new Subject<number>();
        this.uploadComplete$ = this.uploadCompleteSubject.asObservable();
        this.VehicleInfoGetComplete = new Subject<any>();
        this.VehicleInfoGet$ = this.VehicleInfoGetComplete.asObservable();
        this.bookValueRequestPost = new BookValueRequestPost();
        this.idValues = new IDValues();
        this.aftermarketpostDetails = new Array<AfterVehicleFactoryOptionsKBB>();
        this.aftermarketDetails = new Array<AfterFactoryOptionsKBB>()
        this.IsProspectIdExists = false;
        this.ErrorBlackBook = false;
        this.ErrorMainhaim = false;
        this.ErrorNADA = false;
        this.answerdefault = new AnswerDefault();

    }

    DecodeVin(params: VehicleParams): Observable<VinVehicleDetailsKBB> {

        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.DecodeVin, params))
            .map(function (res: Response) {


                return <VinVehicleDetailsKBB>res.json().data;
            }).catch((error: any) => {

                return Observable.throw(new Error(error));
            });
    }
    DecodeVinFromCache(params: any): VinVehicleDetailsKBB {

        if (this.decodeVinVehicleDetailsKBB != undefined && this.decodeVinVehicleDetailsKBB)
            return this.decodeVinVehicleDetailsKBB;

        if (this.decodeVinVehicleDetails != undefined) {
            this.decodeVinVehicleDetailsKBB.DecodeVinVehicleDetails = this.decodeVinVehicleDetails;
            return this.decodeVinVehicleDetailsKBB;
        }
    }

    Getaftermarketcommnet(params: VehicleParams): Observable<AfterMarketComments> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetAftermarketComment, params))
            .map(function (res: Response) {
                return <AfterMarketComments>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }
    GetAfterFactoryCommnetsFromCache(params: VehicleParams): AfterMarketComments {

        if (this.aftermarketCommentsData != null)
            return this.aftermarketCommentsData;
    }
    GetVehicleDetailsFromAPI(params: any): Observable<Vehicle> {

        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetVehicle, params))
            .map(function (res: Response) {
                this.vinVehicleDetails = <Vehicle>res.json().data;
                this.managerNotesText = this.vinVehicleDetails.ManagerNote;
                return <Vehicle>res.json().data;
            }).catch((error: any) => {

                return Observable.throw(new Error(error));
            });
    }

    GetVehicleDetailsFromCache(params: any): Vehicle {

        if ((this.vinVehicleDetails) != undefined)
            return this.vinVehicleDetails;
    }

    GetProspectFromAPI(params: any): Observable<string> {
        let body = params;

        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetProspect), body).map(function (res: Response) {
            return res.json().data;

        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }

    GetKbbColorsFromAPI(params: any): Observable<KbbColors> {

        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetKbbColors, params))
            .map(function (res: Response) {
                return <KbbColors>res.json().data;
            }).catch((error: any) => {

                return Observable.throw(new Error(error));
            });
    }

    GetKbbColorsFromCache(params: any): KbbColors {

        if (this.kbbColors != undefined)
            return this.kbbColors;
    }

    GetQuestionsFromCache(params: VehicleParams, link: LinkEnum) {
        switch (link) {
            case LinkEnum.GetAfterMarket:
                if (this.AfterMarketData != null && this.AfterMarketData.length > 0)
                    return this.AfterMarketData;
                break;
            case LinkEnum.GetHistory:
                if (this.HistoryData != null && this.HistoryData.length > 0)
                    return this.HistoryData;
                break;
        }
    }

    GetReconQuestionFromCache() {
        if (this.ReconQuestionData != null && this.ReconQuestionData.Sections.length > 0)
            return this.ReconQuestionData;
    }

    GetQuestionsfromAPI(params: VehicleParams, link: LinkEnum):any {


        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(link, params))
            .map(function (res: Response) {
                return res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });

    }


    SaveVehicleDetails(params: any): Observable<SIMSResponseData> {
        let body = params;

        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.SaveVehicle), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }

    

    SaveResponse(param: AnswerModel, link: LinkEnum): Observable<SIMSResponseData> {

        let body = JSON.stringify(param);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(link), body).map(function (res: Response) {

            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }
    
    FetchCarfax_Autocheck_RunlistDetails(param: VehicleParams, link: LinkEnum): Observable<AnswerDefault> {
        let body = JSON.stringify(param);
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetFetchCarfax_Autocheck_RunlistDetails, param))
            .map(function (res: Response) {
                return <AnswerDefault>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }
    SaveAfterMarketComments(params: AfterMarketComments): Observable<SIMSResponseData> {
        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.SaveAftermarketoptionComments), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }

    GetFactoryOptionsFromAPI(params: VehicleParams): Observable<KBBandChromeOptions> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetFactory, params))
            .map(function (res: Response) {
                return <KBBandChromeOptions>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }

    Getafterfactoryoption(params: VehicleParams): Observable<AfterFactoryOptionsKBB[]> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetAftermarketoption, params))
            .map(function (res: Response) {
                return <AfterFactoryOptionsKBB[]>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }

    getRawFactoryDataFromCache(): any {
        return this.rawFactoryOptionsData;
    }


    SaveAfterFactoryOptions(params: AfterVehicleFactoryOptionsKBB): Observable<SIMSResponseData> {
        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.SaveAftermarketoption), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }

    GetFactoryOptionsFromCache(params: VehicleParams): KBBandChromeOptions {
        // returning from cache both kbb and chrome option
        if (this.kbbAndChromeOptiondata != null)
            return this.kbbAndChromeOptiondata;
    }


    GetKBBFactoryOptionsFromCache(params: VehicleParams): FactoryOptionsKBB[] {
        // returning only grouped kbb factory optionss
        if (this.factoryOptionsData != null)
            return this.factoryOptionsData;

    }

    GetAfterFactoryOptionsFromCache(params: VehicleParams): AfterFactoryOptionsKBB[] {

        if (this.aftermarketoptiondata != null && this.aftermarketoptiondata.length > 0)
            return this.aftermarketoptiondata;
    }
    GetPricingFromCache(params: VehicleParams): pricing {

        if (this.pricingdata != null)
            return this.pricingdata;
    }

    GetServiceDate(): Date {

        if (this.InServiceDate != null)
            return this.InServiceDate;
    }

    SaveFactoryOptions(params: VehicleFactoryOptionsKBB): Observable<SIMSResponseData> {
        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.SaveFactory), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }


    GetCarfaxAutocheckFromCache(params: VehicleParams): CarfaxAutockeck {
        if (this.CarfaxAutockeckDetails != null)
            return this.CarfaxAutockeckDetails;
    }


    GetCarfaxAutocheckFromAPI(params: VehicleParams): Observable<CarfaxAutockeck> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.CarfaxAutocheckPageonload, params))
            .map(function (res: Response) {
                return <CarfaxAutockeck>res.json().data;

            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }
    GetCarfaxReportFromAPI(params: VehicleParams): Observable<CarfaxAutockeck> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetCarfaxReport, params))
            .map(function (res: Response) {
                return <CarfaxAutockeck>res.json().data;

            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }
    GetAutcCheckReportFromAPI(params: VehicleParams): Observable<CarfaxAutockeck> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetAutocheckReport, params))
            .map(function (res: Response) {
                return <CarfaxAutockeck>res.json().data;

            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }

    GetPricing(params: VehicleParams): Observable<pricing> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetPricing, params))
            .map(function (res: Response) {
                return <pricing>res.json().data;

            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }
    GetPricingRTC(params: VehicleParams): Observable<pricing> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetPricingRTC, params))
            .map(function (res: Response) {
                return <pricing>res.json().data;

            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }

    SavePrice(params: pricingpost) {
        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.SavePrice), body).map(function (res: Response) {
            return res.status;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }
    vehicleDetailsDataChanged(): Observable<Vehicle> {

        return of(this.vinVehicleDetails);
    }

    decodeVinDetailsData(): Observable<VinVehicleDetails> {

        return of(this.decodeVinVehicleDetails);
    }

    GetStoreForLanes(params: VehicleParams): Observable<KioskLane[]> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetLanesForStore, params))
            .map(function (res: Response) {
                return <KioskLane[]>res.json().data;

            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }
    SaveVehicleLaneDetails(param: any): Observable<SIMSResponseData> {

        let body = JSON.stringify(param);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.SaveVehicleLaneDetails), body).map(function (res: Response) {

            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }
   
    setData(data: any, source: LinkEnum) {

        switch (source) {
            case LinkEnum.GetFactory || LinkEnum.SaveFactory:
                this.factoryOptionsData = null;
                this.factoryOptionsData = data;
                break;
            case LinkEnum.GetFactoryRaw:
                this.rawFactoryOptionsData = null;
                this.rawFactoryOptionsData = data;
                break;
            case LinkEnum.GetAftermarketComment:
                this.aftermarketCommentsData = null;
                this.aftermarketCommentsData = data;
                break;
            case LinkEnum.GetHistory || LinkEnum.SaveHistory:
                this.HistoryData = null;
                this.HistoryData = data;
                break;
            case LinkEnum.GetAfterMarket || LinkEnum.SaveAfterMarket:
                this.AfterMarketData = null;
                this.AfterMarketData = data;
                break;
            case LinkEnum.GetRecon || LinkEnum.SaveRecon:
                this.ReconQuestionData = null;
                //this.ReconQuestionData = JSON.parse(JSON.stringify(data)); // to avoid unsaved data to reset
                this.ReconQuestionData = data;
                break;
            case LinkEnum.GetVehicle:
                this.vinVehicleDetails = null;
                this.vinVehicleDetails = data;
                this.vehicleDetailsDataChanged();
                break;
            case LinkEnum.SaveVehicle:
                this.vinVehicleDetails = null;
                this.vinVehicleDetails = data;
                break;
            case LinkEnum.DecodeVinKBB:
                this.decodeVinVehicleDetailsKBB = null;
                this.decodeVinVehicleDetailsKBB = data;
                break;
            case LinkEnum.DecodeVin:
                this.decodeVinVehicleDetails = null;
                this.decodeVinVehicleDetails = data;
                break;
            case LinkEnum.CarfaxAutocheckPageonload:
                this.CarfaxAutockeckDetails = null;
                this.CarfaxAutockeckDetails = data;
                break;

            case LinkEnum.GetPricing:
                this.pricingdata = null;
                this.pricingdata = data;
                break;
            case LinkEnum.GetAftermarketoption:
                this.aftermarketoptiondata = null;
                this.aftermarketoptiondata = data;
                break;
            case LinkEnum.GetBookDetails:
                this.BookDetailResponse = null;
                this.BookDetailResponse = data;
                break;
            case LinkEnum.GetKbbColors:
                this.kbbColors = null;
                this.kbbColors = data;
                break;
            case LinkEnum.GetAllRequiredBooks:
                this.bookConfiguration = new BookConfiguration()
                this.bookConfiguration = null;
                this.bookConfiguration = data;
                break;
            case LinkEnum.GetAllBooks:
                this.VinVehicleDetailBooks = null;
                this.VinVehicleDetailBooks = data;
                break;
            case LinkEnum.GetBookValueADP:
                this.BindBlackBook = new BookValue();
                this.BindBlackBook = null;
                this.BindBlackBook = data;
                break;
            case LinkEnum.GetBookValueKBB:
                this.BindKBB = new BookValue();

                this.BindKBB = null;
                this.BindKBB = data;
                break;
            case LinkEnum.GetManheimBookValues:
                this.BindManheim = new BookValue();
                this.BindManheim = null;
                this.BindManheim = data;
                break;
            case LinkEnum.GetBookValueNADA:
                this.BindNADA = new BookValue();

                this.BindNADA = null;
                this.BindNADA = data;
                break;
            case LinkEnum.SetBlackBook:
                this.SetBlackBook = new ValuationData();
                this.SetBlackBook = data;
                break;

            case LinkEnum.SetMainhaim:
                this.SetMainhaim = new ValuationData();
                this.SetMainhaim = data;
                break;
            case LinkEnum.SetNADA:
                this.SetNADA = new ValuationData();
                this.SetNADA = data;
                break;
            case LinkEnum.SetKBB:
                this.SetKBB = new ValuationData();
                this.SetKBB = data;
                break;
            case LinkEnum.setBootstrap:
                this.setBootstrap = data;
                break;
            case LinkEnum.ErrorBlackBook:
                this.ErrorBlackBook = data;
                break;
            case LinkEnum.ErrorMainhaim:
                this.ErrorMainhaim = data;
                break;
            case LinkEnum.ErrorNADA:
                this.ErrorNADA = data;
                break;
            case LinkEnum.ErrorMessageBlackBook:
                this.ErrorMessageBlackBook = data;
                break;
            case LinkEnum.ErrorMessageMainhaim:
                this.ErrorMessageMainhaim = data;
                break;
            case LinkEnum.ErrorMessageNADA:
                this.ErrorMessageNADA = data;
                break;
            case LinkEnum.IsSaveBlackBook:
                this.isSaveBlackBook = data;
                break;
            case LinkEnum.IsSaveMainhaim:
                this.isSaveMainhaim = data;
                break;
            case LinkEnum.IsSaveNADA:
                this.isSaveNADA = data;
                break;
            case LinkEnum.IsSaveKBB:
                this.isSaveKBB = data;
                break;
            case LinkEnum.IsRequiredBlackBook:
                this.isRequiredBlackBook = data;
                break;
            case LinkEnum.IsRequiredMainhaim:
                this.isRequiredMainhaim = data;
                break;
            case LinkEnum.IsRequiredNADA:
                this.isRequiredNADA = data;
                break;
            case LinkEnum.IsRequiredKBB:
                this.isRequiredKBB = data;
                break;
            case LinkEnum.ClearCacheFactory:
                this.factoryOptionsData = null;
                this.rawFactoryOptionsData = null;
                this.kbbAndChromeOptiondata = null;
                break;
            case LinkEnum.ClearCacheReconinfo:
                this.ReconQuestionData = null;
                break;
            case LinkEnum.VehicleLaneDetails:
                this.vehicleLaneDetails = null;
                break;
            case LinkEnum.KBBandChromeOptions:
                this.kbbAndChromeOptiondata = null;
                this.kbbAndChromeOptiondata = data;
                break;
            case LinkEnum.GetServiceDate:
                this.InServiceDate = null;
                this.InServiceDate = data;
                break;
        }
    }

    GetGetBookDetailsFromCache(params: VehicleBookParams, link: LinkEnum) {
        switch (link) {
            case LinkEnum.GetAfterMarket:
                if (this.AfterMarketData != null && this.AfterMarketData.length > 0)
                    return this.AfterMarketData;
                break;
            case LinkEnum.GetHistory:
                if (this.HistoryData != null && this.HistoryData.length > 0)
                    return this.HistoryData;
                break;
            //case LinkEnum.GetRecon:
            //    if (this.ReconQuestionData != null && this.ReconQuestionData.length > 0)
            //        return this.ReconQuestionData;
            //    break;
        }
    }

    GetBookDetailsfromAPI(params: VehicleBookParams, link: LinkEnum): Observable<BookDetailResponse[]> {


        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(link), params)
            .map(function (res: Response) {
                return <BookDetailResponse[]>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });

    }


    SaveDetailsfromAPI(params: BookValueSaveParams, link: LinkEnum): Observable<boolean> {


        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(link), params)
            .map(function (res: Response) {
                return <boolean>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });

    }
    GetAllRequiredBooksFromCache(): BookConfiguration {

        if (this.bookConfiguration != null || this.bookConfiguration != undefined)
            return this.bookConfiguration;


    }
    GetBalckBookFromCache(): BookValue {

        if (this.BindBlackBook != null || this.BindBlackBook != undefined)
            return this.BindBlackBook;


    }
    GetManhaimFromCache(): BookValue {

        if (this.BindManheim != null || this.BindManheim != undefined)
            return this.BindManheim;


    }
    GetNADAFromCache(): BookValue {

        if (this.BindNADA != null || this.BindNADA != undefined)
            return this.BindNADA;


    }
    GetKBBFromCache(): BookValue {

        if (this.BindKBB != null || this.BindKBB != undefined)
            return this.BindKBB;


    }

    ClearKBBFromCache(): void {
        this.BindKBB = null;
    }

    GetBalckBookValuationFromCache(): ValuationData {

        if (this.SetBlackBook != null || this.SetBlackBook != undefined)
            return this.SetBlackBook;


    }
    GetManhaimValuationFromCache(): ValuationData {

        if (this.SetMainhaim != null || this.SetMainhaim != undefined)
            return this.SetMainhaim;


    }
    GetNADAValuationFromCache(): ValuationData {

        if (this.SetNADA != null || this.SetNADA != undefined)
            return this.SetNADA;


    }
    GetKBBValuationFromCache(): ValuationData {

        if (this.SetKBB != null || this.SetKBB != undefined)
            return this.SetKBB;


    }

    GetBootstapFromCache(): number {

        if (this.setBootstrap != null || this.setBootstrap != undefined)
            return this.setBootstrap;
    }
    GetErrorBlackBookFromCache(): boolean {
        return this.ErrorBlackBook;
    }

    GetErrorMainhaimFromCache(): boolean {
        return this.ErrorMainhaim;
    }
    GetErrorNADAFromCache(): boolean {
        return this.ErrorNADA;
    }

    GetErrorMessageBlackBookFromCache(): string {
        return this.ErrorMessageBlackBook;
    }

    GetErrorMessageMainhaimFromCache(): string {
        return this.ErrorMessageMainhaim;
    }
    GetErrorMessageNADAFromCache(): string {
        return this.ErrorMessageNADA;
    }

    SaveBlackBookFromCache(): boolean {
        return this.isSaveBlackBook;
    }
    SaveMainhaimFromCache(): boolean {
        return this.isSaveMainhaim;
    }
    SaveNADAFromCache(): boolean {
        return this.isSaveNADA;
    }
    SaveKBBFromCache(): boolean {
        return this.isSaveKBB;
    }

    GetRequiredBlackBookFromCache(): boolean {
        return this.isRequiredBlackBook;
    }
    GetRequiredMainhaimFromCache(): boolean {
        return this.isRequiredMainhaim;
    }
    GetRequiredNADAFromCache(): boolean {
        return this.isRequiredNADA;
    }
    GetRequiredBBFromCache(): boolean {
        return this.isRequiredKBB;
    }


    GetAllRequiredBooksfromAPI(params: VehicleParams): Observable<BookConfiguration> {

        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetAllRequiredBooks, params))
            .map(function (res: Response) {
                return <BookConfiguration>res.json().data;
            }).catch((error: any) => {

                return Observable.throw(new Error(error));
            });

    }

    GetAllBooksFromCache(): VinVehicleDetailBooks {

        if (this.VinVehicleDetailBooks != null || this.VinVehicleDetailBooks != undefined)
            return this.VinVehicleDetailBooks;


    }

    GetAllBooksfromAPI(params: VehicleParams): Observable<VinVehicleDetailBooks> {

        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetAllBooks, params))
            .map(function (res: Response) {
                return <VinVehicleDetailBooks>res.json().data;
            }).catch((error: any) => {

                return Observable.throw(new Error(error));
            });

    }

    setVehicleParameters(params: VehicleParams) {
        this.vehicleParams = params;
    }

    getVehicleParameters(): VehicleParams {

        return this.vehicleParams;
    }

    SaveAppraisalPhotos(photoUploadParam: PhotoUploadParams) {

        let body = JSON.stringify(photoUploadParam);
        return this.httpService.PostPhoto(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.SaveAppraisalPhotos), body).map(function (res: Response) {

            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }
    GetAppraisalPhotos(params: VehicleParams) {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.GetAppraisalPhotos, params)).map(function (res: Response) {

            return <VehiclePhotoWrapper>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }
    DeleteAppraisalPhoto(params: VehicleParams, photoId: number) {
        return this.httpService.Delete(this.kbbServiceHelper.ApiLinksForDelete(LinkEnum.DeleteAppraisalPhoto, photoId, params)).map(function (res: Response) {

            return <VehiclePhotoWrapper>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });
    }

    GetOptionsADPfromAPI(params: BookValueSaveParams, link: LinkEnum): Observable<OptionValues[]> {
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(link), params)
            .map(function (res: Response) {
				return <OptionValues[]>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });

    }

    GetBookValueADP(params: BookValueRequestPost, link: LinkEnum): Observable<BookValue> {
        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetBookValueADP), body).map(function (res: Response) {
            return <BookValue>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(error);
        });


    }
    GetBookValueNADA(params: BookValueRequestPost, link: LinkEnum): Observable<BookValue> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetBookValueNADA), body).map(function (res: Response) {
            return <BookValue>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(error);
        });


    }

    GetBookValueKBB(params: BookValueRequestPost, link: LinkEnum): Observable<BookValue> {
        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetBookValueKBB), body).map(function (res: Response) {
            return <BookValue>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(error);
        });


    }

    PhotoUploadCompleted(): void {

        this.uploadCompleteSubject.next(Math.random());
    }
    VehicleInfoGetCompleted(): void {

        this.VehicleInfoGetComplete.next(Math.random());
    }

    GetManheimBookValues(params: BookValueRequestPost, link: LinkEnum): Observable<BookValue> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetManheimBookValues), body).map(function (res: Response) {
            return <BookValue>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(error);
        });

    }
    GetMakeADP(params: BookValueRequestPost, link: LinkEnum): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetMakes), body).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }
    GetModelADP(params: BookValueRequestPost, link: LinkEnum): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetModels), body).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    GetTrimsADP(params: BookValueRequestPost, link: LinkEnum): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetTrims), body).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    GetBodyStyleADP(params: BookValueRequestPost, link: LinkEnum): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetBodyStyle), body).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }


    GetMakeManheim(params: BookValueRequestPost, link: LinkEnum): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetMakesManheim), body).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }
    GetModelManheim(params: BookValueRequestPost, link: LinkEnum): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetModelsManheim), body).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }


    GetBodyStyleManheim(params: BookValueRequestPost, link: LinkEnum): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetBodyStyleManheim), body).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    GetOptionsADP(params: BookValueRequestPost): Observable<OptionValuesUVC> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetOptionsADP), body).map(function (res: Response) {
            return <OptionValuesUVC>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }
    GetOptionsKBB(params: BookValueRequestPost): Observable<OptionValuesUVC> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetOptionsKBB), body).map(function (res: Response) {
            return <OptionValuesUVC>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    // start #2127 v2 failure case 
    GetKBBYears(params: any): Observable<IDValues> {

        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBBYears), params).map(function (res: Response) {
            return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }
	GetKBBMakes(params: BookValueRequestPost): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBBMakes), body).map(function (res: Response) {
			return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    GetKBBMakesFromVI(params: BookValueRequestPost): Observable<SIMSResponseData> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBBMakes), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

	GetKBBModels(params: BookValueRequestPost): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBBModels), body).map(function (res: Response) {
			return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    GetKBBModelsFromVI(params: BookValueRequestPost): Observable<SIMSResponseData> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBBModels), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }
	GetKBBTrims(params: BookValueRequestPost): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBBTrims), body).map(function (res: Response) {
			return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    GetKBBTrimsFromVI(params: BookValueRequestPost): Observable<SIMSResponseData> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBBTrims), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }
	GetKBB_Eng_Tran_DrvTra(params: BookValueRequestPost): Observable<IDValues> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBB_Eng_Tran_DrvTra), body).map(function (res: Response) {
			return <IDValues>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    GetKBB_Eng_Tran_DrvTraFromVI(params: BookValueRequestPost): Observable<SIMSResponseData> {

        let body = JSON.stringify(params);
        return this.httpService.Post(this.kbbServiceHelper.ApiLinksForPost(LinkEnum.GetKBB_Eng_Tran_DrvTra), body).map(function (res: Response) {
            return <SIMSResponseData>res.json().data;
        }).catch((error: any) => {
            return Observable.throw(new Error(error));
        });

    }

    // end #2127 v2 failure case 

    GetOfferDetails(params: VehicleParams): Observable<SIMSResponseData> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.SaveOfferResponseSIMS, params))
            .map(function (res: Response) {
				return <SIMSResponseData>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }

    Pushprice(params: VehicleParams): Observable<SIMSResponseData> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(LinkEnum.PushPrice, params))
            .map(function (res: Response) {
				return <SIMSResponseData>res.json().data;

            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }

    ResubmitSACRecord(param: VehicleParams, link: LinkEnum): Observable<SIMSResponseData> {
        return this.httpService.Get(this.kbbServiceHelper.ApiLinksForGet(link, param))
            .map(function (res: Response) {
                return <SIMSResponseData>res.json().data;
            }).catch((error: any) => {
                return Observable.throw(new Error(error));
            });
    }
}
