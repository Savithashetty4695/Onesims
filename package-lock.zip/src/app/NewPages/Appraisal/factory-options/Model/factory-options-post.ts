export interface VehicleFactoryOptionsKBB {
    InvtrId: number;
   StoreId: number;
   UserName: string;
    VehicleId: number;
     data: FactoryOptionsKBB[];
}

  interface FactoryOptionsKBB {
     optionId: number;
     isSelected: string;
     displayName: string;
     categoryName: string;
     optionKindId: string;
     isStandardOption: boolean;
}