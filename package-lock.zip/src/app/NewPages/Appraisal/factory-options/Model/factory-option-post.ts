export class KBBandChromeOptions {
    InvtrId: number;
    StoreId: number;
    UserName: string;
    VehicleId: number;
    KbbFactoryOptions: FactoryOptionsKBB[];
    ChromeFactoryOptionList: GroupedChromeFactoryOptions[];
    InServiceDate: Date;
    //KbbData: 
    //ChromeData:   
}


export class VehicleFactoryOptionsKBB {
    InvtrId: number;
    StoreId: number;
    UserName: string;
    VehicleId: number;
    KbbFactoryOptions: FactoryOptionsKBB[];
    ChromeFactoryOptions: ChromeFactoryOptions[];
    SourceType: number;
    InServiceDate: string;
    Decode_Type: number;
}

export class FactoryOptionsKBB {
    optionId: number;
    displayName: string;
    categoryName: string;
    optionKindId: string;
    isSelected: string;
    isStandardOption: boolean;
}
export class ChromeFactoryOptions {

    Description: string;
    Utf: string;
    OptionKindId: string;
    Price: number;
    InstalledCause: string;
    StyleId: number[];
    OemCode: string;
    isSelected: string;
}

export class GroupedChromeFactoryOptions {
    Header: string;
    Options: ChromeFactoryOptions[];
}
