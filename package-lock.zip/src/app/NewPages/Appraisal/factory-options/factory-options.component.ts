import { Response } from '@angular/http';
import { Component, OnInit, ViewEncapsulation, ElementRef, Input, ViewChild } from '@angular/core';
import { KBBServiceService } from '../Services/kbbservice.service';
import { HttpServiceService } from '../Services/http-service.service';
import { VehicleParams } from '../Model/vehicle-params.model';
import { KBBandChromeOptions, VehicleFactoryOptionsKBB, FactoryOptionsKBB, GroupedChromeFactoryOptions, ChromeFactoryOptions } from './Model/factory-option-post';
import { ErrorHandler } from '../common/error-handler'
import { LinkEnum, DecodeType } from '../model/link-enum.enum';
import { KbbColors } from '../Model/kbb-colors';
import { VinVehicleDetailsKBB } from '../Model/vin-vehicle-details-kbb';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

import { IDValues } from '../book-values/model/valuation-data';
import { Subscription } from 'rxjs';

import { DatePipe } from '@angular/common';
import { parseDate } from '@progress/kendo-angular-intl';

declare var Close: any;

@Component({
    selector: 'app-factory-options',
    templateUrl: './factory-options.component.html',
    styleUrls: ['./factory-options.component.css'],
    encapsulation: ViewEncapsulation.None

})

export class FactoryOptionsComponent implements OnInit {
    selectedOption: string;
    params: VehicleParams;
    postparams: VehicleParams;
    factory: FactoryOptionsKBB;
    chfactory: ChromeFactoryOptions;
    factoryQuestions: FactoryOptionsKBB[];
    editParams: any;
    listfactory: FactoryOptionsKBB[];
    Chromelistfactory: ChromeFactoryOptions[];
    factorypost: VehicleFactoryOptionsKBB;
    Chfactorypost: KBBandChromeOptions;
    factoryExteriorColor: string;
    kbbColors: KbbColors;
    decodeVinvehicleDetailsKbb: VinVehicleDetailsKBB;

    factoryInteriorColor: string;
    pageHeading: string;

    exteriorColors: IDValues[];
    interiorColors: IDValues[];
    @Input() kbbEditObject: string;
    @Input() showSaveCloseButtons: boolean;

    disableSavebtn: boolean;

    @Input() isButtonClose: boolean;
    busyA: Subscription;

    factoryOptionsTest: any[];
    errorHandler: ErrorHandler;
    // chrome 
    TotalSum: any;
    sumoption: number = 0;
    Price: number = 0;
    sumvalue: number;
    OptionKindId: any;
    IsDDCVehicle: boolean;
    grChromefactoryoptions: GroupedChromeFactoryOptions[];
    KbbDecodeVehicleSource: any;
    serviceDateVehicleSource: any;
    InServiceDate: Date;
    IsInServiceDate: boolean;
    Year: number;
    constructor(private elRef: ElementRef, public kbbServiceService: KBBServiceService, public httpService: HttpServiceService, public modalService: NgbModal, private datePipe: DatePipe) {
        this.params = new VehicleParams();
        this.factorypost = new VehicleFactoryOptionsKBB();
        this.Chfactorypost = new KBBandChromeOptions();
        this.errorHandler = new ErrorHandler();
        this.listfactory = new Array<FactoryOptionsKBB>();
        this.factoryQuestions = new Array<FactoryOptionsKBB>();
        this.decodeVinvehicleDetailsKbb = new VinVehicleDetailsKBB();
        this.Chromelistfactory = new Array<ChromeFactoryOptions>();
        this.IsDDCVehicle = false;
        this.KbbDecodeVehicleSource = HttpServiceService.KbbDecodeVehicleSource;
        this.serviceDateVehicleSource = HttpServiceService.serviceDateVehicleSource;
        this.IsInServiceDate = true;

    }



    factoryOptions: any = [];
    factoryOptionsTemp: any = [];
    //tempfactoryOptions: any = [];
    factoryOptionstandardtemp: any = [];
    fcatoryOptionsSeleted: any = new Array();
    factoryOptionsNotSelectedCount: any;
    @ViewChild('content') content: any;
    @ViewChild('editFactoryOptions') redirect: any;
    editMode: boolean;
    temptest;
    showstandardoptions(): any {
        this.temptest = JSON.parse(JSON.stringify(this.factoryOptions));
        this.open(this.content);

    }
    ChromefactoryOptionsSeleted: any = new Array();

    open(content, options: NgbModalOptions = { backdrop: true, keyboard: true }) {

        this.modalService.open(content, options);
    }

    errorMessage: string;
    toggle = {};
    processData(data) {
        let factoryOptionsRaw: JSON = data;
        let factoryOptionsArray = Object.keys(factoryOptionsRaw).map(function (k) { return factoryOptionsRaw[k] });
        this.factoryOptionsTest = factoryOptionsArray;
        if ((factoryOptionsArray.length <= 0 && this.kbbEditObject != null && this.kbbEditObject != undefined) && (this.KbbDecodeVehicleSource.toString().split(',').includes(this.params.SourceType.toString()) || this.params.Decode_Type == DecodeType.KBB_Book_Decode)) {
            let options: NgbModalOptions = { backdrop: 'static', keyboard: false }
            this.hdMessage = "Factory options Changes";
            this.explanation = "This vehicle is created through External Appraisal App. Please edit vehicle information section before editing Factory options.";
            //show modal method call
            this.modalService.open(this.redirect, options);
        }
        var groupsadditionaloption = {};
        var groupsstandardoption = {};
        var groups = {};
        var factoryOptionsTempData = [];
        for (var i = 0; i < factoryOptionsArray.length; i++) {
            if (factoryOptionsArray[i].isStandardOption == false) {
                let groupName: any = factoryOptionsArray[i].categoryName;

                if (!groupsadditionaloption[groupName]) {
                    groupsadditionaloption[groupName] = [];
                }


                if (factoryOptionsArray[i].optionKindId == 'EC') {
                    this.factoryExteriorColor = factoryOptionsArray[i].displayName;
                }
                else if (factoryOptionsArray[i].optionKindId == 'IC') {
                    this.factoryInteriorColor = factoryOptionsArray[i].displayName;
                }


                groupsadditionaloption[groupName].push({
                    displayName: factoryOptionsArray[i].displayName,
                    optionId: factoryOptionsArray[i].optionId,
                    categoryName: factoryOptionsArray[i].categoryName,
                    optionKindId: factoryOptionsArray[i].optionKindId,
                    isSelected: factoryOptionsArray[i].isSelected.toString().toLocaleLowerCase() == 'true' ? true : false,
                    isStandardOption: false,
                });
            }
        }
        for (var i = 0; i < factoryOptionsArray.length; i++) {
            if (factoryOptionsArray[i].isStandardOption == true) {
                let groupName: any = factoryOptionsArray[i].categoryName;

                if (!groupsstandardoption[groupName]) {
                    groupsstandardoption[groupName] = [];
                }


                if (factoryOptionsArray[i].optionKindId == 'EC') {
                    this.factoryExteriorColor = factoryOptionsArray[i].displayName;
                }
                else if (factoryOptionsArray[i].optionKindId == 'IC') {
                    this.factoryInteriorColor = factoryOptionsArray[i].displayName;
                }


                groupsstandardoption[groupName].push({
                    displayName: factoryOptionsArray[i].displayName,
                    optionId: factoryOptionsArray[i].optionId,
                    categoryName: factoryOptionsArray[i].categoryName,
                    optionKindId: factoryOptionsArray[i].optionKindId,
                    isSelected: factoryOptionsArray[i].isSelected.toString().toLocaleLowerCase() == 'true' ? true : false,
                    isStandardOption: true,

                });
            }

        }

        for (var i = 0; i < factoryOptionsArray.length; i++) {
            if (factoryOptionsArray[i].isStandardOption == true) {
                if (factoryOptionsArray[i].optionKindId == 'EC') {
                    this.factoryExteriorColor = factoryOptionsArray[i].displayName;
                }
                else if (factoryOptionsArray[i].optionKindId == 'IC') {
                    this.factoryInteriorColor = factoryOptionsArray[i].displayName;
                }


                this.fcatoryOptionsSeleted.push({
                    displayName: factoryOptionsArray[i].displayName,
                    Isstandardoptions: true,
                    isSelected: factoryOptionsArray[i].isSelected
                });
            }
        }


        for (var groupName in groupsstandardoption) {
            this.factoryOptions.push({
                categoryName: groupName,
                categoryId: Math.random(),
                factoryItem: groupsstandardoption[groupName],
                additionaloption: 'false'
            });
            factoryOptionsTempData.push({
                factoryItem: groupsstandardoption[groupName],
            });
        }



        for (var groupName in groupsadditionaloption) {
            this.factoryOptions.push({
                categoryName: groupName,
                categoryId: Math.random(),
                factoryItem: groupsadditionaloption[groupName],
                additionaloption: 'true'
            });
            factoryOptionsTempData.push({
                factoryItem: groupsadditionaloption[groupName],
            });
        }

        this.factoryOptionsTemp = JSON.parse(JSON.stringify(factoryOptionsTempData));

        // to handle when we receive empty default option selection from KBB Api,
        //usually this occurs when vehicle has more trim ids and chagned from edit screen of vehicle info
        if (this.showSaveCloseButtons && !this.params.IsKbbFailure) {
            // factoryOptionsArray.forEach(a => a.isSelected.toString().toLocaleLowerCase() == 'false').count();
            let factoryOptionsNotSelectedCount = data.filter(function (factoryOption) { return factoryOption.isSelected === "false" }).length;
            if (factoryOptionsNotSelectedCount == factoryOptionsArray.length) {
                this.errorLable = 'Please select at least one from the below options';
                this.disableSavebtn = true;
            }
        }

        this.processcachedata(this.factoryOptions);
    }

    processChromeData(data) {

        this.grChromefactoryoptions = data;

        let msrp = this.grChromefactoryoptions.filter(x => x.Header == "MSRP")[0].Options[0].Price;

        for (var items of this.grChromefactoryoptions) {

            if (items.Header !== "MSRP") {
                for (var item of items.Options) {
                    if (item.isSelected != null && Boolean(item.isSelected) == true) {
                        this.Price += item.Price;
                    }

                }
            }
        }
        this.sumoption = this.Price;
        this.sumvalue = this.Sum(msrp, this.Price);
        this.TotalSum = this.formatCurrency(msrp) + " + " + this.formatCurrency(this.Price) + " = " + this.formatCurrency(this.sumvalue);

    }

    persistFactoryOptionsData() {

        this.kbbServiceService.setData(this.factoryOptions, LinkEnum.GetFactory);
    }

    persistKBBandChromeData(data) {

        this.kbbServiceService.setData(data, LinkEnum.KBBandChromeOptions);
    }

    persistRawFactoryData(rawFactoryData) {

        this.kbbServiceService.setData(rawFactoryData, LinkEnum.GetFactoryRaw);
    }
    persistServiceDate(data) {
        this.kbbServiceService.setData(data, LinkEnum.GetServiceDate)
    }

    ngOnInit() {

        if (this.showSaveCloseButtons) {
            this.pageHeading = "Factory Options";
        }
        else {

            this.pageHeading = "Equipment & Options";
        }

        this.params = this.kbbServiceService.getVehicleParameters();

        if (this.kbbEditObject != null) {

            this.params = JSON.parse(this.kbbEditObject.replace(/'/g, '"'));

            this.params.InventoryType = 10;
            this.editMode = this.params.editMode;
        }
        if (this.KbbDecodeVehicleSource.toString().split(',').includes(this.params.SourceType.toString())) {
            this.IsDDCVehicle = true;
        }
        if (this.params.Decode_Type == DecodeType.KBB_Book_Decode) {
            this.IsDDCVehicle = true;
        }
        else {
            this.IsDDCVehicle = false;
        }
        if (this.serviceDateVehicleSource.toString().split(',').includes(this.params.SourceType.toString())) {
            this.IsInServiceDate = false;
        }
        //For V2 failure passing the KBB TrimID same as ChromeTrimID
        if (this.params.IsKbbFailure == true || this.KbbDecodeVehicleSource.toString().split(',').includes(this.params.SourceType.toString()) || this.params.Decode_Type == DecodeType.KBB_Book_Decode) {
            // 1. Appraisal step take it from vehicle details for step-1
            // 2. edit mode assing directly from parameters
            if (!this.params.editMode)
                this.params.TrimId = Number(this.kbbServiceService.vinVehicleDetails.TrimID);
            else
                this.params.TrimId = Number(this.params.chromeTrimID);
        }

        // chrome optionchagne
        if (!this.params.editMode) {
            this.params.chromeTrimID = this.kbbServiceService.vinVehicleDetails.TrimID;
        }

        let cachedDecodeVehicleDetails = this.kbbServiceService.DecodeVinFromCache(this.params);
        if (cachedDecodeVehicleDetails != undefined) {

            this.exteriorColors = cachedDecodeVehicleDetails.DecodeVinVehicleDetails.ExteriorColor;
            this.interiorColors = cachedDecodeVehicleDetails.DecodeVinVehicleDetails.InteriorColor;
            this.Year = cachedDecodeVehicleDetails.DecodeVinVehicleDetails.Year == 0 && cachedDecodeVehicleDetails.DecodeVinVehicleDetails.Years!=undefined? parseInt(cachedDecodeVehicleDetails.DecodeVinVehicleDetails.Years[0].Value) : cachedDecodeVehicleDetails.DecodeVinVehicleDetails.Year;
        } else {
            this.kbbServiceService.DecodeVin(this.params).subscribe(
                (result: VinVehicleDetailsKBB) => {
                    this.decodeVinvehicleDetailsKbb = result;
                    this.interiorColors = this.decodeVinvehicleDetailsKbb.DecodeVinVehicleDetails.InteriorColor;
                    this.Year = this.decodeVinvehicleDetailsKbb.DecodeVinVehicleDetails.Year == 0 && this.decodeVinvehicleDetailsKbb.DecodeVinVehicleDetails.Years != undefined ? parseInt(this.decodeVinvehicleDetailsKbb.DecodeVinVehicleDetails.Years[0].Value) : this.decodeVinvehicleDetailsKbb.DecodeVinVehicleDetails.Year;
                    this.GetServiceDate(this.InServiceDate);
                    if (this.exteriorColors == null || this.exteriorColors == undefined) {
                        this.kbbServiceService.GetKbbColorsFromAPI(this.params).subscribe(
                            (result: KbbColors) => {
                                this.kbbColors = result;

                                let IdValue: IDValues, i;
                                for (i = 0; i < this.kbbColors.data.length; i++) {
                                    IdValue = new IDValues();

                                    IdValue.ID = this.kbbColors.data[i].colorId.toString();
                                    IdValue.Value = this.kbbColors.data[i].displayName;
                                    this.decodeVinvehicleDetailsKbb.DecodeVinVehicleDetails.ExteriorColor.push(IdValue);
                                }
                            });

                        this.exteriorColors = this.decodeVinvehicleDetailsKbb.DecodeVinVehicleDetails.ExteriorColor;
                    }
                }
                ,
                (error: Response | any) => this.errorHandler.handleError(error));
        }


        let cachedFactoryOptions = this.kbbServiceService.GetFactoryOptionsFromCache(this.params);
        let cachedServiceDate = this.kbbServiceService.GetServiceDate();
        if (cachedFactoryOptions != null) {
            let groupedKBBFactory = this.kbbServiceService.GetKBBFactoryOptionsFromCache(this.params);
            if (groupedKBBFactory != null && groupedKBBFactory.length > 0) {
                this.factoryOptions = groupedKBBFactory;
                this.processcachedata(this.factoryOptions);
            }
            else
                this.processData(cachedFactoryOptions.KbbFactoryOptions);
            // chrome
            this.grChromefactoryoptions = cachedFactoryOptions.ChromeFactoryOptionList;
            this.processChromeData(this.grChromefactoryoptions);
            this.InServiceDate = cachedServiceDate;
        }

        else {
            this.busyA = this.kbbServiceService.GetFactoryOptionsFromAPI(this.params).subscribe(
                (result: KBBandChromeOptions) => {
                    // persist both kbbandchrome masterlist
                    this.persistKBBandChromeData(result);

                    this.persistRawFactoryData(result);
                    this.processData(this.factoryQuestions = result.KbbFactoryOptions);
                    this.persistFactoryOptionsData();
                    // Chrome start                  
                    this.processChromeData(result.ChromeFactoryOptionList);
                    // Chrome end
                    this.persistServiceDate(result.InServiceDate);
                    this.GetServiceDate(result.InServiceDate);
                },
                (error: Response | any) => this.errorHandler.handleError(error));
        }




    }

    errorLable: string;
    onNextButtonClick() {
        var counter = 0;
        this.factorypost.InvtrId = this.params.InventoryId;
        this.factorypost.StoreId = this.params.StoreId;
        this.factorypost.VehicleId = this.params.VehicleId;
        this.factorypost.UserName = this.params.UserName;
        for (var itema of this.factoryOptions) {
            for (var item of itema.factoryItem) {
                this.factory = new FactoryOptionsKBB();
                this.factory.categoryName = item.categoryName;
                this.factory.displayName = item.displayName;
                this.factory.isSelected = item.isSelected;
                this.factory.optionId = item.optionId;
                this.factory.optionKindId = "KBB";
                this.factory.isStandardOption = item.isStandardOption;
                this.listfactory.push(this.factory);
                if (item.isSelected == true) {
                    counter++;
                }

            }
        }

        if (this.factoryExteriorColor) {
            this.factory = new FactoryOptionsKBB();
            this.factory.categoryName = "Exterior Color";
            this.factory.displayName = this.factoryExteriorColor;
            this.factory.isSelected = "True";
            this.factory.optionKindId = "EC";
            this.listfactory.push(this.factory);
        }
        if (this.factoryInteriorColor) {
            this.factory = new FactoryOptionsKBB();
            this.factory.categoryName = "Interior Color";
            this.factory.displayName = this.factoryInteriorColor;
            this.factory.isSelected = "True";
            this.factory.optionKindId = "IC";
            this.listfactory.push(this.factory);
        }
        for (var itemb of this.grChromefactoryoptions) {
            if (itemb.Header == 'MSRP') {
                itemb.Options[0].isSelected = 'true';
            }
            for (var it of itemb.Options) {
                if (it.isSelected != null && Boolean(it.isSelected) == true) {

                    this.chfactory = new ChromeFactoryOptions;
                    this.chfactory.Description = it.Description;
                    this.chfactory.InstalledCause = it.InstalledCause;
                    this.chfactory.isSelected = it.isSelected;
                    this.chfactory.OemCode = it.OemCode;
                    this.chfactory.OptionKindId = it.OptionKindId;
                    this.chfactory.Price = it.Price;
                    this.chfactory.StyleId = it.StyleId;
                    this.Chromelistfactory.push(this.chfactory);
                    counter++;
                }

            }

        }

        this.factorypost.KbbFactoryOptions = this.listfactory;
        this.factorypost.ChromeFactoryOptions = this.Chromelistfactory;
        this.factorypost.Decode_Type = this.params.Decode_Type;
        this.factorypost.SourceType = this.params.SourceType;
        this.factorypost.InServiceDate = this.datePipe.transform(this.InServiceDate, "MM/dd/yyyy");
        this.persistServiceDate(parseDate(this.datePipe.transform(this.InServiceDate, "MM/dd/yyyy")));
        if (counter > 0 || this.params.IsKbbFailure == true || this.KbbDecodeVehicleSource.toString().split(',').includes(this.params.SourceType.toString())) {
            this.errorLable = null;
            this.kbbServiceService.SaveFactoryOptions(this.factorypost).subscribe(
                result => {
                    result;
                    if (this.editMode == true) {
                        Close(0);
                    }
                },
                //(result: SIMSResponseData) => result,
                (error: Response | any) => this.errorHandler.handleError(error));

            return true;


        }
        else {

            this.errorLable = 'Please select at least one from the below options';
            window.scrollTo(0, 0);
            return false;
        }

    }

    //added for displaying popup 
    hdMessage: string = null;
    explanation: string = null;
    saveFromEditPage() {

        var factoryItemTemp = [];
        let checkChanges = false;

        for (var itema of this.factoryOptions) {
            factoryItemTemp.push(itema.factoryItem);
        }
        for (var i = 0; i < factoryItemTemp.length; i++) {
            for (var j = 0; j < this.factoryOptionsTemp[i]['factoryItem'].length; j++) {
                if (factoryItemTemp[i][j].optionId == this.factoryOptionsTemp[i]['factoryItem'][j].optionId && factoryItemTemp[i][j].isSelected != this.factoryOptionsTemp[i]['factoryItem'][j].isSelected) {
                    checkChanges = true;
                }
            }
        }
        if (checkChanges) {
            let options: NgbModalOptions = { backdrop: 'static', keyboard: false }
            this.hdMessage = "Confirm factory options Changes";
            this.explanation = "Factory options informations have been changed.Please edit the book values.Click Ok to continue.";
            //show modal method call
            this.modalService.open(this.redirect, options);
        }
        else {
            this.onNextButtonClick();
        }
    }

    onFactorySelectioonChange() {

        let IsNothingSelected: boolean;
        IsNothingSelected = true;
        this.errorLable = 'Please select at least one from the below options';

        this.factoryOptions.forEach(x => {
            x.factoryItem.forEach(y => {
                if (y.isSelected) {
                    this.errorLable = '';
                    IsNothingSelected = false;
                }
            })

        });

        if (IsNothingSelected && this.showSaveCloseButtons) {
            this.disableSavebtn = true;
        }
        else {
            this.disableSavebtn = false;
        }

        this.kbbServiceService.ClearKBBFromCache();
    }

    trackFactory(index, factoryOptions) {
        return factoryOptions ? factoryOptions.categoryId : undefined;
    }
    factoryoptionsselectedtemp: any = [];
    processcachedata(data) {

        this.fcatoryOptionsSeleted = [];
        for (var i = 0; i < data.length; i++) {
            for (var j = 0; j < data[i]["factoryItem"].length; j++) {
                if (data[i]["factoryItem"][j].isStandardOption == true) {
                    this.fcatoryOptionsSeleted.push({
                        displayName: data[i]["factoryItem"][j].displayName,
                        Isstandardoptions: true,
                        isSelected: data[i]["factoryItem"][j].isSelected
                    });
                }
            }
        }

    }
    closestandardoptiondata() {

        if (this.temptest != null)
            this.factoryOptions = this.temptest;



    }

    saveadditionaloptionsdata() {
        this.processcachedata(this.factoryOptions);
    }

    //added for chrome 
    CalculateTotalValue(obj: any, el: ChromeFactoryOptions, group: string) {
        debugger;
        let senderUtf: any = obj.source._elementRef.nativeElement.attributes['utf'].value;
        let utfSelector: string = "[utf = '" + senderUtf + "']";
        let senderId: any = obj.source.id;
        let senderOptionKindId = obj.source._elementRef.nativeElement.attributes['optionkindid'].value;
        let optKindSelector: string = "[optionkindid = '" + senderOptionKindId + "']";
        if (senderUtf != "0" && senderUtf != "") {
            this.enableDisable(obj.checked, utfSelector, senderId);

        }
        else if (senderUtf == "") {
            this.enableDisable(obj.checked, optKindSelector, senderId);
        }

        let price: number = el.Price;
        let num = document.getElementById("lblVehicleMSRPValue").innerHTML;
        let msrp = num.toString().replace(/\$|\,|\(|\)/g, '');
        let sum: any;
        let a1: number; let a2: number;
        if (obj.checked) {
            this.sumoption = this.Sum(this.sumoption, price);
            sum = parseFloat(msrp) + this.sumoption;
        }
        else {
            this.sumoption = this.Diff(this.sumoption, price);
            sum = parseFloat(msrp) + this.sumoption;
        }

        this.TotalSum = this.formatCurrency(msrp) + " + " + this.formatCurrency(this.sumoption) + " = " + this.formatCurrency(sum);

    }

    enableDisable(isChecked: boolean, selector: string, senderId: string): void {
        let lstOptKind: any = this.elRef.nativeElement.querySelectorAll(selector);
        if (isChecked) {
            if (lstOptKind.length > 0) {
                for (let element of lstOptKind) {
                    let currentMatChkboxId = element.id;
                    this.elRef.nativeElement.querySelector('#' + currentMatChkboxId).disabled = true;
                    this.elRef.nativeElement.querySelector('#' + currentMatChkboxId).checked = false;
                    this.elRef.nativeElement.querySelector('#' + currentMatChkboxId).classList.add('disabled');

                    element.querySelector('input[type="checkbox"]').disabled = true;
                    element.querySelector('input[type="checkbox"]').checked = false;
                    element.querySelector('input[type="checkbox"]').classList.add('disabled');

                    this.elRef.nativeElement.querySelector('.mat-checkbox-background').style.backgroundColor = '';
                }
            }

            this.elRef.nativeElement.querySelector('#' + senderId).disabled = false;
            this.elRef.nativeElement.querySelector('#' + senderId).checked = true;
            this.elRef.nativeElement.querySelector('#' + senderId).classList.remove('disabled');

            this.elRef.nativeElement.querySelector('#' + senderId).querySelector('input[type="checkbox"]').disabled = false;
            this.elRef.nativeElement.querySelector('#' + senderId).querySelector('input[type="checkbox"]').checked = true;
            this.elRef.nativeElement.querySelector('#' + senderId).querySelector('input[type="checkbox"]').classList.remove('disabled');
        }
        else {
            if (lstOptKind.length > 0) {
                for (let element of lstOptKind) {
                    let ecurrentMatChkboxId = element.id;
                    element.querySelector('input[type="checkbox"]').disabled = false;
                    element.querySelector('input[type="checkbox"]').checked = false;
                    this.elRef.nativeElement.querySelector('#' + ecurrentMatChkboxId).classList.remove('disabled');
                    this.elRef.nativeElement.querySelector('#' + ecurrentMatChkboxId).disabled = false;
                    element.querySelector('input[type="checkbox"]').classList.remove('disabled');
                    //this.elRef.nativeElement.querySelector('.mat-checkbox-background').style.backgroundColor = '';
                }

            }
        }

    }


    Sum(a1, a2) {
        return parseFloat(a1 + a2);
    }
    Diff(a1, a2) {
        return (parseFloat(a1) - parseFloat(a2));
    }


    formatCurrency(num) {
        num = num.toString().replace(/\$|\,|\(|\)/g, '');
        if (isNaN(num)) num = "0";
        let sign: any = (num == (num = Math.abs(num)));
        num = Math.floor(num * 100 + 0.50000000001);
        let cents: any = num % 100;
        num = Math.floor(num / 100).toString();
        if (cents < 10) cents = "0"; //  + cents;
        for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
            num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
        if (sign) return ('$ ' + num); // + '.' + cents);
        else return ("(" + '$ ' + num + ")");  // + '.' + cents);
    }
    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }

    HideShowCategory(id, SectionName) {

        for (var category of this.grChromefactoryoptions) {
            if (category.Header == SectionName) {
                let contentDiv = this.elRef.nativeElement.querySelector('#factoryContent' + id);
                let icon = this.elRef.nativeElement.querySelector('#factoryIcon' + id);
                this.ShowHide(icon, contentDiv, category);
            }

        }
    }

    ShowHide(icon: any, contentDiv: any, category: GroupedChromeFactoryOptions): void {
        if (contentDiv.classList.contains('collapse')) {
            contentDiv.classList.remove('collapse');
            icon.classList.add('fa-minus-square');
            icon.classList.remove('fa-plus-square');

            // css effect 
            this.ChromeOptionsReset(contentDiv, category);

        } else {
            contentDiv.classList.add('collapse');
            icon.classList.add('fa-plus-square');
            icon.classList.remove('fa-minus-square');

        }
    }
    ChromeOptionsReset(contentDiv: any, category: GroupedChromeFactoryOptions) {

        for (let opt of category.Options) {
            if (opt.isSelected) {
                if (opt.Utf != "0") {
                    let lstUtf: any = contentDiv.querySelectorAll("[utf='" + opt.Utf + "']");
                    if (lstUtf.length > 0) {
                        for (let element of lstUtf) {
                            let currentMatChkboxId = element.id;
                            if (!element.querySelector('input[type="checkbox"]').checked) {
                                this.elRef.nativeElement.querySelector('#' + currentMatChkboxId).disabled = true;
                                this.elRef.nativeElement.querySelector('#' + currentMatChkboxId).checked = false;
                                if (!this.elRef.nativeElement.querySelector('#' + currentMatChkboxId).classList.contains('disabled'))
                                    this.elRef.nativeElement.querySelector('#' + currentMatChkboxId).classList.add('disabled');


                                element.querySelector('input[type="checkbox"]').disabled = true;
                                element.querySelector('input[type="checkbox"]').checked = false;
                                if (!element.querySelector('input[type="checkbox"]').classList.contains('disabled'))
                                    element.querySelector('input[type="checkbox"]').classList.add('disabled');

                                this.elRef.nativeElement.querySelector('.mat-checkbox-background').style.backgroundColor = '';
                            }

                        }
                    }
                }


            }
        }


    }
    GetServiceDate(InServiceDate) {
        if (InServiceDate != undefined && InServiceDate != '') {
            var myDate = InServiceDate.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3");
            this.InServiceDate = parseDate(this.datePipe.transform(myDate, "MM/dd/yyyy"));
        }
        else {
            if (this.Year != null) {
                let date: Date = new Date();
                date.setFullYear(this.Year);
                this.InServiceDate = parseDate(this.datePipe.transform(date, "MM/dd/yyyy"));
            }
        }
        this.persistServiceDate(this.InServiceDate);

    }
}


