import { Component, OnInit, ElementRef, Input, AfterViewChecked} from '@angular/core';
import { VehicleParams } from '../Model/vehicle-params.model';
import { Vehicle } from '../Model/vehicle';
import { KBBServiceService } from '../Services/kbbservice.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-appraisal-steps',
    templateUrl: './appraisal-steps.component.html',
    styleUrls: ['./appraisal-steps.component.css']
}) 
export class AppraisalStepsComponent implements OnInit {
    public myInnerHeight: Number;
    public myInnerHeightVehicle: Number;
    showPricingStep: boolean = false;
    @Input() appraisalPayload: any;
    params: VehicleParams;
    vinVehicleDetails: Vehicle;
    FormInvalid: boolean = false;
    IsProspectIdExists: boolean;
    public isFinishEnable: boolean = false;
    isPendingAppraisal: boolean = false;
    isVehicleInfoNextEnabled: boolean;
    isAfterMarketNextEnabled: boolean;
    isHistoryNextEnabled: boolean;
    isConditionNextEnabled: boolean;
    isBooksPreviousDisabled: boolean;
    isPricePreviousDisabled: boolean;
    busyBook: Subscription;
    

    isFullWizard: boolean = true;
    initialStepCount = 1;
    constructor(private elRef: ElementRef, private kbbService: KBBServiceService) {
        this.vinVehicleDetails = new Vehicle();
        this.params = new VehicleParams();
        //window.onresize = (e) => {
        //    this.ngZone.runOutsideAngular(() => {
        //       this.myInnerHeight = (window.innerHeight - ((this.elRef.nativeElement.querySelector('#KBBHeader').clientHeight) + (this.elRef.nativeElement.querySelector('.footerHeight').clientHeight) + 180));
        //    });

        //};
        this.IsProspectIdExists = kbbService.IsProspectIdExists;
        kbbService.IsProspectIdExistsChange.subscribe((value) => {
            this.IsProspectIdExists = value;
        });
        this.kbbService.isFinishEnable.subscribe((value) => {
            this.isFinishEnable = value;
        });
        kbbService.KbbDecodeCompleteChange.subscribe(value => {
            this.isVehicleInfoNextEnabled = value;
        });
        kbbService.isAfterMarketEnable.subscribe((value) => {
            this.isAfterMarketNextEnabled = value;
        });
        kbbService.isHistoryEnable.subscribe((value) => {
            this.isHistoryNextEnabled = value;
        });
        kbbService.isConditionEnable.subscribe((value) => {
            this.isConditionNextEnabled = value;
        });
        kbbService.isFinishBookDisable.subscribe((value) => {
            this.isBooksPreviousDisabled = value;
            if (value == true) {
                this.busyBook = kbbService.isFinishBookDisable.subscribe();
            }
        });
        kbbService.isFinishPriceDisable.subscribe((value) => {
            this.isPricePreviousDisabled = value;
        });

        kbbService.isWizardStep.subscribe((value) => {
            if (value) {
                this.currentStep = 1;
                this.visitedStep = 1;
            }
        });

        
    }

    //for dynamic height 
    //ngAfterViewChecked() {
    //    setTimeout(_ => this.setHeight());
    //}
    setHeight() {
        if (this.isPendingAppraisal)
            this.myInnerHeight =
                (window.parent.innerHeight - ((this.elRef.nativeElement.querySelector('#KBBHeader').clientHeight) + (this.elRef.nativeElement.querySelector('.footerHeight').clientHeight) + 180));
        else
            this.myInnerHeight = (window.innerHeight - ((this.elRef.nativeElement.querySelector('#KBBHeader').clientHeight) + (this.elRef.nativeElement.querySelector('.footerHeight').clientHeight) + 180));

    }

    visitedVehicleInfo: Boolean = false;
    MainScreens: Array<String> = ['Options', 'Aftermarket', 'History', 'Condition', 'Contact', 'Review'];
    currentStepName: string[] = ['Vehicle Information', 'Options', 'Aftermarket', 'History', 'Condition', 'Books', 'Pricing'];

    currentStep: number = 1;
    visitedStep: number = 1;
    visitedOptions: Boolean;
    visitedAfterMarket: Boolean;
    visitedHistory: Boolean;
    visitedCondition: Boolean;
    visitedBooks: Boolean;

    wizardStepChange(clickedStepNumb, isNextPreviousClick = false) {
        if (this.kbbService.vinVehicleDetails.Mileage == null) {
            return false;
        }

        if (clickedStepNumb == 2 ) {
            let vehForm = document.getElementById('VehicleInfoForm');
            if (vehForm != null) {
                if (vehForm.classList.contains('ng-invalid')) {
                    this.FormInvalid = true;
                } else {
                    this.FormInvalid = false;
                }
            }
        }

        if (!this.FormInvalid) {
            if (clickedStepNumb > this.currentStep && isNextPreviousClick || clickedStepNumb <= this.visitedStep) {
                if (clickedStepNumb <= this.visitedStep + 1)  {
                    this.currentStep = clickedStepNumb;
                    if (clickedStepNumb > this.visitedStep)
                        this.visitedStep = clickedStepNumb;
                }
            } else if (clickedStepNumb < this.currentStep) {
                this.currentStep = clickedStepNumb;
            }
        }
        if (clickedStepNumb == 6 && this.showPricingStep == true) {
            this.isBooksPreviousDisabled = false;
        }

    }



    ngOnInit() {
        if (this.appraisalPayload != null || this.appraisalPayload != undefined) {
            let appraisalPayloadJson: any = JSON.parse(this.appraisalPayload);
            this.params.VIN = appraisalPayloadJson.vin;
            this.params.Mileage = appraisalPayloadJson.mileage;
            this.params.StoreId = appraisalPayloadJson.storeId;
            this.params.InventoryType = appraisalPayloadJson.inventoryType;
            this.params.VehicleId = appraisalPayloadJson.vehicleId;
            this.params.InventoryId = appraisalPayloadJson.invtrId;
            this.params.SourceType = appraisalPayloadJson.sourceType;
            this.params.UserName = appraisalPayloadJson.userName;
            this.params.CurrStoreID = appraisalPayloadJson.currStoreId;
            this.params.IsKbbVehicle = appraisalPayloadJson.isKbbVehicle;
            this.params.editMode = appraisalPayloadJson.isEdit;
            this.params.IsKbbFailure = appraisalPayloadJson.isKbbFailure;
            this.params.isStep5Exists = appraisalPayloadJson.isStep5Exists;
            this.params.Decode_Type = appraisalPayloadJson.Decode_Type;
            this.params.isCCAVehicle = appraisalPayloadJson.isCCAVehicle;
            if (this.params.SourceType == 40 || this.params.SourceType == 20 || this.params.isStep5Exists) {
                this.showPricingStep = true;
                this.initialStepCount = 0;
            }
            //if (this.params.SourceType == 40 || this.params.SourceType == 20) {
            //    this.showPricingStep = true;
            //}
            //Added for pending appraisal height adjustment starts
            if (appraisalPayloadJson.isPendingAppraisal) {
                this.isPendingAppraisal = true;
            }
            //Added for pending appraisal height adjustment end

            this.onResize(null);
        }
    }

   
    onResize(event) {
        if (window.innerWidth > 768) {
            this.isFullWizard = true;
        }
        else { this.isFullWizard = false; }
    }
}
