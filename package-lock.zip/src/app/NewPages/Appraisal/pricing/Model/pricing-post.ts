export class pricingpost {
    public VehicleID: number;
    public StoreID: number;
    public  InvtrID: number;
    public IsChecked: boolean;
    public SuggestedPrice: string;
    public RASuggestedPrice: string;
    public hdnnewconditionValue: string;
    public UserName: string;
    public UnseenAppraisalValue: number;
    public AppraisalValue: number;
    public MarketValue: string;
}

       