export class pricing {
    //Button
    public btnGetRetailPriceVisible: boolean;

    //Retail Text
    public txtRetailPriceValueVisible: boolean;
    public  txtRetailPriceValueText :string;

    //RA Suggested 
   
    public  lblRASuggestedPriceText :string;

    //Retail
    public lblRetailPriceValueText: string;
    public lblRetailPriceValueVisible: boolean;          
    public lblRetailPriceVisible: boolean;
    public lblRetailPriceText: string;

    //Pricing Factors
        public  lblPeriodText: string;
        public  lblMileageText : string;
        public  lblRangeText : string;
        public  lblSales0Text : string;
        public  lblSales1Text : string;
        public  lblSales2Text : string;
        public  lblSales3Text : string;
        public  lblSales4Text : string;
        public  lblSales5Text : string;
        public  lblSales6Text : string;
        public  lblSales7Text : string;
        public  lblSales8Text : string;
        public  lblSales9Text : string;

        public  lblListing0Text : string;
        public  lblListing1Text : string;
        public  lblListing2Text : string;
        public  lblListing3Text : string;
        public  lblListing4Text : string;
        public  lblListing5Text : string;
        public  lblListing6Text : string;
        public  lblListing7Text : string;
        public  lblListing8Text : string;
        public  lblListing9Text : string;
        public  lblListing10Text : string;
        public  lblListing11Text : string;
        public  lblListing12Text : string;
        public  lblListing13Text : string;
        public  lblListing14Text : string;
        public lblListing15Text: string;
        public hdnnewconditionValue: string;

   
    public MarketValueLabel: number;
    public MarketValueLabelVisble: boolean;
    public MarketValuetextVisble: boolean;
    public MarketValueText: number;

    public lblConditionText: number;

    public txtAppraisalValueVisible: boolean;
    public txtUnseenAppValueVisible: boolean;
    public UnseenAppraisalValue: string;
    public AppraisalValueText: number;
    public AppraisalValueTextUnseen: number;
    public lblAppraisalValueVisible: boolean;
    public AppraisalValueLabel: string;
    public PricingAccessible: boolean;
    public txtUnseenAppValueText: string;
    public txtAppraisalValueText: string;
}

       