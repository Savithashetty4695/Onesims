import { Component, OnInit,ViewChild} from '@angular/core';
import {Response} from '@angular/http';
import {KBBServiceService} from '../Services/kbbservice.service';
import {VinVehicleDetails} from '../Model/vin-vehicle-details';
import {HttpServiceService} from '../Services/http-service.service';
import {VehicleParams} from '../Model/vehicle-params.model';
import {pricing} from './Model/pricing-get';
import {pricingpost} from './Model/pricing-post';
import {ErrorHandler}from '../common/error-handler';
import {SIMSResponseData} from '../model/simsresponse-data';
import {LinkEnum} from '../Model/link-enum.enum';
import { BookValue } from '../book-values/model/book-value';
import { Subscription } from 'rxjs';
import { NgbModal, ModalDismissReasons, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-pricing',
    templateUrl: './pricing.component.html',
    styleUrls: ['./pricing.component.css']
})
export class PricingComponent implements OnInit {
    indexCounter: number;
    PricingDetails: pricing;
    PricingDetailspost: pricingpost;
    vehicleparams: VehicleParams;
    responsesave: SIMSResponseData;
    errorHandler: ErrorHandler;
    checked: boolean;
    showModal: boolean = false;
    isKBBFailure: boolean;
    url: string;
    params: VehicleParams;
    offerDetails: SIMSResponseData;
    busyA: Subscription;
    busyB: Subscription;

    busyManheim: Subscription;
    busyNADA: Subscription;
    busyBlackBook: Subscription;
    busyKBB: Subscription;
    busyAll: Subscription;
    busyBooks: Subscription;
    BindBlackBook: BookValue;
    BindManheim: BookValue;
    BindNADA: BookValue;
    BindKBB: BookValue;
    BlackBook: string;
    Manheim: string;
    NADA: string;
    KBB: string;
    suggestedPrice: string;
    lblsugestedprice: string;
    public showLabels = true;
    public showTicks = true;
    public reverse = false;

    public startAngle = 0;
    public endAngle = 180;
    public rangeSize = 40;

    public rangeLineCap = 'round';

    public rangePlaceholderColor = '#e6e5e5';
    public ticksColor = '#009000';
    public labelsColor = '#DE884D';
    public above: number;
    public below: number;
    public average: number;
    public majorUnit: number;
    public value: number;

    public firstRangeLow: number;
    public firstRangeHigh: number;
    public secondRangeLow: number;
    public secondRangeHigh: number;
    public thirdRangeLow: number;
    public thirdRangeHigh: number;
    @ViewChild('wholesale') wholeSale: any;
    vehicleSource: number;
    origin: string;
    pricfactor: boolean;
    appraisal: boolean;
    PrintAppDisable: boolean;

    isMarketValueKeyPressed: boolean;
    whoMarketValue: any;
    tempMarketValue: any;
    tempMarket: any;
    htmlMarketValueElement: any;
    MarketValueLabelVisble: boolean;
    MarketValuetextVisble: boolean;
    
    isUnseenAppraisalValueKeyPressed: boolean;
    ApprisalValueLabelVisbleUnseen: boolean;
    ApprisalValuetextVisbleUnseen: boolean;

    isAppraisalValueKeyPressed: boolean;
    ApprisalValueLabelVisble: boolean;
    ApprisalValuetextVisble: boolean;

    whoAppraisalValue: any;
    tempAppraisalValue: any;

    htmlAppraisalValueElement: any;
    tempAppraisal: any;

    whoUnseenAppraisalValue: any;
    tempUnseenAppraisalValue: any;
    htmlUnseenAppraisalValueElement: any;
    tempUnseenAppraisal: any;

    showSightUnSeenAppraisalValue: boolean;
    showAppraisalValue: boolean;

    constructor(public kbbServiceService: KBBServiceService, public httpService: HttpServiceService, public modalService: NgbModal) {
        this.params = new VehicleParams();
        this.offerDetails = new SIMSResponseData();
        this.PricingDetails = new pricing();
        this.vehicleparams = new VehicleParams();
        this.PricingDetailspost = new pricingpost();
        this.errorHandler = new ErrorHandler();
        this.checked = false;
        this.BindBlackBook = new BookValue();
        this.BindManheim = new BookValue();
        this.BindNADA = new BookValue();
        this.BindKBB = new BookValue();
        this.BlackBook = "BlackBook";
        this.Manheim = "Manheim";
        this.NADA = "NADA";
        this.KBB = "KBB";


    }



    ngOnInit() {

        this.vehicleparams = this.kbbServiceService.getVehicleParameters();
        this.isKBBFailure = this.vehicleparams.IsKbbFailure;
        let blackbookcache = this.kbbServiceService.GetBalckBookFromCache();
        this.BindBlackBook = blackbookcache;
        let Manheimcache = this.kbbServiceService.GetManhaimFromCache();
        if (Manheimcache != undefined && Manheimcache != null) {

            this.BindManheim = Manheimcache;
        }
        if (this.BindManheim != undefined && this.BindManheim != null) {
            this.LoadMMRValues(this.BindManheim);
        }
        let NADAcache = this.kbbServiceService.GetNADAFromCache();
        this.BindNADA = NADAcache;
        let KBBcache = this.kbbServiceService.GetKBBFromCache();
        this.BindKBB = KBBcache;
        this.PrintAppDisable = true;
        this.vehicleSource = this.vehicleparams.SourceType;
        if (this.vehicleSource == 10 || this.vehicleSource == 30 || this.vehicleSource == 60 || this.vehicleSource == 100 || this.vehicleSource == 70) {
            this.origin = "appraisal";
            this.appraisal = true;
            //this.PrintAppDisable = false;
        }
        else {
            this.origin = "inventory";
            this.pricfactor = true;
            this.PrintAppDisable = false;
            //this.PrintAppDisable = false;

        }

        if (this.kbbServiceService.vinVehicleDetails.SightUnseen == true) {
            this.showSightUnSeenAppraisalValue = true;
            this.showAppraisalValue = false;
        }
        else {
            this.showAppraisalValue = true;
            this.showSightUnSeenAppraisalValue = false;
        }

        this.MarketValueLabelVisble = false;
        this.PricingDetails.MarketValueLabelVisble = false;
        this.PricingDetails.MarketValuetextVisble = true;
        this.ApprisalValueLabelVisble = false;
        this.MarketValuetextVisble = true;
        this.ApprisalValuetextVisble = true;
        this.ApprisalValueLabelVisbleUnseen = false;
        this.ApprisalValuetextVisbleUnseen = true;



        let cachedaPricingOptions = this.kbbServiceService.GetPricingFromCache(this.vehicleparams);
        if (cachedaPricingOptions == undefined) {            
            if (this.PricingDetails.lblRASuggestedPriceText == null || this.PricingDetails.lblRASuggestedPriceText == undefined) {
                this.lblsugestedprice = this.kbbServiceService.suggestedPrice;
            }
        }
        if (cachedaPricingOptions != undefined)
        {
            this.PricingDetails = cachedaPricingOptions;
            if (this.PricingDetails.MarketValueText > 0 && this.PricingDetails.MarketValueText != undefined) {
                if ((this.PricingDetails.AppraisalValueText > 0
                    && this.PricingDetails.AppraisalValueText != undefined)
                    || (this.PricingDetails.AppraisalValueTextUnseen > 0
                        && this.PricingDetails.AppraisalValueTextUnseen != undefined))
                    this.PrintAppDisable = false;
            }
            if (this.PricingDetails.PricingAccessible == false)
                this.PrintAppDisable = false;
        }
        else
            this.busyA = this.kbbServiceService.GetPricing(this.vehicleparams).subscribe(
                (result: pricing) => {
                    (this.PricingDetails = result);
                    this.PricingDetails.MarketValueLabelVisble = false;
                    this.PricingDetails.MarketValuetextVisble = true;
                    this.PricingDetails.txtUnseenAppValueVisible = this.kbbServiceService.vinVehicleDetails.SightUnseen;
                    if (this.PricingDetails.txtUnseenAppValueVisible) {
                        if (this.PricingDetails.txtUnseenAppValueText != null && this.PricingDetails.txtUnseenAppValueText != undefined && this.PricingDetails.txtUnseenAppValueText != '') {
                            this.PricingDetails.AppraisalValueTextUnseen = Number(this.PricingDetails.txtUnseenAppValueText)
                            this.PricingDetails.MarketValueText = this.PricingDetails.AppraisalValueTextUnseen + Number(this.PricingDetails.lblConditionText);
                            this.PrintAppDisable = false;
                        }
                    }
                    else {
                        if (this.PricingDetails.txtAppraisalValueText != null && this.PricingDetails.txtAppraisalValueText != undefined && this.PricingDetails.txtAppraisalValueText) {
                            this.PricingDetails.AppraisalValueText = parseInt(this.PricingDetails.txtAppraisalValueText)
                            this.PricingDetails.MarketValueText = this.PricingDetails.AppraisalValueText + Number(this.PricingDetails.lblConditionText);
                            this.PrintAppDisable = false;
                        }
                    }
                    if (this.PricingDetails.PricingAccessible == false)
                        this.PrintAppDisable = false;
                    this.persistPricingData();
                },
                (error: Response | any) => this.errorHandler.handleError(error));

    }
    HideMMRHtml() {
        var texts = document.getElementsByTagName('text');
        if (texts.length > 0) {
            texts[0].textContent = '';
            texts[1].textContent = this.formatCurrency(this.below.toString());
            texts[2].textContent = this.formatCurrency(this.average.toString());
            texts[3].textContent = this.formatCurrency(this.above.toString());
        }
        if (texts.length >= 5) {
            texts[4].textContent = '';
        }
    }

    formatCurrency(num) {
        num = num.toString().replace(/\$|\,|\(|\)/g, '');
        if (isNaN(num)) num = "0";
        let sign: any = (num == (num = Math.abs(num)));
        num = Math.floor(num * 100 + 0.50000000001);
        let cents: any = num % 100;
        num = Math.floor(num / 100).toString();
        if (cents < 10) cents = "0"; //  + cents;
        for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
            num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
        if (sign) return ('$ ' + num); // + '.' + cents);
        else return ("(" + '$ ' + num + ")");  // + '.' + cents);
    }
    LoadMMRValues(data) {
        this.above = data.WholeSaleAbove;
        this.below = data.WholeSaleBelow;
        this.average = data.WholeSaleAverage;
        this.majorUnit = this.average - this.below;
        this.firstRangeLow = this.below - this.majorUnit;
        this.firstRangeHigh = this.below;
        this.secondRangeLow = this.below;
        this.secondRangeHigh = this.above;
        this.thirdRangeLow = this.above;
        this.thirdRangeHigh = this.above + this.majorUnit;
        this.value = data.NationalAverage;
        setTimeout(() => {    //<<<---    using ()=> syntax
            this.HideMMRHtml();
        }, 1000);
        //var texts = document.getElementsByTagName('text');
        //for (let i = 0; i < texts.length; i++) {
        //    var a = texts[i].innerHTML;
        //    if (a === this.firstRangeLow.toString() || a === this.thirdRangeHigh.toString()) {
        //        texts[i].innerHTML = null;
        //    }
        //}
    }
    pricingRTC() {
        this.vehicleparams = this.kbbServiceService.getVehicleParameters();
        this.PricingDetails == null;
        this.busyB = this.kbbServiceService.GetPricingRTC(this.vehicleparams).subscribe(
            (result: pricing) => {
                this.PricingDetails = result;
                    this.kbbServiceService.suggestedPrice = result.lblRASuggestedPriceText;
            },
            (error: Response | any) => this.errorHandler.handleError(error));
    }
 

    chekcbox() {
        if (this.checked == true) {
            this.open(this.wholeSale);
        }
    }

    open(content, options: NgbModalOptions = { backdrop: true, keyboard: true }) {

        this.modalService.open(content, options);
    }



    GetOfferDetails() {
        
        this.kbbServiceService.GetOfferDetails(this.vehicleparams).subscribe(
            (result: SIMSResponseData) => result,
            (error: Response | any) => this.errorHandler.handleError(error));
    }

    SavePrice() {
        if (this.isKBBFailure != true || this.isKBBFailure == null) {
            this.GetOfferDetails();
        }
        this.PrintAppDisable = true;
        this.vehicleparams = this.kbbServiceService.getVehicleParameters();
        this.PricingDetailspost == null;
        this.PricingDetailspost.InvtrID = this.vehicleparams.InventoryId;
        this.PricingDetailspost.StoreID = this.vehicleparams.StoreId;
        this.PricingDetailspost.VehicleID = this.vehicleparams.VehicleId;
        this.PricingDetailspost.RASuggestedPrice = this.PricingDetails.lblRASuggestedPriceText;
        this.PricingDetailspost.SuggestedPrice = this.PricingDetails.txtRetailPriceValueText;
        this.PricingDetailspost.hdnnewconditionValue = this.PricingDetails.hdnnewconditionValue;
        this.PricingDetailspost.IsChecked = this.checked;
        this.PricingDetailspost.UserName = this.vehicleparams.UserName;
        this.PricingDetailspost.AppraisalValue = this.PricingDetails.AppraisalValueText;
        this.PricingDetailspost.UnseenAppraisalValue = this.PricingDetails.AppraisalValueTextUnseen;
        this.kbbServiceService.SavePrice(this.PricingDetailspost).subscribe(
            (result) => {
                this.Redirect(result);
                this.kbbServiceService.isFinishPriceDisable.next(true);
            },
            (error: Response | any) => this.errorHandler.handleError(error));

    }
    Redirect(data: any): void {
        if (data != null) {


            if (this.vehicleparams.SourceType == 40) {
                window.top.location.href = '../../Inventory/Pages/Inventory_Log.aspx';
            }
            else if (this.vehicleparams.SourceType == 60 || this.vehicleparams.SourceType == 50) {
                window.top.location.href = '../../Appraisals/Pages/ServiceAppraisalLog.aspx';
            }
            else if (this.vehicleparams.SourceType == 100 || this.vehicleparams.SourceType == 30) {
                window.top.location.href = '../../Appraisals/Pages/AppraisalLog.aspx';
            }
            else if (this.vehicleparams.SourceType == 110) {
                window.top.location.href = '../../Appraisals/Pages/InternetAppraisalLog.aspx';
            }
            else {
                window.top.location.href = '../../Appraisals/Pages/AppraisalLog.aspx';
            }
        }
        //if (data == '200') {
            
        //    window.top.location.href = '../../Inventory/Pages/Inventory_log.aspx';
        //}
    }

    onMarketValueKeyUp(event: any) {
        debugger;
        this.isMarketValueKeyPressed = false;
        event = event || window.event;
        this.whoMarketValue = event.target || event.srcElement, this.tempMarketValue;
        if (this.whoMarketValue != null && this.whoMarketValue != undefined) {
            this.tempMarketValue = this.validDigits(this.whoMarketValue.value);
            this.whoMarketValue.value = this.addCommas(this.tempMarketValue);
        }
        this.updateMarketValue(event.currentTarget.value);
        this.persistPricingData();
    }

    onMarketValueBlur() {
        debugger;
        this.htmlMarketValueElement = document.getElementById('txtMarket');
        if (this.htmlMarketValueElement != undefined && this.htmlMarketValueElement != null) {
            this.tempMarket = parseFloat(this.validDigits(this.htmlMarketValueElement.value));
            if (this.tempMarket) this.htmlMarketValueElement.value = this.addCommas(this.tempMarket);
        }

        this.updateMarketValue(this.tempMarket.value);
        this.onMarket();
    }

    onKeypress(event: any) {
        debugger;
        event = event || window.event;
        let charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }

    onMarket() {
        this.persistPricingData();
        debugger;
        if (this.PricingDetails.txtUnseenAppValueVisible == true) {
            this.PrintAppDisable = false;
            this.ApprisalValueLabelVisbleUnseen = false;
            this.ApprisalValuetextVisbleUnseen = true;
            this.PricingDetails.AppraisalValueTextUnseen = Number(this.PricingDetails.MarketValueText) - Number(this.PricingDetails.lblConditionText);
        }
        else {
            this.ApprisalValueLabelVisble = false;
            this.PrintAppDisable = false;
            this.ApprisalValuetextVisble = true;
            this.PricingDetails.AppraisalValueText = Number(this.PricingDetails.MarketValueText) - Number(this.PricingDetails.lblConditionText);
        }
    }

    onAppr() {
        this.persistPricingData();
        debugger;
        if (this.PricingDetails.AppraisalValueText == null) {
            this.PrintAppDisable = true;
        }
        else {
            this.PrintAppDisable = false;
        }
        this.PricingDetails.MarketValueLabelVisble = false;
        this.PricingDetails.MarketValuetextVisble = true;
        this.PricingDetails.MarketValueText = Number(this.PricingDetails.AppraisalValueText) + Number(this.PricingDetails.lblConditionText);

    }

    onAppraisalValueKeyUp(event: any) {
        debugger;
        this.isAppraisalValueKeyPressed = false;
        event = event || window.event;
        this.whoAppraisalValue = event.target || event.srcElement, this.tempAppraisalValue;
        if (this.whoAppraisalValue != null && this.whoAppraisalValue != undefined) {
            this.tempAppraisalValue = this.validDigits(this.whoAppraisalValue.value);
            this.whoAppraisalValue.value = this.addCommas(this.tempAppraisalValue);
        }
        if (this.tempAppraisalValue == "") {
            this.PrintAppDisable = true;
        }
        else {
            this.PrintAppDisable = false;
        }
        this.updateAppraisalValue(event.currentTarget.value);
        this.persistPricingData();
    }

    onAppraisalValueBlur() {
        debugger;
        this.htmlAppraisalValueElement = document.getElementById('txtAppraisal');
        if (this.htmlAppraisalValueElement != undefined && this.htmlAppraisalValueElement != null) {
            this.tempAppraisal = parseFloat(this.validDigits(this.htmlAppraisalValueElement.value));
            if (this.tempAppraisal) this.htmlAppraisalValueElement.value = this.addCommas(this.tempAppraisal);
        }

        if (this.validDigits(this.htmlAppraisalValueElement.value) == "") {
            this.PrintAppDisable = true;
        }
        this.updateAppraisalValue(this.tempAppraisal.value);
        this.onAppr();
    }

    onApprUnseen() {
        this.persistPricingData();
        if (this.PricingDetails.AppraisalValueTextUnseen == null) {
            this.PrintAppDisable = true;
        }
        else {
            this.PrintAppDisable = false;
        }
        this.PricingDetails.MarketValueLabelVisble = false;
        this.PrintAppDisable = false;
        this.PricingDetails.MarketValuetextVisble = true;
        this.PricingDetails.MarketValueText = Number(this.PricingDetails.AppraisalValueTextUnseen) + Number(this.PricingDetails.lblConditionText);
    }

    onUnseenAppraisalValueKeyUp(event: any) {
        debugger;
        this.isUnseenAppraisalValueKeyPressed = false;
        event = event || window.event;
        this.whoUnseenAppraisalValue = event.target || event.srcElement, this.tempUnseenAppraisalValue;
        if (this.whoUnseenAppraisalValue != null && this.whoUnseenAppraisalValue != undefined) {
            this.tempUnseenAppraisalValue = this.validDigits(this.whoUnseenAppraisalValue.value);
            this.whoUnseenAppraisalValue.value = this.addCommas(this.tempUnseenAppraisalValue);
        }
        if (this.tempUnseenAppraisalValue == "") {
            this.PrintAppDisable = true;
        }
        else {
            this.PrintAppDisable = false;
        }
        this.updateUnseenAppraisalValue(event.currentTarget.value);
        this.persistPricingData();
    }

    onUnseenAppraisalValueBlur() {
        debugger;
        this.htmlUnseenAppraisalValueElement = document.getElementById('txtUnseenAppraisal');
        if (this.htmlUnseenAppraisalValueElement != undefined && this.htmlUnseenAppraisalValueElement != null) {
            this.tempUnseenAppraisal = parseFloat(this.validDigits(this.htmlUnseenAppraisalValueElement.value));
            if (this.tempUnseenAppraisal) this.htmlUnseenAppraisalValueElement.value = this.addCommas(this.tempUnseenAppraisal);
        }

        if (this.validDigits(this.htmlUnseenAppraisalValueElement.value) == "") {
            this.PrintAppDisable = true;
        }
        this.updateUnseenAppraisalValue(this.tempUnseenAppraisal.value);
        this.onApprUnseen();
    }


    // return integers and decimal numbers from input
    // optionally truncates decimals- does not 'round' input
    validDigits(n: any): any {
        n = n.replace(/[^\d\.]+/g, '');
        var ax1 = n.indexOf('.'), ax2 = -1;
        if (ax1 != -1) {
            ++ax1;
            ax2 = n.indexOf('.', ax1);
            if (ax2 > ax1) n = n.substring(0, ax2);
        }
        var num = parseInt(n);
        if (num == 0) {
            n = "";
        }
        if (n <= 0) {
            n = "";
        }
        return n;
    }

    addCommas(n) {
        var rx = /(\d+)(\d{3})/;
        return String(n).replace(/^\d+/, function (w) {
            while (rx.test(w)) {
                w = w.replace(rx, '$1,$2');
            }
            return w;
        });
    }


    updateMarketValue(marketValueAmt: any) {
        debugger;
        this.persistPricingData();
        if (marketValueAmt == undefined) {
            marketValueAmt = (document.getElementById("txtMarket") as HTMLInputElement).value;
        }
        var marketValue = +marketValueAmt;
        if (marketValue == 0) {
            this.PricingDetails.MarketValueText = null;
            return false;
        }

        if (marketValueAmt != null && marketValueAmt != "") {
            var num = marketValueAmt.replace(/,/g, '');
            this.PricingDetails.MarketValueText = +num;
        }
        else {
            this.PricingDetails.MarketValueText = null;
        }

    }

    updateAppraisalValue(appraisalValueAmt: any) {
        this.persistPricingData();
        debugger;
        if (appraisalValueAmt == undefined) {
            appraisalValueAmt = (document.getElementById("txtAppraisal") as HTMLInputElement).value;
        }
        var appraisalValue = +appraisalValueAmt;
        if (appraisalValue == 0) {
            this.PricingDetails.AppraisalValueText = null;
            return false;
        }

        if (appraisalValueAmt != null && appraisalValueAmt != "") {
            var num = appraisalValueAmt.replace(/,/g, '');
            this.PricingDetails.AppraisalValueText = +num;
        }
        else {
            this.PricingDetails.AppraisalValueText = null;
        }

    }

    updateUnseenAppraisalValue(unseenAppraisalValueAmt: any) {
        debugger;
        this.persistPricingData();
        if (unseenAppraisalValueAmt == undefined) {
            unseenAppraisalValueAmt = (document.getElementById("txtUnseenAppraisal") as HTMLInputElement).value;
        }
        var appraisalValue = +unseenAppraisalValueAmt;
        if (appraisalValue == 0) {
            this.PricingDetails.AppraisalValueTextUnseen = null;
            return false;
        }

        if (unseenAppraisalValueAmt != null && unseenAppraisalValueAmt != "") {
            var num = unseenAppraisalValueAmt.replace(/,/g, '');
            this.PricingDetails.AppraisalValueTextUnseen = num;
        }
        else {
            this.PricingDetails.AppraisalValueTextUnseen = null;
        }

    }

    persistPricingData() {
        debugger;
        this.kbbServiceService.setData(this.PricingDetails, LinkEnum.GetPricing);
        if (this.PricingDetails.PricingAccessible == false) {
            this.PrintAppDisable = false;
        }
    }

    PrintBookout() {
        window.open("../../Reports/Pages/PrintandSaveBookout.aspx?VehicleID=" + this.vehicleparams.VehicleId + "&StoreID=" + this.vehicleparams.StoreId + "&InvID=" + this.vehicleparams.InventoryId);
    }
    PrintAppraisal() {
        window.open("../../Reports/Pages/PrintAppraisal.aspx?VehicleID=" + this.vehicleparams.VehicleId + "&StoreID=" + this.vehicleparams.StoreId + "&InvID=" + this.vehicleparams.InventoryId + "&SightUnSeen=" + this.kbbServiceService.vinVehicleDetails.SightUnseen + "&AppraisalValue=" + this.PricingDetails.AppraisalValueText);
    }


}


