import { Component, OnInit } from '@angular/core';
import {KBBServiceService} from '../Services/kbbservice.service';
import {HttpServiceService} from '../Services/http-service.service';

@Component({
  selector: 'app-image-gallery',
  templateUrl: './image-gallery.component.html',
  styleUrls: ['./image-gallery.component.css']
})
export class ImageGalleryComponent implements OnInit {

    constructor(public kbbServiceService: KBBServiceService, public httpService: HttpServiceService)  { }

  ngOnInit() {
  }

}
