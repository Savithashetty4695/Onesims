import {Response} from '@angular/http';
import { Pipe, PipeTransform, ViewChild } from '@angular/core';
import { Component, OnInit, Input, ElementRef} from '@angular/core';
import {KBBServiceService} from '../Services/kbbservice.service';
import {HttpServiceService} from '../Services/http-service.service';
import { Questions} from '../Model/Questions.model';
import {VehicleParams} from '../Model/vehicle-params.model';
import {ErrorHandler}from '../common/error-handler';
import {LinkEnum} from '../model/link-enum.enum';
import {AnswerModel, Answer} from '../model/answer-model';
import { SIMSResponseData } from '../model/simsresponse-data';
import {AnswerDefault} from '../model/answer-default';
import { Subscription } from 'rxjs';
import { NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

declare var Close: any;

@Component({
    selector: 'app-history',
    templateUrl: './history.component.html',
    styleUrls: ['./history.component.css'],
})
export class HistoryComponent implements OnInit {
    hasError: boolean = false;
    errorMessage: string;
    params: VehicleParams;
    questions: Questions[];
    allquestions: Questions[];
    question: Questions;
    errorHandler: ErrorHandler;
    answer: Answer[];
    answerModel = AnswerModel;
    response: Answer;
    editParams: any;    
    SACStatusID: number;
    isCCAVehicle: boolean = false;
    reqResubmit: boolean = false;
    editMode: boolean = false;
    @ViewChild('resubmitpopup') resubmitpopup: any;
    @Input() showSaveCloseButtons: boolean;
    @Input() kbbEditObject: string;
    who: any;
    temp: any;
    temp1: any;
    hideErrorMessage: boolean;
    htmlAmountElement: any;
    isKeyPressed: Boolean;
    updatedTotalClaim: string;
    enteredClaimValue: number;
    answerdefault: AnswerDefault;
	busyA: Subscription;
	busyB: Subscription;
	busyC: Subscription;

    constructor(public kbbServiceService: KBBServiceService, public httpService: HttpServiceService, private elRef: ElementRef, private modalService: NgbModal) {
        this.params = new VehicleParams();
        this.questions = new Array<Questions>();
        this.allquestions = new Array<Questions>();
        this.question = new Questions;
        this.answer = new Array<Answer>();
        this.answerModel.prototype = new AnswerModel();
        this.answerModel.prototype.Answers = this.answer;
        this.errorHandler = new ErrorHandler();
        this.answerdefault = new AnswerDefault();
    }

    SaveAndNext() {
        if (this.updatedTotalClaim == null) {
            this.hideErrorMessage = false;
        }

        this.kbbServiceService.setData(this.questions, LinkEnum.GetHistory); 
        var count = 0;
        var recCount = 0;
        for (var item of this.questions) {
            var errorLabel = this.elRef.nativeElement.querySelector('#error' + recCount);
            if (item.questionId == 'qp/76/amount') {
                var ans = this.questions.filter(x => x.questionId == 'qp/76')[0].value;
                if (ans != null) {
                    if (ans.toLowerCase() == 'yes') {
                        if (item.value == null || item.value.trim() == '' || item.value == undefined) {
                            count++;
                            errorLabel.innerHTML = 'This field is Required.';
                            this.hasError = true;
                        }
                        else
                        {
                            errorLabel.innerHTML = '';
                            this.constructAnswerObject(item);
                        }
                    }
                    else {
                        errorLabel.innerHTML = '';
                       
                    }
                }
                else {
                    errorLabel.innerHTML = '';
                   
                }
            }
            else if (item.questionId == 'qp/83' || item.questionId == 'qp/124' || item.questionId == 'qp/125' || item.questionId == 'qp/81' || item.questionId == 'qp/17' || item.questionId == 'qp/65') {
            }
            else {
                if (item.value == null || item.value == '' || item.value == undefined) {

                    count++;
                    this.hasError = true;
                    errorLabel.innerHTML = 'This field is Required.';
                }
                else {
                    errorLabel.innerHTML = '';
                    this.constructAnswerObject(item);
                }
            }
            recCount++;
        }

        if (count == 0) {

            this.busyB = this.kbbServiceService.FetchCarfax_Autocheck_RunlistDetails(this.params, LinkEnum.GetFetchCarfax_Autocheck_RunlistDetails).subscribe(
                (result: AnswerDefault) => {
                    //this.Saved(result);
                    this.answerdefault = result;
                    for (var item of this.allquestions) {
                        if (item.questionId == 'qp/83') {
                            item.value = this.answerdefault.IsOriginalOwnor;
                            this.answer.push(item);
                        }
                        else if (item.questionId == 'qp/124') {
                            item.value = this.answerdefault.IsClearHistory;
                            this.answer.push(item);
                        }
                        else if (item.questionId == 'qp/125') {
                            item.value = this.answerdefault.IsRentalCar;
                            this.answer.push(item);
                        }
                        else if (item.questionId == 'qp/81') {
                            item.value = this.answerdefault.IsAutoAction;
                            this.answer.push(item);
                        }
                        else if (item.questionId == 'qp/17') {
                            item.value = this.answerdefault.IsServiceRecordAvailable;
                            this.answer.push(item);
                        }
                    }
                    this.answerModel.prototype.Answers = this.answer;
                    this.answerModel.prototype.InvtrID = this.params.InventoryId;
                    this.answerModel.prototype.StoreID = this.params.StoreId
                    this.answerModel.prototype.VehicleID = this.params.VehicleId;
                    this.answerModel.prototype.UserName = this.params.UserName;

                    // in edit mode check sacstatus
                    if (this.editMode == true && this.SACStatusID == 403 && this.isCCAVehicle == true) {
                        let options: NgbModalOptions = { backdrop: 'static', keyboard: false, windowClass: 'custom-modals' }
                        this.modalService.open(this.resubmitpopup, options);
                        return false;
                    }
                    else {
                        this.SaveDataToDB();
                        return true;
                    }
                });
            return true;
        }
        else return false;

    }

    setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    private SaveDataToDB() {
        this.kbbServiceService.SaveResponse(this.answerModel.prototype, LinkEnum.SaveHistory)
            .subscribe((result: SIMSResponseData) => this.Saved(result), 
                (error: Response | any) => this.errorHandler.handleError(error));
    }

    //Resubmit changes
    ResubmitYes() {
        this.reqResubmit = true;
        this.SaveDataToDB();
        
        return true;
    }

    constructAnswerObject(item: Questions)
    {
        this.response = new Answer();
        this.response.label = item.label;
        this.response.questionId = item.questionId;
        this.response.questionType = item.questionType;
        this.response.tags = item.tags;
        this.response.value = item.value;
        this.response.vehicleConditionCategory = item.vehicleConditionCategory;
        this.response.vehicleConditionCategoryName = item.vehicleConditionCategoryName;
        this.response.vehicleSectionId = item.vehicleSectionId;
        this.response.vehicleSectionName = item.vehicleSectionName;
        this.answer.push(this.response);
    }
    Saved(data) {
        //Data saved sucessfully.
        //Add after save stuffs here.
        if (this.editMode == true) {
            if (this.reqResubmit) {
                this.kbbServiceService.ResubmitSACRecord(this.params, LinkEnum.ResubmitSACRecord).subscribe(
                    (result: SIMSResponseData) => result,
                    (error: Response | any) => this.errorHandler.handleError(error));
            }
            else if (this.SACStatusID == 403 && this.isCCAVehicle == true) {
                this.setCookie("IsResubmit-" + this.params.VehicleId + "-" +
                    this.params.StoreId + "-" +
                    this.params.InventoryId, 1, 1);
            }
            Close(0);
        }
      
    }

    ngOnInit() {
        this.htmlAmountElement = document.getElementById('txtAmount');
        this.params = this.kbbServiceService.getVehicleParameters();
        this.enteredClaimValue = 0;
       
        if (this.kbbEditObject != null) {
            this.params = JSON.parse(this.kbbEditObject.replace(/'/g, '"'));
            this.editMode = true;
            this.SACStatusID = parseInt(this.params.SACStatusID.toString());
            this.isCCAVehicle = this.params.isCCAVehicle;
        }
        
        let cachedHistoryQuestions = this.kbbServiceService.GetQuestionsFromCache(this.params, LinkEnum.GetHistory);
        if (cachedHistoryQuestions != null && cachedHistoryQuestions.length > 0)
        {
            this.questions = cachedHistoryQuestions;
            this.allquestions = cachedHistoryQuestions;
        }
        else {
            this.busyA = this.kbbServiceService.GetQuestionsfromAPI(this.params, LinkEnum.GetHistory).subscribe(
                (result: Questions[]) => {
                    this.questions = result;
                    this.allquestions = result;
                    this.persistHistoryQuestionData(null);
                    this.kbbServiceService.isHistoryEnable.next(true);
                  
                },
                (error: Response | any) => this.errorHandler.handleError(error));
        }
    }
    persistHistoryQuestionData(index?: number) {
        if (index != null)
        {
            var errorLabel = this.elRef.nativeElement.querySelector('#error' + index);
             errorLabel.innerHTML = '';
        }
        this.kbbServiceService.setData(this.questions, LinkEnum.GetHistory);
    }

    updateAmount(qId: any, amount: any) {

        var amountValue = +amount;
        if (amountValue == 0) {
            this.questions.filter(x => x.questionId == 'qp/76/amount')[0].value = null;
            return false;
        }
        if (amount != undefined && amount != null && amount != "") {
            var num = amount.replace(/,/g, '');
            this.questions.filter(x => x.questionId == qId)[0].value = num;
            this.persistHistoryQuestionData();
        }
        else {
            this.questions.filter(x => x.questionId == qId)[0].value = null;
            this.persistHistoryQuestionData();
        }
    }
    
    enableDisable() {
        var item = this.questions.filter((x: Questions) => x.questionId === 'qp/76')[0].value;
        this.updatedTotalClaim = this.questions.filter((x: Questions) => x.questionId === 'qp/76/amount')[0].value;
        if (item != null) {
            if (item.toLowerCase() == 'no' || item.toLowerCase() == 'not sure' || item.toLowerCase() == 'false') {
                this.questions.filter((x: Questions) => x.questionId === 'qp/76/amount')[0].value = null;
                if (this.updatedTotalClaim == null) {
                    this.hideErrorMessage = true;
                }
                return true;
            }
            else { return false; }
        }
        else return true;
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    //Validation for Amount: should accept only a number 

    allowOnlyNumber(event) {
        if (this.isKeyPressed)
            event.preventDefault();
        this.isKeyPressed = true;
        let charCode = (event.which) ? event.which : event.keyCode;
        if ((charCode != 46 && charCode > 31
            && (charCode < 48 || charCode > 57)) || charCode == 13 || charCode == 46) {
            return false;
        }

        var claimKey = +event.key;
        this.enteredClaimValue += claimKey;
        var vinpayOffValue = (<HTMLInputElement>document.getElementById("txtAmount")).value;
        if (this.enteredClaimValue == 0 && vinpayOffValue == '') {
            this.questions.filter(x => x.questionId == 'qp/76/amount')[0].value = null;
            this.hideErrorMessage = false;
            return false;
        }
        else {
            this.hideErrorMessage = true;
        }


        var errorLabel = this.elRef.nativeElement.querySelector('#error' + 5);
        errorLabel.innerHTML = '';
        return true;
    }


    addCommas(n) {
        var rx = /(\d+)(\d{3})/;
        return String(n).replace(/^\d+/, function (w) {
            while (rx.test(w)) {
                w = w.replace(rx, '$1,$2');
            }
            return w;
        });
    }
    // return integers and decimal numbers from input
    // optionally truncates decimals- does not 'round' input
    validDigits(n: any): any {

        n = n.replace(/[^\d\.]+/g, '');
        var ax1 = n.indexOf('.'), ax2 = -1;
        if (ax1 != -1) {
            ++ax1;
            ax2 = n.indexOf('.', ax1);
            if (ax2 > ax1) n = n.substring(0, ax2);
        }
        return n;
    }
   


    onKeyUp(event: any) {
        this.isKeyPressed = false;
        event = event || window.event;
        this.who = event.target || event.srcElement, this.temp;
        if (this.who != undefined && this.who != null) {
            this.temp = this.validDigits(this.who.value);
            this.who.value = this.addCommas(this.temp);
        }

        this.updateAmount('qp/76/amount',event.currentTarget.value);
    }
    keyDownFunction(event) {
        if (event.keyCode == 13) {
            return false;
        }
    }


    onBlur() {
        if (this.htmlAmountElement != undefined && this.htmlAmountElement != null) {
            this.temp1 = parseFloat(this.validDigits(this.htmlAmountElement.value));

            if (this.temp1) this.htmlAmountElement.value = this.addCommas(this.temp1);
            this.updateAmount('qp/76/amount', this.htmlAmountElement.value);
        }
    }


}
