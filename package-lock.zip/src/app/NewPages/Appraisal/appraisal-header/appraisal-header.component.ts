import { Component, OnInit } from '@angular/core';
// import {Response} from '@angular/http';
import { Pipe, PipeTransform } from '@angular/core';
import {KBBServiceService} from '../Services/kbbservice.service';
import {VinVehicleDetails} from '../Model/vin-vehicle-details';
import {HttpServiceService} from '../Services/http-service.service';
import {VehicleParams} from '../Model/vehicle-params.model';
import {Vehicle} from '../Model/vehicle';
import {ErrorHandler}from '../common/error-handler';
import {LinkEnum} from '../Model/link-enum.enum';


@Component({
    selector: 'app-appraisal-header',
    templateUrl: './appraisal-header.component.html'
})
export class AppraisalHeaderComponent implements OnInit {
    indexCounter: number;
    decodeVinVehicleDetails: VinVehicleDetails;
    vinVehicleDetails: Vehicle;
    vehicleparams: VehicleParams;
    errorHandler: ErrorHandler;
    decodeapiVehicleResult: VinVehicleDetails;
    SourceTypeHeader: string;
    vehicleSourceType: string;


    constructor(public kbbService: KBBServiceService, public httpService: HttpServiceService) {
        if (this.decodeVinVehicleDetails == null)
            this.decodeVinVehicleDetails = new VinVehicleDetails();
        if (this.vinVehicleDetails == null)
            this.vinVehicleDetails = new Vehicle();
        this.vehicleparams = new VehicleParams();
        this.errorHandler = new ErrorHandler();
    }
    ngOnInit() {

        this.mapVehicleDetails();
        this.kbbService.VehicleInfoGet$.subscribe(result => {
            this.mapVehicleDetails();
        })

    }

    mapVehicleDetails() {
        let cachedVinVehicleDetails = this.kbbService.GetVehicleDetailsFromCache(this.vehicleparams);
        if (cachedVinVehicleDetails != undefined) {
            this.vinVehicleDetails = cachedVinVehicleDetails;
            if (this.vinVehicleDetails.SourceType == '100' || this.vinVehicleDetails.SourceType == '110') {
                this.vehicleSourceType = 'Purchase';
            }
            else {
                this.vehicleSourceType = 'Trade';
            }
        }
        
    }
}
