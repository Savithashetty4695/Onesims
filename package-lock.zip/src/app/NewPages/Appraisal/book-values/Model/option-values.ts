export class OptionValues {
    Cost: number;
    RetailCost: number;
    Std: string;
    Oa: string;
    TradeInCost: number;
    TradeInXClean: number;
    TradeInAbove: number;
    TradeInAverage: number;
    TradeInBelow: number;
    RetailAbove: number;
    RetailAverage: number;
    RetailBelow: number;
    LoanAbove: number;
    LoanAverage: number;
    LoanBelow: number;
    WSaleAbove: number;
    WSaleAverage: number;
    WSaleBelow: number;
    ID: string;
    Value: string;
    Selected: boolean;
    Code: string;

}
