export class VehicleBookParams {
    VehicleId: number;
    StoreId: number;
    InvtryId: number;
    BookID: number;
    Mileage: number;
    public SourceType: number;
}
