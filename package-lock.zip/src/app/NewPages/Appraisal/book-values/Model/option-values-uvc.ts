import {OptionValues} from './option-values';
export class OptionValuesUVC {
    Uvc: string;
    optionsUVC: OptionValues;
}