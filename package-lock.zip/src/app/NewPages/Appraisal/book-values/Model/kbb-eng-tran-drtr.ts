import {OptionValuesUVC} from './option-values-uvc';
export class KBB_Eng_Tran_DrTr {
    Engine: OptionValuesUVC;
    Transmission: OptionValuesUVC;
    DriveTrain: OptionValuesUVC;
}