export class Store {
    StoreId: number;
    StoreName: string;
    DealershipLogo: string;
    RoleId: string;
    RoleName: string;
    StoreStateID: string;
    OrgType: number;
    MarketID: number;
    tep5_Exists: boolean;
    ReconType: string;

}
