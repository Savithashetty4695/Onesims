import {ValuationData} from './valuation-data';
import {IDValues} from './valuation-data';
export class BookValueRequestPost {
    dealerId: string;
    NadaRegionId: string;
    RegionId: string;
    adpRegionID: string;
    DecodeType: string;
    Millage: number;
    ProviderID: string;
    ExtColor: string;
    valuationData; ValuationData;
}
