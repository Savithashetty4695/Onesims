import {BooksVinVehicleDetailsKBB} from './books-vin-vehicle-details-kbb';

export class VinVehicleDetailBooks {
    BlackBook: BooksVinVehicleDetailsKBB;
    NADA: BooksVinVehicleDetailsKBB;
    KBB: BooksVinVehicleDetailsKBB;
    Mainhaim: BooksVinVehicleDetailsKBB;
    dealerId: string;
    blackBookRegionId: string;
    nadaRegionId: string;
    kbbRegionId: string;
    MainhaimdRegionId: string;

}
