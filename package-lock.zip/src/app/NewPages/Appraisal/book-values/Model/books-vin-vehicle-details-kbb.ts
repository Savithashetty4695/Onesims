export class BooksVinVehicleDetailsKBB {

    public VIN: string;
    public Year: number;
    public NewVehicle: boolean;

    public Uvc: string;

    public Cylinders: number;

    public NoOfDoors: number;

    public ClarificationNeeded: boolean;

    public IsDecodeSuccess: boolean;

    public years: IDValues[];

    public make: IDValues[];

    public EngineDetails: EngineDetails[];

    public Engine: IDValues[];

    public model: IDValues[];

    public bodyStyle: IDValues[];

    public series: IDValues[];

    public Transmission: IDValues[];

    public DriveTrain: IDValues[];

    public ClassOfVehicle: IDValues[];

    public DecodeStatus: IDValues[];

    public DMVClass: IDValues[];

    public ExteriorColor: IDValues[];

    public InteriorColor: IDValues[];

    public InteriorType: IDValues[];

    public Fuel: IDValues[];

    public VehicleType: IDValues[];

    public DMVType: IDValues[];

    public Options: OptionValues[];

    public ModelCode: IDValues[];

    public DealerOption: IDValues[];

    public SourceType: IDValues[];

    public FactoryOptions: FactoryOptions[];

    public OEMExteriorColor: IDValues[];

    public OEMInteriorColor: IDValues[];

    public VehicleMSRP: number;

    public IsFactoryOptionRequired: boolean;

    public StandardEquipment: StandardEquipment[];
    public KbbColorDetails: Datum[];

    //Added for KBB
    public KBBMakeId: number;

    public KBBModelId: number;

    public KBBTrimId: number;

}

export class IDValues {
    public ID: string;
    public Value: string;
    public Selected: boolean;
    public Code: string;
}


export class EngineDetails {

    public Displacement: string;
    public NetTorqueRPM: number;
    public NetTorqueValue: number;
    public HorsepowerRPM: number;
    public HorsepowerValue: number;
    public FuelEfficiencyCity: number;
    public FuelEfficiencyHwy: number;
}



export class OptionValues {

    public Cost: number;

    public TradeInCost: number;

    public Std: string;

    public Oa: string;

    public TradeInXClean: number;

    public TradeInAbove: number;

    public TradeInAverage: number;

    public TradeInBelow: number;

    public RetailAbove: number;

    public RetailAverage: number;
    public RetailCost: number;

    public RetailBelow: number;

    public LoanAbove: number;

    public LoanAverage: number;

    public LoanBelow: number;

    public WSaleAbove: number;

    public WSaleAverage: number;

    public WSaleBelow: number;
    public ID: string;
    public Value: string;
    public Selected: boolean;
    public Code: string;
}

export class KBBColorDetails {
    public data: Datum[];

}

export class Datum {
    public colorId: number;
    public displayName: string;
}

export class StandardEquipment {

    public Mechanical: Mechanical[];

    public Exterior: Exterior[];

    public Entertainment: Entertainment[];

    public Interior: Interior[];

    public Safety: Safety[];
}


export class EquipmentDetails {

    public HeaderName: string;

    public Description: string;

    public TrimID: number[];
}



export class Mechanical extends EquipmentDetails {

}

export class Exterior extends EquipmentDetails {

}

export class Entertainment extends EquipmentDetails {

}

export class Interior extends EquipmentDetails {

}

export class Safety extends EquipmentDetails {

}

export class FactoryOptions {

    public Description: string;


    public Utf: string;


    public OptionKindId: string;


    public Price: number;

    public StyleId: number[];

    public OemCode: string;

}