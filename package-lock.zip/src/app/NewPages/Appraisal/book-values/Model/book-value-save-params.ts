import {BookValue} from './book-value';

export class BookValueSaveParams {
    BookValues: BookValue;
    VehicleId: number;
    StoreId: number;
    InvtryId: number;
    UpdateResponseTableOnly: boolean;
    LaneId: number;
    UserName: string;
}

