export class BookConfiguration {
    RequiredBookIds: number[];
    SetupBookIds: number[];
}
