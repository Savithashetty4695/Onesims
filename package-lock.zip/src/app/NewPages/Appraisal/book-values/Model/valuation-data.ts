import {OptionValues} from './option-values'

export class ValuationData {
    Vin: string;
    NewVehicle: boolean;
    Uvc: string;
    Mileage: number;
    Year: IDValues;
    make: IDValues;
    Engine: IDValues;
    model: IDValues;
    ModelCode: IDValues;
    bodyStyle: IDValues;
    series: IDValues;
    Transmission: IDValues;
    DriveTrain: IDValues;
    ClassOfVehicle: IDValues;
    DecodeStatus: IDValues;

    ExteriorColor: IDValues;
    InteriorColor: IDValues;
    InteriorType: IDValues;
    Fuel: IDValues;
    VehicleType: IDValues;
    DMVType: IDValues;
    Options: OptionValues[];
    RequestXML: string;
    ExtColor: string;
}
export class IDValues {
    ID: string;  
    Value: string;
    Selected: boolean;
    Code: string
    }