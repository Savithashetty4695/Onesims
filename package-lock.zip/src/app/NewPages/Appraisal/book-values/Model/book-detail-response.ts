import {BookValue} from './book-value';
import {ValuationData} from './valuation-data';
export class BookDetailResponse {
    BookValue: BookValue;
    ValuationData: ValuationData;
}
