import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Response } from '@angular/http';
import { BookDetailResponse } from './model/book-detail-response';
import { KBBServiceService } from '../Services/kbbservice.service';
import { HttpServiceService } from '../Services/http-service.service';
import { VehicleParams } from '../Model/vehicle-params.model';
import { VehicleBookParams } from './model/vehicle-book-params';
import { ErrorHandler } from '../common/error-handler';
import { LinkEnum } from '../model/link-enum.enum';
import { SIMSResponseData } from '../model/simsresponse-data';
import { BookValueSaveParams } from './model/book-value-save-params';
import { BookValue } from './model/book-value';
import { ValuationData } from './model/valuation-data';
import { BookConfiguration } from './model/book-configuration';
import { VinVehicleDetailBooks } from './model/vin-vehicle-detail-books';
import { OptionValues } from './model/option-values';
import { Vehicle } from '../Model/vehicle';
import { IDValues } from './model/valuation-data';
import { VinVehicleDetailsKBB } from '../Model/vin-vehicle-details-kbb';
import { BookValueRequestPost } from './model/book-value-request-post';
import { OptionValuesUVC } from './model/option-values-uvc';
import { VinVehicleDetails } from '../Model/vin-vehicle-details';
import { VehicleFactoryOptionsKBB, FactoryOptionsKBB } from '../factory-options/Model/factory-option-post';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-book-values',
    templateUrl: './book-values.component.html',
    styleUrls: ['./book-values.component.css']
})
export class BookValuesComponent implements OnInit {
    @Input() appraisalPayload: any;
    params: VehicleBookParams;
    errorHandler: ErrorHandler;
    BookDetailResponse: BookDetailResponse[];
    BookDetailResponse1: BookDetailResponse[];
    bookValueSaveParams: BookValueSaveParams;
    bookConfiguration: BookConfiguration;
    vinVehicleDetailBooks: VinVehicleDetailBooks;
    vehicleParams: VehicleParams;
    booksJson: any;
    Store_id: number;
    decodeVinVehicleDetailsKBB: VinVehicleDetailsKBB;
    valuationData: ValuationData;
    MainhaimvaluationData: ValuationData;
    BlackbookvaluationData: ValuationData;
    NADAvaluationData: ValuationData;
    KBBvaluationData: ValuationData;
    isFinishButtonClicked: boolean;
    private factoryOptionsData: any[];
    optionValues: OptionValues;
    optionValuesKBB: OptionValues[];
    optionValuesUVC: OptionValuesUVC;
    bookValue: BookValue;
    vinVehicleDetails: Vehicle;
    iDValues: IDValues;
    BlackBook: string;
    Manheim: string;
    NADA: string;
    KBB: string;
    BlackBookRequired: boolean;
    ManhaimRequired: boolean;
    NADARequired: boolean;
    KBBRequired: boolean;
    BlackBookMan: boolean;
    ManhaimMan: boolean;
    NADAMan: boolean;
    KBBMan: boolean;
    KBBDefault: boolean;
    boostap: number;
    isKBBFailure: boolean;
    bookValueRequestPost: BookValueRequestPost;
    public isBBYear: boolean;
    public isBBMake: boolean;
    public isBBModel: boolean;
    public isBBSeriesTrim: boolean;
    public isBBBodyStyle: boolean;
    public isBBOptions: boolean;
    public isMhmYear: boolean;
    public isMhmMake: boolean;
    public isMhmModel: boolean;
    public isMhmSeriesTrim: boolean;
    public isMhmBodyStyle: boolean;
    public isMhmOptions: boolean;
    public isGetProceess: boolean;
    public isNadaYear: boolean;
    public isNadaMake: boolean;
    public isNadaModel: boolean;
    public isNadaSeriesTrim: boolean;
    public isNadaBodyStyle: boolean;
    BindBlackBook: BookValue;
    BindManheim: BookValue;
    BindNADA: BookValue;
    BindKBB: BookValue;
    public isNadaOptions: boolean;
    public isKBBYear: boolean;
    public isKBBMake: boolean;
    public isKBBModel: boolean;
    public isKBBSeriesTrim: boolean;
    public isKBBEngine: boolean;
    public isKBBTransmission: boolean;
    public isKBBDriveTrain: boolean;
    public isKBBOptions: boolean;
    public isSaveBlackBook: boolean;
    public isSaveMainhaim: boolean;
    public isSaveNADA: boolean;
    public isSaveKBB: boolean;
    public isprintbookOut: boolean;
    public isBookNotSaved: boolean;
    public ErrorBlackBook: boolean;
    public ErrorMainhaim: boolean;
    public ErrorNADA: boolean;
    public ErrorMessageBlackBook: string;
    public ErrorMessageMainhaim: string;
    public ErrorMessageNADA: string;
    public ExteriorColor: string;
    public showLabels = true;
    public showTicks = true;
    public reverse = false;

    public startAngle = 0;
    public endAngle = 180;
    public rangeSize = 40;

    public rangeLineCap = 'round';

    public rangePlaceholderColor = '#e6e5e5';
    public ticksColor = '#009000';
    public labelsColor = '#DE884D';
    public above: number;
    public below: number;
    public average: number;
    public majorUnit: number;
    public value: number;

    public firstRangeLow: number;// this.below;
    public firstRangeHigh: number;// this.below + this.majorUnit / 2;
    public secondRangeLow: number;// this.firstRangeHigh;
    public secondRangeHigh: number// this.secondRangeLow + this.majorUnit;
    public thirdRangeLow: number;// this.secondRangeHigh;
    public thirdRangeHigh: number;// this.above;

    //public pointers: any[] = [{
    //    value: this.average,
    //    color: '#333333',
    //    length: 1
    //    // Default length
    //    // length: 1
    //}
    //];

    //public AdjustedMMR = this.pointers[0].value;
    busyManheim: Subscription;
    busyNADA: Subscription;
    busyBlackBook: Subscription;
    busyKBB: Subscription;
    busyAll: Subscription;
    busyBooks: Subscription;
    showManagerNotes: boolean;
    toggleManagerNotesText: string;
    managerNotes: string;
    showPricingStep: boolean;
    constructor(public kbbServiceService: KBBServiceService, public httpService: HttpServiceService) {
        this.vinVehicleDetails = new Vehicle();
        this.vehicleParams = new VehicleParams();
        this.params = new VehicleBookParams();
        this.bookValueSaveParams = new BookValueSaveParams();
        this.vinVehicleDetailBooks = new VinVehicleDetailBooks();
        this.errorHandler = new ErrorHandler();
        this.optionValues = new OptionValues();
        this.optionValuesKBB = new Array<OptionValues>();
        this.optionValuesUVC = new OptionValuesUVC();
        this.bookValue = new BookValue();
        this.valuationData = new ValuationData();
        this.MainhaimvaluationData = new ValuationData();
        this.BlackbookvaluationData = new ValuationData();
        this.NADAvaluationData = new ValuationData();
        this.KBBvaluationData = new ValuationData();
        this.iDValues = new IDValues();
        this.bookValueRequestPost = new BookValueRequestPost();
        this.booksJson = JSON.parse('[{"BlackBook":{"vin":null,"year":0,"newVehicle":false,"Uvc":"2008900015","Cylinders":0,"NoOfDoors":0,"ClarificationNeeded":false,"IsDecodeSuccess":true,"engineDetails":null,"years":[{"ID":"2008","Value":"2008","Selected":false,"Code":null},{"ID":"2005","Value":"2005","Selected":false,"Code":null}],"make":[{"ID":"Toyota         ","Value":"Toyota         ","Selected":false,"Code":null}],"Engine":null,"model":[{"ID":"4Runner","Value":"4Runner","Selected":false,"Code":null}],"bodyStyle":[{"ID":"4D SUV 4X4 V6","Value":"4D SUV 4X4 V6","Selected":false,"Code":null}],"series":[{"ID":"Limited","Value":"Limited","Selected":false,"Code":null}],"Transmission":null,"DriveTrain":null,"ClassOfVehicle":null,"DecodeStatus":null,"DMVClass":null,"ExteriorColor":null,"InteriorColor":null,"InteriorType":null,"Fuel":null,"VehicleType":null,"DMVType":null,"Options":[{"Cost":400,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2","Value":"Power Moonroof  400","Selected":false,"Code":null},{"Cost":150,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"49","Value":"Navigation System  150","Selected":false,"Code":null},{"Cost":350,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"149","Value":"Rear Seat Ent Sys  350","Selected":false,"Code":null},{"Cost":-200,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"11","Value":"w/o 3rd Seat -200","Selected":false,"Code":null}],"ModelCode":null,"DealerOption":null,"SourceType":null,"FactoryOptions":null,"OEMExteriorColor":null,"OEMInteriorColor":null,"VehicleMSRP":0,"IsFactoryOptionRequired":false,"StandardEquipment":null,"KBBColor":null,"KBBTrimId":0},"NADA":{"vin":null,"year":0,"newVehicle":false,"Uvc":"1138873","Cylinders":0,"NoOfDoors":0,"ClarificationNeeded":false,"IsDecodeSuccess":true,"engineDetails":null,"years":[{"ID":"2008","Value":"2008","Selected":false,"Code":null}],"make":[{"ID":"48","Value":"TOYOTA","Selected":false,"Code":null}],"Engine":null,"model":[],"bodyStyle":[{"ID":"1138873","Value":"Utility 4D Limited 4WD","Selected":false,"Code":null}],"series":[{"ID":"29","Value":"4Runner-V6","Selected":false,"Code":null}],"Transmission":null,"DriveTrain":null,"ClassOfVehicle":null,"DecodeStatus":null,"DMVClass":null,"ExteriorColor":null,"InteriorColor":null,"InteriorType":null,"Fuel":null,"VehicleType":null,"DMVType":null,"Options":[{"Cost":200,"TradeInCost":200,"RetailCost":225,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"150","Value":"3rd Row Seat","Selected":false,"Code":null},{"Cost":175,"TradeInCost":175,"RetailCost":200,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"067","Value":"JBL Stereo System","Selected":false,"Code":null},{"Cost":225,"TradeInCost":225,"RetailCost":250,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"346","Value":"Navigation System","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"025","Value":"Power Seat","Selected":true,"Code":null},{"Cost":300,"TradeInCost":300,"RetailCost":350,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"092","Value":"Power Sunroof","Selected":false,"Code":null},{"Cost":275,"TradeInCost":275,"RetailCost":325,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"244","Value":"Rear Entertainment System","Selected":false,"Code":null},{"Cost":1300,"TradeInCost":1300,"RetailCost":1450,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"130","Value":"Snow Plow Pkg./Plow","Selected":false,"Code":null},{"Cost":175,"TradeInCost":175,"RetailCost":200,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"145","Value":"Towing/Camper Pkg","Selected":false,"Code":null},{"Cost":125,"TradeInCost":125,"RetailCost":150,"Std":null,"Oa":null,"TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"039","Value":"Winch","Selected":false,"Code":null}],"ModelCode":null,"DealerOption":null,"SourceType":null,"FactoryOptions":null,"OEMExteriorColor":null,"OEMInteriorColor":null,"VehicleMSRP":0,"IsFactoryOptionRequired":false,"StandardEquipment":null,"KBBColor":null,"KBBTrimId":0},"KBB":{"vin":null,"year":0,"newVehicle":false,"Uvc":"","Cylinders":0,"NoOfDoors":0,"ClarificationNeeded":false,"IsDecodeSuccess":true,"engineDetails":null,"years":[{"ID":"2008","Value":"2008","Selected":false,"Code":null}],"make":[{"ID":"49","Value":"Toyota","Selected":false,"Code":null}],"Engine":[{"ID":"2146744","Value":"V6, 4.0 Liter","Selected":true,"Code":null},{"ID":"2146745","Value":"V8, 4.7 Liter","Selected":false,"Code":null}],"model":[{"ID":"294","Value":"4Runner","Selected":false,"Code":null}],"bodyStyle":null,"series":[{"ID":"197760","Value":"Limited Sport Utility 4D","Selected":false,"Code":null}],"Transmission":[{"ID":"2146746","Value":"Automatic, 5-Spd w/Overdrive","Selected":true,"Code":null}],"DriveTrain":[{"ID":"2146747","Value":"2WD","Selected":false,"Code":null},{"ID":"2146748","Value":"4WD","Selected":true,"Code":null}],"ClassOfVehicle":null,"DecodeStatus":null,"DMVClass":null,"ExteriorColor":null,"InteriorColor":null,"InteriorType":null,"Fuel":null,"VehicleType":null,"DMVType":null,"Options":[{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146751","Value":"Hill Descent Control","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146750","Value":"Hill Start Assist","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146776","Value":"Traction Control","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146749","Value":"Stability Control","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146775","Value":"ABS (4-Wheel)","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"7377226","Value":"Anti-Theft System","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"4495831","Value":"Keyless Entry","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146752","Value":"Air Conditioning","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146755","Value":"Power Windows","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146756","Value":"Power Door Locks","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146758","Value":"Cruise Control","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146754","Value":"Power Steering","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146757","Value":"Tilt Wheel","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146759","Value":"AM/FM Stereo","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146762","Value":"CD (Multi Disc)","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146763","Value":"MP3 (Single Disc)","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146764","Value":"MP3 (Multi Disc)","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146765","Value":"JBL Premium Sound","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"4495832","Value":"Satellite Feature","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146767","Value":"Navigation System","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146770","Value":"DVD System","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146771","Value":"Video System","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146768","Value":"Bluetooth Wireless","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146769","Value":"Parking Sensors","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2882741","Value":"Backup Camera","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146772","Value":"Dual Air Bags","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146773","Value":"Side Air Bags","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"4495833","Value":"F&R Head Curtain Air Bags","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"4495834","Value":"Heated Seats","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146779","Value":"Dual Power Seats","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146777","Value":"Leather","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146780","Value":"Third Row Seat","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146781","Value":"Quad Seating (4 Buckets)","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146783","Value":"Moon Roof","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146786","Value":"Privacy Glass","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"4495835","Value":"Daytime Running Lights","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"7377227","Value":"Fog Lights","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146787","Value":"Running Boards","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146788","Value":"Custom Bumper","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146789","Value":"Grille Guard","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146790","Value":"Winch","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146792","Value":"Snow Plow","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146793","Value":"Custom Paint","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146794","Value":"Two-Tone Paint","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146785","Value":"Roof Rack","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146791","Value":"Towing Pkg","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"S","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146795","Value":"Alloy Wheels","Selected":true,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146796","Value":"Premium Wheels","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146798","Value":"Wide Tires","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146799","Value":"Oversize Off-Road Tires","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"2146797","Value":"Oversized Premium Wheels 20","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"6473151","Value":"Beige","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"6473146","Value":"Black","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"6473149","Value":"Blue","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"6473153","Value":"Gray","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"6473145","Value":"Red","Selected":false,"Code":null},{"Cost":0,"TradeInCost":0,"RetailCost":0,"Std":null,"Oa":"A","TradeInXClean":0,"TradeInAbove":0,"TradeInAverage":0,"TradeInBelow":0,"RetailAbove":0,"RetailAverage":0,"RetailBelow":0,"LoanAbove":0,"LoanAverage":0,"LoanBelow":0,"WSaleAbove":0,"WSaleAverage":0,"WSaleBelow":0,"ID":"6473155","Value":"White","Selected":false,"Code":null}],"ModelCode":null,"DealerOption":null,"SourceType":null,"FactoryOptions":null,"OEMExteriorColor":null,"OEMInteriorColor":null,"VehicleMSRP":0,"IsFactoryOptionRequired":false,"StandardEquipment":null,"KBBColor":null,"KBBTrimId":0},"Mainhaim":{"vin":null,"year":0,"newVehicle":false,"Uvc":null,"Cylinders":0,"NoOfDoors":0,"ClarificationNeeded":false,"IsDecodeSuccess":true,"engineDetails":null,"years":[{"ID":"2008","Value":"2008","Selected":false,"Code":null}],"make":[{"ID":"050","Value":"TOYOTA","Selected":false,"Code":null}],"Engine":null,"model":[{"ID":"5772","Value":"4RUNNER 4WD V6","Selected":false,"Code":null}],"bodyStyle":[{"ID":"2807","Value":"4D SUV LIMITED","Selected":false,"Code":null}],"series":null,"Transmission":null,"DriveTrain":null,"ClassOfVehicle":null,"DecodeStatus":null,"DMVClass":null,"ExteriorColor":null,"InteriorColor":null,"InteriorType":null,"Fuel":null,"VehicleType":null,"DMVType":null,"Options":null,"ModelCode":null,"DealerOption":null,"SourceType":null,"FactoryOptions":null,"OEMExteriorColor":null,"OEMInteriorColor":null,"VehicleMSRP":0,"IsFactoryOptionRequired":false,"StandardEquipment":null,"KBBColor":null,"KBBTrimId":0}}]');
        this.isBBYear = true;
        this.isBBMake = true;
        this.isBBModel = true;
        this.isBBSeriesTrim = true;
        this.isBBBodyStyle = true;
        this.isBBOptions = false;
        this.isMhmYear = true;
        this.isMhmMake = true;
        this.isMhmModel = true;
        this.isMhmSeriesTrim = true;
        this.isMhmBodyStyle = true;
        this.isMhmOptions = false;
        this.isNadaYear = true;
        this.isNadaMake = true;
        this.isNadaModel = true;
        this.isNadaSeriesTrim = true;
        this.isNadaBodyStyle = true;
        this.isNadaOptions = false;
        this.isGetProceess = false;
        this.isprintbookOut = false;
        this.isBookNotSaved = true;
        this.BlackBook = "BlackBook";
        this.Manheim = "Manheim";
        this.NADA = "NADA";
        this.KBB = "KBB";
        this.BindBlackBook = new BookValue();
        this.BindManheim = new BookValue();
        this.BindNADA = new BookValue();
        this.BindKBB = new BookValue();
        this.factoryOptionsData = [];
        this.isSaveBlackBook = false;
        this.isSaveMainhaim = false;
        this.isSaveNADA = false;
        this.isSaveKBB = false;
        this.BlackBookRequired = false;
        this.ManhaimRequired = false;
        this.NADARequired = false;
        this.KBBRequired = false;
        this.BlackBookMan = true;
        this.ManhaimMan = true;
        this.NADAMan = true;
        this.KBBMan = true;
        this.ErrorBlackBook = false;
        this.ErrorMainhaim = false;
        this.ErrorNADA = false;
        this.KBBDefault = false;
        this.boostap = 3;
        this.showPricingStep = false;
    }
    BookDetails: any = [];
    SeriesTrim: Array<String> = ["Select", "4dr Sdn l4 Auto", "Tech Pkg (4dr Sdn l4 Auto Tech Pkg)"];
    ngOnInit() {
        this.vehicleParams = this.kbbServiceService.getVehicleParameters();
        this.params.InvtryId = this.vehicleParams.InventoryId;
        this.params.StoreId = this.vehicleParams.StoreId;
        this.params.VehicleId = this.vehicleParams.VehicleId;
        this.params.BookID = 30;
        this.isKBBFailure = this.vehicleParams.IsKbbFailure;
        this.vinVehicleDetails.ExtColor = this.kbbServiceService.vinVehicleDetails.ExtColor;
        this.params.Mileage = this.vehicleParams.Mileage;
        this.vinVehicleDetails = this.kbbServiceService.GetVehicleDetailsFromCache(this.params);
        this.decodeVinVehicleDetailsKBB = this.kbbServiceService.DecodeVinFromCache(this.params);
        if (this.vehicleParams.SourceType == 40 || this.vehicleParams.SourceType == 20 || this.vehicleParams.isStep5Exists) {
            this.showPricingStep = true;
        }
        let cachedBookDetails = this.kbbServiceService.GetGetBookDetailsFromCache(this.params, LinkEnum.GetBookDetails);
        if (cachedBookDetails != null && cachedBookDetails.length > 0)
            this.BookDetails = cachedBookDetails;
        else
            this.GetAllRequiredBooks();
        this.GetAllBooks();
        if (this.kbbServiceService.showManagerNotes || (this.vehicleParams.ManagerNote != '' && this.vehicleParams.ManagerNote != null)) {
            this.showManagerNotes = true;
        }
        else {
            this.showManagerNotes = false;
        }
        if (this.showManagerNotes) {
            this.toggleManagerNotesText = 'Hide Manager Notes';
        }
        else {
            this.toggleManagerNotesText = 'Show Manager Notes';
        }
        if (this.kbbServiceService.managerNotesText != null) {
            this.managerNotes = this.kbbServiceService.managerNotesText;
        }
        if (this.managerNotes == '' || this.managerNotes == null || this.managerNotes == undefined) {
            this.managerNotes = this.vehicleParams.ManagerNote;
        }
    }
    GetBlackBookOnLoadTime = function () {
        if (this.BlackBookRequired == true) {
            let blackBookFromCache = this.kbbServiceService.GetBalckBookFromCache();
            if ((blackBookFromCache == null || blackBookFromCache == undefined) && (this.BlackbookvaluationData != null || this.BlackbookvaluationData != undefined)) {

                if (this.vinVehicleDetailBooks.BlackBook.years != null && this.vinVehicleDetailBooks.BlackBook.years.length == 1) {
                    this.BlackbookvaluationData.Year = new IDValues();
                    this.BlackbookvaluationData.Year.ID = this.vinVehicleDetailBooks.BlackBook.years[0].ID;
                    this.BlackbookvaluationData.Year.Value = this.vinVehicleDetailBooks.BlackBook.years[0].Value;
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);
                }
                else if (this.vinVehicleDetailBooks.BlackBook.years == null || this.vinVehicleDetailBooks.BlackBook.years.length == 0) {
                    this.vinVehicleDetailBooks.BlackBook.years = null;
                    this.vinVehicleDetailBooks.BlackBook.make = null;
                    this.vinVehicleDetailBooks.BlackBook.model = null;
                    this.vinVehicleDetailBooks.BlackBook.series = null;
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;
                    this.BlackBookMan = true;
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);

                    return false;
                }
                else if (this.vinVehicleDetailBooks.BlackBook.years.length > 1 && (this.BlackbookvaluationData.Year == null || this.BlackbookvaluationData.Year == undefined)) {
                    this.BlackbookvaluationData.Year = new IDValues();
                    this.BlackbookvaluationData.Year = "";
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);
                    return false;
                }

                if (this.vinVehicleDetailBooks.BlackBook.make.length == 1) {
                    this.BlackbookvaluationData.make = new IDValues();
                    this.BlackbookvaluationData.make.ID = this.vinVehicleDetailBooks.BlackBook.make[0].ID;
                    this.BlackbookvaluationData.make.Value = this.vinVehicleDetailBooks.BlackBook.make[0].Value;
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);

                }
                else if (this.vinVehicleDetailBooks.BlackBook.make.length == 0) {
                    this.vinVehicleDetailBooks.BlackBook.make = null;
                    this.vinVehicleDetailBooks.BlackBook.model = null;
                    this.vinVehicleDetailBooks.BlackBook.series = null;
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;

                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlYear_SelectedIndexChanged("", "BlackBook");

                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                else if (this.BlackbookvaluationData.make == null || this.BlackbookvaluationData.make == undefined) {
                    this.vinVehicleDetailBooks.BlackBook.model = null;
                    this.vinVehicleDetailBooks.BlackBook.series = null;
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;

                    this.persistBlackBookValueationData(this.BlackbookvaluationData);
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                if (this.vinVehicleDetailBooks.BlackBook.model.length == 1) {
                    this.BlackbookvaluationData.model = new IDValues();
                    this.BlackbookvaluationData.model.ID = this.vinVehicleDetailBooks.BlackBook.model[0].ID;
                    this.BlackbookvaluationData.model.value = this.vinVehicleDetailBooks.BlackBook.model[0].Value;
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);

                }
                else if (this.vinVehicleDetailBooks.BlackBook.model.length == 0) {
                    this.vinVehicleDetailBooks.BlackBook.model = null;
                    this.vinVehicleDetailBooks.BlackBook.series = null;
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlMake_SelectedIndexChanged("", "BlackBook");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else if (this.BlackbookvaluationData.model == null || this.BlackbookvaluationData.model == undefined) {
                    this.vinVehicleDetailBooks.BlackBook.series = null;
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;

                    this.persistBlackBookValueationData(this.BlackbookvaluationData);
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;

                }

                if (this.vinVehicleDetailBooks.BlackBook.series.length == 1) {
                    this.BlackbookvaluationData.series = new IDValues();
                    this.BlackbookvaluationData.series.ID = this.vinVehicleDetailBooks.BlackBook.series[0].ID;
                    this.BlackbookvaluationData.series.value = this.vinVehicleDetailBooks.BlackBook.series[0].Value;
                    this.BlackbookvaluationData.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);
                    this.refresh(this.vinVehicleDetailBooks);

                }
                else if (this.vinVehicleDetailBooks.BlackBook.series.length == 0) {
                    this.vinVehicleDetailBooks.BlackBook.series = null;
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlModel_SelectedIndexChanged("", "BlackBook");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                else if (this.BlackbookvaluationData.series == null || this.BlackbookvaluationData.series == undefined) {
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                if (this.vinVehicleDetailBooks.BlackBook.bodyStyle.length == 1 && (this.vinVehicleDetailBooks.BlackBook.Options == null || this.vinVehicleDetailBooks.BlackBook.Options.length < 1)) {
                    this.BlackbookvaluationData.bodyStyle = new IDValues();
                    this.BlackbookvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.BlackBook.bodyStyle[0].ID;
                    this.BlackbookvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.BlackBook.bodyStyle[0].Value;
                    this.BlackbookvaluationData.Uvc = this.vinVehicleDetailBooks.BlackBook.Uvc;
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);
                    this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
                    this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
                    this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
                    this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                    this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                    this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;
                    this.bookValueRequestPost.ProviderID = "4";
                    this.bookValueRequestPost.valuationData.Uvc = null;
                    this.kbbServiceService.GetOptionsADP(this.bookValueRequestPost).subscribe(
                        (result: OptionValues) => {
                            this.processBindOptions(this.optionValues = result, "BlackBook")
                        },
                        (error: Response | IDValues) => this.errorHandler.handleError(error));
                }
                else if (this.vinVehicleDetailBooks.BlackBook.bodyStyle.length == 1) {
                    this.BlackbookvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.BlackBook.bodyStyle[0].ID;
                    this.BlackbookvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.BlackBook.bodyStyle[0].Value;
                    this.BlackbookvaluationData.Uvc = this.vinVehicleDetailBooks.BlackBook.Uvc;
                    this.persistBlackBookValueationData(this.BlackbookvaluationData);
                }
                else if (this.vinVehicleDetailBooks.BlackBook.bodyStyle.length == 0) {
                    this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
                    this.vinVehicleDetailBooks.BlackBook.Options = null;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlSeries_SelectedIndexChanged("", "BlackBook");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else if (this.BlackbookvaluationData.bodyStyle == null || this.BlackbookvaluationData.bodyStyle == undefined) {
                    this.vinVehicleDetailBooks.BlackBook.Options = null;
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
            }
            else {
                this.BindBlackBook = blackBookFromCache;
                this.BlackBookRequired = true;
            }
        }

    }

    GetMainhaimBookOnLoadTime = function () {
        if (this.ManhaimRequired == true) {
            let manhaimFromCache = this.kbbServiceService.GetManhaimFromCache();
            this.MainhaimvaluationData.ExtColor = this.kbbServiceService.vinVehicleDetails.ExtColor;
            if ((manhaimFromCache == null || manhaimFromCache == undefined) && (this.MainhaimvaluationData != null || this.MainhaimvaluationData != undefined)) {
                if (this.vinVehicleDetailBooks.Mainhaim.years.length == 1) {
                    this.MainhaimvaluationData.Year = new IDValues();
                    this.MainhaimvaluationData.Year.ID = this.vinVehicleDetailBooks.Mainhaim.years[0].ID;
                    this.MainhaimvaluationData.Year.Value = this.vinVehicleDetailBooks.Mainhaim.years[0].Value;
                    this.persistMainHaimValueationData(this.MainhaimvaluationData);

                }
                else if (this.vinVehicleDetailBooks.Mainhaim.years.length == 0) {
                    this.vinVehicleDetailBooks.Mainhaim.years = null;
                    this.vinVehicleDetailBooks.Mainhaim.make = null;
                    this.vinVehicleDetailBooks.Mainhaim.model = null;
                    this.vinVehicleDetailBooks.Mainhaim.series = null;
                    this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
                    this.vinVehicleDetailBooks.Mainhaim.Options = null;
                    this.ManhaimMan = true;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlYear_SelectedIndexChanged("", "Mainhaim");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                else if ((this.vinVehicleDetailBooks.Mainhaim.years.length > 1) && (this.MainhaimvaluationData.Year == null || this.MainhaimvaluationData.Year == undefined)) {
                    this.MainhaimvaluationData.Year = new IDValues();
                    this.MainhaimvaluationData.Year = "";
                    this.persistMainHaimValueationData(this.MainhaimvaluationData);
                    return false;

                }
                if (this.vinVehicleDetailBooks.Mainhaim.make.length == 1) {
                    this.MainhaimvaluationData.make = new IDValues();
                    this.MainhaimvaluationData.make.ID = this.vinVehicleDetailBooks.Mainhaim.make[0].ID;
                    this.MainhaimvaluationData.make.Value = this.vinVehicleDetailBooks.Mainhaim.make[0].Value;
                    this.persistMainHaimValueationData(this.MainhaimvaluationData);

                }
                else if (this.vinVehicleDetailBooks.Mainhaim.make.length == 0) {
                    this.vinVehicleDetailBooks.Mainhaim.make = null;
                    this.vinVehicleDetailBooks.Mainhaim.model = null;
                    this.vinVehicleDetailBooks.Mainhaim.series = null;
                    this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
                    this.vinVehicleDetailBooks.Mainhaim.Options = null;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlMake_SelectedIndexChanged("", "Mainhaim");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                else if (this.MainhaimvaluationData.make == null || this.MainhaimvaluationData.make == undefined) {
                    this.vinVehicleDetailBooks.Mainhaim.Model = null;
                    this.vinVehicleDetailBooks.Mainhaim.series = null;
                    this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
                    this.persistMainHaimValueationData(this.MainhaimvaluationData);
                    this.refresh(this.vinVehicleDetailBooks);

                    return false;

                }

                if (this.vinVehicleDetailBooks.Mainhaim.model.length == 1) {
                    this.MainhaimvaluationData.model = new IDValues();
                    this.MainhaimvaluationData.model.ID = this.vinVehicleDetailBooks.Mainhaim.model[0].ID;
                    this.MainhaimvaluationData.model.value = this.vinVehicleDetailBooks.Mainhaim.model[0].Value;
                    this.persistMainHaimValueationData(this.MainhaimvaluationData);

                }
                else if (this.vinVehicleDetailBooks.Mainhaim.model.length == 0) {
                    this.vinVehicleDetailBooks.Mainhaim.model = null;
                    this.vinVehicleDetailBooks.Mainhaim.series = null;
                    this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
                    this.vinVehicleDetailBooks.Mainhaim.Options = null;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlModel_SelectedIndexChanged("", "Mainhaim");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else if (this.MainhaimvaluationData.model == null || this.MainhaimvaluationData.model == undefined) {
                    this.vinVehicleDetailBooks.Mainhaim.series = null;
                    this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
                    this.persistMainHaimValueationData(this.MainhaimvaluationData);
                    this.refresh(this.vinVehicleDetailBooks);

                    return false;

                }
                if (this.vinVehicleDetailBooks.Mainhaim.bodyStyle.length == 1) {
                    this.MainhaimvaluationData.bodyStyle = new IDValues();
                    this.MainhaimvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.Mainhaim.bodyStyle[0].ID;
                    this.MainhaimvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.Mainhaim.bodyStyle[0].Value;
                    this.persistMainHaimValueationData(this.MainhaimvaluationData);
                }
                else if (this.vinVehicleDetailBooks.Mainhaim.bodyStyle.length == 0) {
                    this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
                    this.vinVehicleDetailBooks.Mainhaim.Options = null;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlBodyStyle_SelectedIndexChanged("", "Mainhaim");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else {

                    return false;

                }
                this.MainhaimvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.Mainhaim.bodyStyle[0].ID;
                this.MainhaimvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.Mainhaim.bodyStyle[0].Value;
                this.MainhaimvaluationData.Uvc = this.vinVehicleDetailBooks.Mainhaim.Uvc;
                this.persistMainHaimValueationData(this.MainhaimvaluationData);

                this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;

                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
                this.bookValueRequestPost.MainhaimdRegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
                this.bookValueRequestPost.ExtColor = this.kbbServiceService.vinVehicleDetails.ExtColor;
                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
                this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                this.bookValueRequestPost.valuationData.RequestXML = "";
                this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.valuationData.Options = null;
                this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;
                this.busyManheim = this.kbbServiceService.GetManheimBookValues(this.bookValueRequestPost).subscribe(
                    (result: BookValue) => {
                        this.processManheimBookOptionADP(this.bookValue = result)
                    },
                    (error: Response | any) => {
                        this.ManhaimMan == true;
                        if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true) && (this.KBBDefault == true)) {
                            this.kbbServiceService.isFinishEnable.next(true);
                        }

                        this.ErrorMainhaim = true;
                       // this.ErrorMessageMainhaim = error.json().message;
                        this.ErrorMessageMainhaim = "";
                        this.PerstistMessageErrorMainhaim(this.ErrorMessageMainhaim);
                        this.PerstistErrorMainhaim(this.ErrorMainhaim);
                        this.errorHandler.handleError(error)
                    });
            }
            else {
                this.BindManheim = manhaimFromCache;
                if (this.BindManheim != null && this.BindManheim != undefined) {
                    this.LoadMMRValues(manhaimFromCache);
                }
                this.ManhaimRequired = true;
            }
            if (this.MainhaimvaluationData.ExtColor != this.kbbServiceService.vinVehicleDetails.ExtColor
                || this.vehicleParams.Mileage != this.vinVehicleDetails.Mileage) {
                this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;
                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
                this.bookValueRequestPost.MainhaimdRegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
                this.bookValueRequestPost.ExtColor = this.kbbServiceService.vinVehicleDetails.ExtColor;
                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
                this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                this.bookValueRequestPost.valuationData.RequestXML = "";
                this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.valuationData.Options = null;
                this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;
                this.busyManheim = this.kbbServiceService.GetManheimBookValues(this.bookValueRequestPost).subscribe(
                    (result: BookValue) => {
                        this.processManheimBookOptionADP(this.bookValue = result)
                    },
                    (error: Response | any) => {
                        this.ManhaimMan == true;
                        if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true) && (this.KBBDefault == true)) {
                            this.kbbServiceService.isFinishEnable.next(true);
                        }

                        this.ErrorMainhaim = true;
                        //this.ErrorMessageMainhaim = error.json().message;;
                        this.ErrorMessageMainhaim = "";
                        this.PerstistMessageErrorMainhaim(this.ErrorMessageMainhaim);
                        this.PerstistErrorMainhaim(this.ErrorMainhaim);
                        this.errorHandler.handleError(error)
                    });
            }
        }
    }
    GetNADABookOnLoadTime = function () {
        if (this.NADARequired == true) {

            let NADAFromCache = this.kbbServiceService.GetNADAFromCache();
            if ((NADAFromCache == null || NADAFromCache == undefined) && (this.NADAvaluationData != null || this.NADAvaluationData != undefined)) {

                if ((this.vinVehicleDetailBooks.NADA.years != null && this.vinVehicleDetailBooks.NADA.years.length == 1)) {
                    this.bookValueRequestPost.valuationData = new ValuationData();
                    this.NADAvaluationData.Year = new IDValues();
                    this.NADAvaluationData.Year.ID = this.vinVehicleDetailBooks.NADA.years[0].ID;
                    this.NADAvaluationData.Year.Value = this.vinVehicleDetailBooks.NADA.years[0].Value;
                    this.persistNADAValueationData(this.NADAvaluationData);


                }

                else if (this.vinVehicleDetailBooks.NADA.years == null || this.vinVehicleDetailBooks.NADA.years.length == 0) {
                    this.vinVehicleDetailBooks.NADA.years = null;
                    this.vinVehicleDetailBooks.NADA.make = null;
                    this.vinVehicleDetailBooks.NADA.series = null;
                    this.vinVehicleDetailBooks.NADA.bodyStyle = null;
                    this.vinVehicleDetailBooks.NADA.Model = null;
                    this.vinVehicleDetailBooks.NADA.Options = null;
                    this.NADAMan = true;
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                else if ((this.vinVehicleDetailBooks.NADA.years.length > 1) && (this.NADAvaluationData.Year == null || this.NADAvaluationData.Year == undefined)) {
                    this.NADAvaluationData.Year = new IDValues();
                    this.NADAvaluationData.Year = "";
                    this.persistNADAValueationData(this.NADAvaluationData);
                    return false;

                }

                if (this.vinVehicleDetailBooks.NADA.make.length == 1) {
                    this.NADAvaluationData.make = new IDValues();
                    this.NADAvaluationData.make.ID = this.vinVehicleDetailBooks.NADA.make[0].ID;
                    this.NADAvaluationData.make.Value = this.vinVehicleDetailBooks.NADA.make[0].Value;
                    this.persistNADAValueationData(this.NADAvaluationData);
                }
                else if (this.vinVehicleDetailBooks.NADA.make.length == 0) {
                    this.vinVehicleDetailBooks.NADA.make = null;
                    this.vinVehicleDetailBooks.NADA.model = null;
                    this.vinVehicleDetailBooks.NADA.series = null;
                    this.vinVehicleDetailBooks.NADA.bodyStyle = null;
                    this.vinVehicleDetailBooks.NADA.Options = null;

                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlYear_SelectedIndexChanged("", "NADA");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else if (this.NADAvaluationData.make == null || this.NADAvaluationData.make == undefined) {
                    this.vinVehicleDetailBooks.NADA.Model = null;
                    this.vinVehicleDetailBooks.NADA.series = null;
                    this.vinVehicleDetailBooks.NADA.bodyStyle = null;
                    this.vinVehicleDetailBooks.NADA.Options = null;
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }


                if (this.vinVehicleDetailBooks.NADA.series.length == 1) {
                    this.NADAvaluationData.series = new IDValues();
                    this.NADAvaluationData.series.ID = this.vinVehicleDetailBooks.NADA.series[0].ID;
                    this.NADAvaluationData.series.Value = this.vinVehicleDetailBooks.NADA.series[0].Value;
                    this.persistNADAValueationData(this.NADAvaluationData);
                }
                else if (this.vinVehicleDetailBooks.NADA.series.length == 0) {
                    this.vinVehicleDetailBooks.NADA.series = null;
                    this.vinVehicleDetailBooks.NADA.bodyStyle = null;
                    this.vinVehicleDetailBooks.NADA.Options = null;

                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlMake_SelectedIndexChanged("", "NADA");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else if (this.NADAvaluationData.series == null || this.NADAvaluationData.series == undefined) {
                    this.vinVehicleDetailBooks.NADA.bodyStyle = null;
                    this.vinVehicleDetailBooks.NADA.Options = null;
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                if ((this.vinVehicleDetailBooks.NADA.bodyStyle.length == 1) && (this.vinVehicleDetailBooks.NADA.Options == null || this.vinVehicleDetailBooks.NADA.Options.length < 1)) {
                    this.NADAvaluationData.bodyStyle = new IDValues();
                    this.NADAvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.NADA.bodyStyle[0].ID;
                    this.NADAvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.NADA.bodyStyle[0].Value;
                    this.NADAvaluationData.Uvc = this.vinVehicleDetailBooks.NADA.Uvc;
                    this.persistNADAValueationData(this.NADAvaluationData);

                    this.bookValueRequestPost.valuationData = this.NADAvaluationData;
                    this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
                    this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
                    this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                    this.bookValueRequestPost.valuationData.RequestXML = "";
                    this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                    this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;

                    this.bookValueRequestPost.ProviderID = "6";
                    this.bookValueRequestPost.valuationData.Uvc = null;

                    this.kbbServiceService.GetOptionsADP(this.bookValueRequestPost).subscribe(
                        (result: OptionValues) => {
                            this.processBindOptions(this.optionValues = result, "NADA")

                        },
                        (error: Response | IDValues) => this.errorHandler.handleError(error));
                }
                else if (this.vinVehicleDetailBooks.NADA.bodyStyle.length == 1) {
                    this.NADAvaluationData.bodyStyle = new IDValues();
                    this.NADAvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.NADA.bodyStyle[0].ID;
                    this.NADAvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.NADA.bodyStyle[0].Value;
                    this.NADAvaluationData.Uvc = this.vinVehicleDetailBooks.NADA.Uvc;
                    this.persistNADAValueationData(this.NADAvaluationData);
                }
                else if (this.vinVehicleDetailBooks.NADA.bodyStyle.length == 0) {
                    this.vinVehicleDetailBooks.NADA.series = null;
                    this.vinVehicleDetailBooks.NADA.bodyStyle = null;
                    this.vinVehicleDetailBooks.NADA.Options = null;

                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlSeries_SelectedIndexChanged("", "NADA");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else if (this.NADAvaluationData.series == null || this.NADAvaluationData.series == undefined) {
                    this.vinVehicleDetailBooks.NADA.Options = null;

                    return false;
                }
            }
            else {
                this.BindNADA = NADAFromCache;
                this.NADARequired = true;

            }
        }


    }
    GetKBBBookOnLoadTime = function () {
        if (this.KBBRequired == true) {
            let KBBFromCache = this.kbbServiceService.GetKBBFromCache();
            if ((KBBFromCache == null || KBBFromCache == undefined) && (this.KBBvaluationData != null || this.KBBvaluationData != undefined)) {

                this.bookValueRequestPost.valuationData = new ValuationData();
                this.KBBvaluationData.Year = new IDValues();
                this.KBBvaluationData.Year.Value = this.vinVehicleDetails.Year.toString();
                this.KBBvaluationData.Year.ID = this.vinVehicleDetails.Year.toString();


                this.KBBvaluationData.make = new IDValues();
                this.KBBvaluationData.make.Value = this.vinVehicleDetails.Make.toString();
                this.KBBvaluationData.make.ID = this.vinVehicleDetails.KBBMakeId.toString();

                this.KBBvaluationData.model = new IDValues();
                this.KBBvaluationData.model.Value = this.vinVehicleDetails.Model.toString();
                this.KBBvaluationData.model.ID = this.vinVehicleDetails.KBBModelId.toString();


                this.KBBvaluationData.series = new IDValues();
                this.KBBvaluationData.series.Value = this.vinVehicleDetails.Trim.toString();
                this.KBBvaluationData.series.ID = this.vinVehicleDetails.KBBTrimId.toString();

                this.KBBvaluationData.Engine = new IDValues();
                this.KBBvaluationData.Engine.Value = this.vinVehicleDetails.Engine.toString();
                this.KBBvaluationData.Engine.ID = this.vinVehicleDetails.KBBEngineId.toString();

                this.KBBvaluationData.Transmission = new IDValues();
                this.KBBvaluationData.Transmission.Value = this.vinVehicleDetails.Transmission.toString();
                this.KBBvaluationData.Transmission.ID = this.vinVehicleDetails.KBBTransmissionId.toString();


                this.KBBvaluationData.DriveTrain = new IDValues();
                this.KBBvaluationData.DriveTrain.Value = this.vinVehicleDetails.DriveTrain.toString();
                this.KBBvaluationData.DriveTrain.ID = this.vinVehicleDetails.KBBDrivetrainId.toString();
                this.persistKBBValueationData(this.KBBvaluationData);
                this.bookValueRequestPost.valuationData.Options = new OptionValues();
                this.bookValueRequestPost.valuationData.RequestXML = "";
                this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;

                this.bookValueRequestPost.ProviderID = "5";

                this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                this.bookValueRequestPost.valuationData = this.KBBvaluationData;
                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
                this.kbbServiceService.GetOptionsKBB(this.bookValueRequestPost).subscribe(
                    (result: OptionValues) => {
                        this.processBindOptions(this.optionValues = result, "KBB")

                    },
                    (error: Response | IDValues) => this.errorHandler.handleError(error));
            }
            else {
                this.BindKBB = KBBFromCache;
                this.KBBRequired = true;
            }

        }
    }

    GetKBBV2FailureOnLoadTime = function () {

        this.KBBMan = true;
        this.KBBDefault = true;
        if (this.isKBBFailure) {
            if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true)) {
                this.kbbServiceService.isFinishEnable.next(true);
            }

        }
        else {
            if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true) && (this.KBBDefault == true)) {
                this.kbbServiceService.isFinishEnable.next(true);
            }
        }

        let KBBFromCache = this.kbbServiceService.GetKBBFromCache();
        if ((KBBFromCache == null || KBBFromCache == undefined) && (this.KBBvaluationData != null || this.KBBvaluationData != undefined) && (this.KBBvaluationData.Year == null)) {
            this.KBBvaluationData.Year = null;
            this.KBBvaluationData.make = null;
            this.KBBvaluationData.model = null;
            this.KBBvaluationData.series = null;
            this.KBBvaluationData.Engine = null;
            this.KBBvaluationData.Transmission = null;
            this.KBBvaluationData.DriveTrain = null;
            this.vinVehicleDetailBooks.KBB.Options = null;
            this.kbbServiceService.GetKBBYears("KBB").subscribe(
                (result: IDValues) => {
                    this.processBindYear(this.iDValues = result, "KBB")

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        else {
            this.BindKBB = KBBFromCache;
            this.KBBRequired = true;
        }

    }
    GetKBBBookOnLoadTimeOnV2Failure = function () {
        if (this.KBBRequired == true) {

            let KBBFromCache = this.kbbServiceService.GetKBBFromCache();
            if ((KBBFromCache == null || KBBFromCache == undefined) && (this.KBBvaluationData != null || this.KBBvaluationData != undefined)) {

                if ((this.vinVehicleDetailBooks.KBB.years != null && this.vinVehicleDetailBooks.KBB.years.length == 1)) {
                    this.bookValueRequestPost.valuationData = new ValuationData();
                    this.KBBvaluationData.Year = new IDValues();
                    this.KBBvaluationData.Year.ID = this.vinVehicleDetailBooks.KBB.years[0].ID;
                    this.KBBvaluationData.Year.Value = this.vinVehicleDetailBooks.KBB.years[0].Value;
                    this.persistKBBValueationData(this.KBBvaluationData);


                }

                else if (this.vinVehicleDetailBooks.KBB.years == null || this.vinVehicleDetailBooks.KBB.years.length == 0) {
                    this.vinVehicleDetailBooks.KBB.years = null;
                    this.vinVehicleDetailBooks.KBB.make = null;
                    this.vinVehicleDetailBooks.KBB.series = null;
                    this.vinVehicleDetailBooks.KBB.bodyStyle = null;
                    this.vinVehicleDetailBooks.KBB.model = null;
                    this.vinVehicleDetailBooks.KBB.Options = null;
                    this.KBBMan = true;
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                else if ((this.vinVehicleDetailBooks.KBB.years.length > 1) && (this.KBBvaluationData.Year == null || this.KBBvaluationData.Year == undefined)) {
                    this.KBBvaluationData.Year = new IDValues();
                    this.KBBvaluationData.Year = "";
                    this.persistKBBValueationData(this.KBBvaluationData);
                    return false;

                }

                if (this.vinVehicleDetailBooks.KBB.make.length == 1) {
                    this.KBBvaluationData.make = new IDValues();
                    this.KBBvaluationData.make.ID = this.vinVehicleDetailBooks.KBB.make[0].ID;
                    this.KBBvaluationData.make.Value = this.vinVehicleDetailBooks.KBB.make[0].Value;
                    this.persistKBBValueationData(this.KBBvaluationData);
                }
                else if (this.vinVehicleDetailBooks.KBB.make.length == 0) {
                    this.vinVehicleDetailBooks.KBB.make = null;
                    this.vinVehicleDetailBooks.KBB.model = null;
                    this.vinVehicleDetailBooks.KBB.series = null;
                    this.vinVehicleDetailBooks.KBB.bodyStyle = null;
                    this.vinVehicleDetailBooks.KBB.Options = null;

                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlYear_SelectedIndexChanged("", "KBB");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }




                if (this.vinVehicleDetailBooks.KBB.model.length == 1) {
                    this.KBBvaluationData.model = new IDValues();
                    this.KBBvaluationData.model.ID = this.vinVehicleDetailBooks.KBB.model[0].ID;
                    this.KBBvaluationData.model.value = this.vinVehicleDetailBooks.KBB.model[0].Value;
                    this.persistKBBValueationData(this.KBBvaluationData);

                }
                else if (this.vinVehicleDetailBooks.BlackBook.model.length == 0) {
                    this.vinVehicleDetailBooks.KBB.series = null;
                    this.vinVehicleDetailBooks.KBB.bodyStyle = null;
                    this.vinVehicleDetailBooks.KBB.Options = null;
                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlMake_SelectedIndexChanged("", "KBB");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
                if (this.vinVehicleDetailBooks.KBB.series.length == 1) {
                    this.KBBvaluationData.series = new IDValues();
                    this.KBBvaluationData.series.ID = this.vinVehicleDetailBooks.KBB.series[0].ID;
                    this.KBBvaluationData.series.Value = this.vinVehicleDetailBooks.KBB.series[0].Value;
                    this.persistKBBValueationData(this.KBBvaluationData);
                    this.KBBvaluationData.Engine = null;
                    this.KBBvaluationData.Transmission = null;
                    this.KBBvaluationData.DriveTrain = null;
                    this.vinVehicleDetailBooks.KBB.Options = null;
                    this.persistKBBValueationData(this.KBBvaluationData);
                    this.bookValueRequestPost.NadaRegionId = "";
                    this.bookValueRequestPost.adpRegionID = "";
                    this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
                    this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
                    this.bookValueRequestPost.ProviderID = "5";
                    this.bookValueRequestPost.valuationData = this.KBBvaluationData;
                    this.KBBvaluationData.Uvc = this.vinVehicleDetailBooks.KBB.Uvc;

                    this.kbbServiceService.GetKBB_Eng_Tran_DrvTra(this.bookValueRequestPost).subscribe(
                        //   this.kbbServiceService.GetKBBEngines(this.bookValueRequestPost).subscribe(
                        (result: ValuationData) => {
                            this.processBindEng_Tran_DrvTra(this.ValuationData = result, "KBB")

                        },
                        (error: Response | ValuationData) => this.errorHandler.handleError(error));
                }
                else if (this.vinVehicleDetailBooks.KBB.series.length == 0) {
                    this.vinVehicleDetailBooks.KBB.series = null;
                    this.vinVehicleDetailBooks.KBB.bodyStyle = null;
                    this.vinVehicleDetailBooks.KBB.Options = null;

                    this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                    this.ddlMake_SelectedIndexChanged("", "KBB");
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }

                else if (this.KBBvaluationData.series == null || this.KBBvaluationData.series == undefined) {
                    this.vinVehicleDetailBooks.KBB.bodyStyle = null;
                    this.vinVehicleDetailBooks.KBB.Options = null;
                    this.refresh(this.vinVehicleDetailBooks);
                    return false;
                }
            }
            else {
                this.BindKBB = KBBFromCache;
                this.KBBRequired = true;

            }
        }
    }

    btnClick = function () {
        this.isFinishButtonClicked = true;
        this.kbbServiceService.isFinishBookDisable.next(true);
        this.saveBookDetails();
        //this.saveManagerNotes();
        //this.GetOfferDetails();

    };

    processData(data) {

        this.BookDetailResponse1 = data;


    }



    persistBookDetails(data) {

        this.kbbServiceService.setData(data, LinkEnum.GetBookDetails);
    }
    persistBlackBook(data) {

        this.kbbServiceService.setData(data, LinkEnum.GetBookValueADP);
    }
    persistBlackBookValueationData(data) {

        this.kbbServiceService.setData(data, LinkEnum.SetBlackBook);
    }

    persistMainHaim(data) {

        this.kbbServiceService.setData(data, LinkEnum.GetManheimBookValues);
    }
    persistMainHaimValueationData(data) {

        this.kbbServiceService.setData(data, LinkEnum.SetMainhaim);
    }

    persistNADA(data) {

        this.kbbServiceService.setData(data, LinkEnum.GetBookValueNADA);
    }
    persistNADAValueationData(data) {

        this.kbbServiceService.setData(data, LinkEnum.SetNADA);
    }

    persistKBB(data) {

        this.kbbServiceService.setData(data, LinkEnum.GetBookValueKBB);
    }
    persistKBBValueationData(data) {

        this.kbbServiceService.setData(data, LinkEnum.SetKBB);
    }



    saveBookDetails = function () {
        if (this.isBookNotSaved) {
            this.isBookNotSaved = false;
            this.bookValueSaveParams.VehicleId = this.vehicleParams.VehicleId;
            this.bookValueSaveParams.StoreId = this.vehicleParams.StoreId;
            this.bookValueSaveParams.InvtryId = this.vehicleParams.InventoryId;
            this.bookValueSaveParams.UpdateResponseTableOnly = false;
            this.bookValueSaveParams.UserName = this.vehicleParams.UserName;


            //Mainhaim
            if (this.isSaveMainhaim == true) {
                this.isSaveMainhaim = false;
                this.PerstistIsSaveMainhaim(false);
                this.bookValueSaveParams.BookValues = this.BindManheim;
                this.bookValueSaveParams.BookValues.valuationData = this.MainhaimvaluationData;
                this.bookValueSaveParams.BookValues.ProviderId = '1';
                this.bookValueSaveParams.BookValues.BookValueProvider = '40';
                this.kbbServiceService.SaveDetailsfromAPI(this.bookValueSaveParams, LinkEnum.SaveBookValueDetails).subscribe(
                    (result: BookDetailResponse[]) => {
                    },
                    (error: Response | BookConfiguration) => this.errorHandler.handleError(error));
            }
            //Nada
            if (this.isSaveNADA == true) {
                this.isSaveNADA = false;
                this.PerstistIsSaveNADA(false);
                this.bookValueSaveParams.BookValues = this.BindNADA;
                this.bookValueSaveParams.BookValues.valuationData = this.NADAvaluationData;
                this.bookValueSaveParams.BookValues.valuationData.Options = this.BindNADA.Options;

                this.bookValueSaveParams.BookValues.ProviderId = '6';
                this.bookValueSaveParams.BookValues.BookValueProvider = '10';

                this.kbbServiceService.SaveDetailsfromAPI(this.bookValueSaveParams, LinkEnum.SaveBookValueDetails).subscribe(
                    (result: BookDetailResponse[]) => {
                    },
                    (error: Response | BookConfiguration) => this.errorHandler.handleError(error));
            }

            //KBB
            if (this.isSaveKBB == true) {
                this.isSaveKBB = false;
                this.PerstistIsSaveKBB(false);
                this.bookValueSaveParams.BookValues = this.BindKBB;
                this.bookValueSaveParams.BookValues.valuationData = this.KBBvaluationData;
                this.bookValueSaveParams.BookValues.ProviderId = '5';
                this.bookValueSaveParams.BookValues.BookValueProvider = '20';
                this.bookValueSaveParams.BookValues.valuationData.Options = this.BindKBB.Options;
                this.kbbServiceService.SaveDetailsfromAPI(this.bookValueSaveParams, LinkEnum.SaveBookValueDetails).subscribe(
                    (result: BookDetailResponse[]) => {
                    },
                    (error: Response | BookConfiguration) => this.errorHandler.handleError(error));
            }
            if (this.isSaveBlackBook == true) {
                this.isSaveBlackBook = false;
                this.PerstistIsSaveBlackBook(false);
                this.bookValueSaveParams.BookValues = this.BindBlackBook;
                this.bookValueSaveParams.BookValues.ProviderId = '4';
                this.bookValueSaveParams.BookValues.BookValueProvider = '30';

                this.bookValueSaveParams.BookValues.valuationData = this.BlackbookvaluationData;
                this.bookValueSaveParams.BookValues.valuationData.Options = this.BindBlackBook.Options;
                this.bookValueSaveParams.LaneId = 0;
                //blackBook
                this.kbbServiceService.SaveDetailsfromAPI(this.bookValueSaveParams, LinkEnum.SaveBookValueDetails).subscribe(
                    (result: BookDetailResponse[]) => {
                        this.SavePushPrice();
						if (!this.showPricingStep && !this.isprintbookOut) {
							this.GetOfferDetails();
							this.saveManagerNotes();
							
						}
					},
					(error: Response | BookConfiguration) => this.errorHandler.handleError(error));
            }
            else {
                this.SavePushPrice();
            }
        }
        else {
            this.GetOfferDetails();
            this.SavePushPrice();
            this.saveManagerNotes();
            this.isprintbookOut = false;
        }

    }

    SavePushPrice() {
        this.kbbServiceService.Pushprice(this.vehicleParams).subscribe(
            (result: SIMSResponseData) => {
            },
            (error: Response | any) => this.errorHandler.handleError(error));
    }

    GetOfferDetails() {
        if (this.isKBBFailure != true || this.isKBBFailure == null) {
            this.kbbServiceService.GetOfferDetails(this.vehicleParams).subscribe(
                (result: SIMSResponseData) => {
                },
                (error: Response | any) => this.errorHandler.handleError(error));
        }
    }
    Redirect(data: any): void {
        if (data != null) {
            if (this.vehicleParams.SourceType == 40) {
                window.top.location.href = '../../Inventory/Pages/Inventory_Log.aspx';
            }
            else if (this.vehicleParams.SourceType == 60 || this.vehicleParams.SourceType == 50) {
                window.top.location.href = '../../Appraisals/Pages/ServiceAppraisalLog.aspx';
            }
            else if (this.vehicleParams.SourceType == 100 || this.vehicleParams.SourceType == 30) {
                window.top.location.href = '../../Appraisals/Pages/AppraisalLog.aspx';
            }
            else if (this.vehicleParams.SourceType == 110) {
                window.top.location.href = '../../Appraisals/Pages/InternetAppraisalLog.aspx';
            }
            else {
                window.top.location.href = '../../Appraisals/Pages/AppraisalLog.aspx';
            }
        }
    }



    GetAllRequiredBooks = function () {
        let bookConfigurationFromcache = this.kbbServiceService.GetAllRequiredBooksFromCache();

        if (bookConfigurationFromcache == undefined || bookConfigurationFromcache == null) {

            this.busyAll = this.kbbServiceService.GetAllRequiredBooksfromAPI(this.vehicleParams).subscribe(
                (result: BookConfiguration) => {
                    this.bookConfiguration = result;

                    for (let propName of this.bookConfiguration.SetupBookIds)
                        if (propName == "30") {
                            this.BlackBookRequired = true;
                            this.PerstistIsRequiredBlackBook(this.BlackBookRequired);
                        }
                        else if (propName == "40") {
                            this.ManhaimRequired = true;
                            this.PerstistIsRequiredMainhaim(this.ManhaimRequired);
                        }
                        else if (propName == "10") {
                            this.NADARequired = true;
                            this.PerstistIsRequiredNADA(this.NADARequired);
                        }
                        else if (propName == "20") {
                            this.KBBRequired = true;
                            this.PerstistIsRequiredKBB(this.KBBRequired);

                        }
                    for (let propName of this.bookConfiguration.BookIDs)
                        if (propName == "30") {
                            this.BlackBookMan = false;
                        }
                        else if (propName == "40") {
                            this.ManhaimMan = false;
                        }
                        else if (propName == "10") {
                            this.NADAMan = false;
                        }
                        else if (propName == "20") {
                            this.KBBMan = false;
                        }
                    let lengthboostrap = this.bookConfiguration.SetupBookIds.length;
                    if (lengthboostrap == 3) {
                        this.boostap = 4;
                    }
                    else if (lengthboostrap == 4) {
                        this.boostap = 3;
                    }
                    else if (lengthboostrap == 2) {
                        this.boostap = 6;
                    }
                    else if (lengthboostrap == 1) {
                        this.boostap = 12;
                    }

                    this.PerstistBootStrap(this.boostap);
                    this.persistBookConfigurationData();
                },
                (error: Response | BookConfiguration) => this.errorHandler.handleError(error));
        }
        else {
            this.bookConfiguration = bookConfigurationFromcache;
        }
    }
    persistGetAllBooksData(data): void {
        this.kbbServiceService.setData(data, LinkEnum.GetAllBooks);
    }
    PerstistBootStrap(data): void {
        this.kbbServiceService.setData(data, LinkEnum.setBootstrap);
    }
    PerstistErrorBlackBook(data): void {
        this.kbbServiceService.setData(data, LinkEnum.ErrorBlackBook);
    }
    PerstistErrorMainhaim(data): void {
        this.kbbServiceService.setData(data, LinkEnum.ErrorMainhaim);
    }
    PerstistErrorNADA(data): void {
        this.kbbServiceService.setData(data, LinkEnum.ErrorNADA);
    }

    PerstistMessageErrorBlackBook(data): void {
        this.kbbServiceService.setData(data, LinkEnum.ErrorMessageBlackBook);
    }
    PerstistMessageErrorMainhaim(data): void {
        this.kbbServiceService.setData(data, LinkEnum.ErrorMessageMainhaim);
    }
    PerstistMessageErrorNADA(data): void {
        this.kbbServiceService.setData(data, LinkEnum.ErrorMessageNADA);
    }


    PerstistIsSaveBlackBook(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsSaveBlackBook);
    }
    PerstistIsSaveMainhaim(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsSaveMainhaim);
    }
    PerstistIsSaveNADA(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsSaveNADA);
    }

    PerstistIsSaveKBB(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsSaveKBB);
    }
    PerstistIsRequiredBlackBook(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsRequiredBlackBook);
    }
    PerstistIsRequiredMainhaim(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsRequiredMainhaim);
    }
    PerstistIsRequiredNADA(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsRequiredNADA);
    }

    PerstistIsRequiredKBB(data): void {
        this.kbbServiceService.setData(data, LinkEnum.IsRequiredKBB);
    }


    persistBookConfigurationData(): void {
        this.kbbServiceService.setData(this.bookConfiguration, LinkEnum.GetAllRequiredBooks);

    }
    GetAllBooks = function () {
        let GetAllBooksFromCacheFromcache = this.kbbServiceService.GetAllBooksFromCache();

        if (GetAllBooksFromCacheFromcache == undefined || GetAllBooksFromCacheFromcache == null) {
            this.busyBooks = this.kbbServiceService.GetAllBooksfromAPI(this.vehicleParams).subscribe(
                (result: VinVehicleDetailBooks) => {
                    this.persistGetAllBooksData(result);
                    this.processBookData(this.vinVehicleDetailBooks = result)
                },
                (error: Response | VinVehicleDetailBooks) => this.errorHandler.handleError(error));
        }
        else {
            this.boostap = this.kbbServiceService.GetBootstapFromCache();
            this.vinVehicleDetailBooks = GetAllBooksFromCacheFromcache;
            this.ErrorBlackBook = this.kbbServiceService.GetErrorBlackBookFromCache();
            this.ErrorMainhaim = this.kbbServiceService.GetErrorMainhaimFromCache();
            this.ErrorNADA = this.kbbServiceService.GetErrorNADAFromCache();
            this.isSaveBlackBook = this.kbbServiceService.SaveBlackBookFromCache();
            this.isSaveMainhaim = this.kbbServiceService.SaveMainhaimFromCache();
            this.isSaveNADA = this.kbbServiceService.SaveNADAFromCache();
            this.isSaveKBB = this.kbbServiceService.SaveKBBFromCache();
            this.BlackbookvaluationData = this.kbbServiceService.GetBalckBookValuationFromCache();
            this.MainhaimvaluationData = this.kbbServiceService.GetManhaimValuationFromCache();
            this.NADAvaluationData = this.kbbServiceService.GetNADAValuationFromCache();
            this.KBBvaluationData = this.kbbServiceService.GetKBBValuationFromCache();
            this.BlackBookRequired = this.kbbServiceService.GetRequiredBlackBookFromCache();
            this.ManhaimRequired = this.kbbServiceService.GetRequiredMainhaimFromCache();
            this.NADARequired = this.kbbServiceService.GetRequiredNADAFromCache();
            this.KBBRequired = this.kbbServiceService.GetRequiredBBFromCache();
            this.processBookData(this.vinVehicleDetailBooks);
            this.ErrorMessageBlackBook = this.kbbServiceService.GetErrorMessageBlackBookFromCache();
            this.ErrorMessageMainhaim = this.kbbServiceService.GetErrorMessageMainhaimFromCache();
            this.ErrorMessageNADA = this.kbbServiceService.GetErrorMessageNADAFromCache();

        }
    }
    processBookData(data) {
        this.vinVehicleDetailBooks = data;
        this.refresh(data);
        this.GetMainhaimBookOnLoadTime();
        this.GetBlackBookOnLoadTime();
        this.GetNADABookOnLoadTime();
        if (!this.isKBBFailure || this.params.SourceType == 110) {
            this.GetKBBBookOnLoadTime();
        }
        else {
            //this.GetKBBV2FailureOnLoadTime();
            this.GetKBBBookOnLoadTimeOnV2Failure();
             }
        if (data != null && data != undefined) {
            this.LoadMMRValues(data);
        }
    }
    HideMMRHtml() {
        var texts = document.getElementsByTagName('text');
        if (texts.length > 0) {
            texts[0].textContent = '';
            texts[1].textContent = this.formatCurrency(this.below.toString());
            texts[2].textContent = this.formatCurrency(this.average.toString());
            texts[3].textContent = this.formatCurrency(this.above.toString());
        }
        if (texts.length >= 5) {
            texts[4].textContent = '';
        }
    }

    formatCurrency(num) {
        num = num.toString().replace(/\$|\,|\(|\)/g, '');
        if (isNaN(num)) num = "0";
        let sign: any = (num == (num = Math.abs(num)));
        num = Math.floor(num * 100 + 0.50000000001);
        let cents: any = num % 100;
        num = Math.floor(num / 100).toString();
        if (cents < 10) cents = "0"; //  + cents;
        for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
            num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
        if (sign) return ('$ ' + num); // + '.' + cents);
        else return ("(" + '$ ' + num + ")");  // + '.' + cents);
    }
    LoadMMRValues(data) {
        if (data.WholeSaleAbove != undefined) {
            this.above = data.WholeSaleAbove;
            this.below = data.WholeSaleBelow;
            this.average = data.WholeSaleAverage;
            this.majorUnit = this.average - this.below;
            this.firstRangeLow = this.below - this.majorUnit;
            this.firstRangeHigh = this.below;
            this.secondRangeLow = this.below;
            this.secondRangeHigh = this.above;
            this.thirdRangeLow = this.above;
            this.thirdRangeHigh = this.above + this.majorUnit;
            this.value = data.NationalAverage;
            setTimeout(() => {    //<<<---    using ()=> syntax
                this.HideMMRHtml();
            }, 100);
        }
    }
    ddlYear_SelectedIndexChanged = function (selected, Type) {
        if (Type == 'BlackBook') {

            this.BlackbookvaluationData.make = null;
            this.BlackbookvaluationData.bodyStyle = null;
            this.BlackbookvaluationData.model = null;
            this.BlackbookvaluationData.series = null;
            this.vinVehicleDetailBooks.BlackBook.Options = null;
            if (this.bookConfiguration.BookIDs.indexOf(30) != -1) {
                this.BlackBookMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.persistBlackBookValueationData(this.BlackbookvaluationData);

            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
            this.bookValueRequestPost.ProviderID = "4";
            this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
            this.kbbServiceService.GetMakeADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindMake(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'Mainhaim') {
            if (this.bookConfiguration.BookIDs.indexOf(40) != -1) {
                this.ManhaimMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.MainhaimvaluationData.make = null;
            this.MainhaimvaluationData.model = null;
            this.MainhaimvaluationData.bodyStyle = null;
            this.MainhaimvaluationData.NadaRegionId = "";
            this.MainhaimvaluationData.adpRegionID = "";
            this.persistMainHaimValueationData(this.MainhaimvaluationData);
            this.bookValueRequestPost.ExtColor = this.kbbServiceService.vinVehicleDetails.ExtColor;
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;
            this.kbbServiceService.GetMakeManheim(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindMake(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'NADA') {
            if (this.bookConfiguration.BookIDs.indexOf(10) != -1) {
                this.NADAMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.NADAvaluationData.make = null;
            this.NADAvaluationData.bodyStyle = null;
            this.NADAvaluationData.model = null;
            this.vinVehicleDetailBooks.NADA.Options = null;
            this.persistNADAValueationData(this.NADAvaluationData)

            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
            this.bookValueRequestPost.ProviderID = "6";
            this.bookValueRequestPost.valuationData = this.NADAvaluationData;
            this.kbbServiceService.GetMakeADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindMake(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'KBB') {
            this.KBBvaluationData.make = null;
            this.KBBvaluationData.model = null;
            this.KBBvaluationData.series = null;
            this.KBBvaluationData.Engine = null;
            this.KBBvaluationData.Transmission = null;
            this.KBBvaluationData.DriveTrain = null;
            this.vinVehicleDetailBooks.KBB.Options = null;
            this.persistKBBValueationData(this.KBBvaluationData)

            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.KBBvaluationData;
            this.kbbServiceService.GetKBBMakes(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindMake(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }


    }
    ddlMake_SelectedIndexChanged = function (selected, Type) {

        if (Type == 'BlackBook') {
            this.BlackbookvaluationData.model = null;
            this.BlackbookvaluationData.bodyStyle = null;
            this.BlackbookvaluationData.series = null;
            this.vinVehicleDetailBooks.BlackBook.Options = null;
            if (this.bookConfiguration.BookIDs.indexOf(30) != -1) {
                this.BlackBookMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.persistBlackBookValueationData(this.BlackbookvaluationData);

            this.bookValueRequestPost.BlackBookRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
            this.bookValueRequestPost.ProviderID = "4";
            this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
            this.kbbServiceService.GetModelADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindModel(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'Mainhaim') {
            if (this.bookConfiguration.BookIDs.indexOf(40) != -1) {
                this.ManhaimMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.MainhaimvaluationData.model = null;
            this.MainhaimvaluationData.series = null;
            this.MainhaimvaluationData.bodyStyle = null;
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.persistMainHaimValueationData(this.MainhaimvaluationData);

            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;
            this.kbbServiceService.GetModelManheim(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindModel(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'NADA') {
            if (this.bookConfiguration.BookIDs.indexOf(10) != -1) {
                this.NADAMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.NADAvaluationData.model = null;
            this.NADAvaluationData.series = null;
            this.NADAvaluationData.bodyStyle = null;
            this.vinVehicleDetailBooks.NADA.series = null;
            this.vinVehicleDetailBooks.NADA.Options = null;
            this.persistNADAValueationData(this.NADAvaluationData);
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;

            this.bookValueRequestPost.ProviderID = "6";
            this.bookValueRequestPost.valuationData = this.NADAvaluationData;
            this.kbbServiceService.GetTrimsADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindTrims(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'KBB') {
            this.KBBvaluationData.model = null;
            this.KBBvaluationData.series = null;
            this.KBBvaluationData.Engine = null;
            this.KBBvaluationData.Transmission = null;
            this.KBBvaluationData.DriveTrain = null;
            this.vinVehicleDetailBooks.KBB.Options = null;
            this.persistKBBValueationData(this.KBBvaluationData);

            this.bookValueRequestPost.KBBRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.KBBvaluationData;
            this.kbbServiceService.GetKBBModels(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindModel(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }

    }
    ddlModel_SelectedIndexChanged = function (selected, Type) {
        if (Type == 'BlackBook') {
            this.BlackbookvaluationData.bodyStyle = null;
            this.BlackbookvaluationData.series = null;
            this.vinVehicleDetailBooks.BlackBook.Options = null;
            if (this.bookConfiguration.BookIDs.indexOf(30) != -1) {
                this.BlackBookMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
            this.bookValueRequestPost.ProviderID = "4";
            this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
            this.kbbServiceService.GetTrimsADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindTrims(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'Mainhaim') {
            if (this.bookConfiguration.BookIDs.indexOf(40) != -1) {
                this.ManhaimMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.MainhaimvaluationData.bodyStyle = null;
            this.persistMainHaimValueationData(this.MainhaimvaluationData);

            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.MainhaimdRegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;
            this.kbbServiceService.GetBodyStyleManheim(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindBodyStyle(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }

        if (Type == 'NADA') {
            if (this.bookConfiguration.BookIDs.indexOf(10) != -1) {
                this.NADAMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.NADAvaluationData.bodyStyle = null;
            this.vinVehicleDetailBooks.NADA.Options = null;
            this.NADAvaluationData.Options = null;
            this.persistNADAValueationData(this.NADAvaluationData);
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.MainhaimdRegionId = this.vinVehicleDetailBooks.blackBookRegionId;
            this.bookValueRequestPost.kbbRegionId = this.vinVehicleDetailBooks.kbbRegionId;
            this.bookValueRequestPost.MainhaimdRegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
            this.bookValueRequestPost.ProviderID = "6";
            this.bookValueRequestPost.valuationData = this.NADAvaluationData;
            this.kbbServiceService.GetTrimsADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindTrims(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'KBB') {
            this.KBBvaluationData.series = null;
            this.KBBvaluationData.Engine = null;
            this.KBBvaluationData.Transmission = null;
            this.KBBvaluationData.DriveTrain = null;
            this.vinVehicleDetailBooks.KBB.Options = null;
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.KBBvaluationData;
            this.kbbServiceService.GetKBBTrims(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindTrims(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }

    }

    ddlSeries_SelectedIndexChanged = function (selected, Type) {
        this.name = selected;

        if (Type == 'BlackBook') {
            this.persistBlackBookValueationData(this.BlackbookvaluationData);
            this.BlackbookvaluationData = this.kbbServiceService.GetBalckBookValuationFromCache();
            this.BlackbookvaluationData.bodyStyle = null;
            this.vinVehicleDetailBooks.BlackBook.Options = null;
            this.BlackbookvaluationData.Options = null;
            this.BindBlackBook = null;
            this.persistBlackBook(null);
            if (this.bookConfiguration.BookIDs.indexOf(30) != -1) {
                this.BlackBookMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
            this.bookValueRequestPost.ProviderID = "4";
            this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
            this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
            this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
            this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;

            this.kbbServiceService.GetBodyStyleADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindBodyStyle(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'Mainhaim') {
            if (this.bookConfiguration.BookIDs.indexOf(40) != -1) {
                this.ManhaimMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.MainhaimvaluationData.bodyStyle = null;
            this.persistMainHaimValueationData(this.MainhaimvaluationData);

            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;
            this.kbbServiceService.GetBodyStyleManheim(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindBodyStyle(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'NADA') {
            if (this.bookConfiguration.BookIDs.indexOf(10) != -1) {
                this.NADAMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.NADAvaluationData.bodyStyle = null;
            this.vinVehicleDetailBooks.NADA.Options = null;
            this.persistNADAValueationData(this.NADAvaluationData);
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
            this.bookValueRequestPost.ProviderID = "6";
            this.bookValueRequestPost.valuationData = this.NADAvaluationData;
            this.kbbServiceService.GetBodyStyleADP(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindBodyStyle(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }
        if (Type == 'KBB') {
            this.KBBvaluationData.Engine = null;
            this.KBBvaluationData.Transmission = null;
            this.KBBvaluationData.DriveTrain = null;
            this.vinVehicleDetailBooks.KBB.Options = null;
            this.persistKBBValueationData(this.KBBvaluationData);
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.KBBvaluationData;
            this.kbbServiceService.GetKBB_Eng_Tran_DrvTra(this.bookValueRequestPost).subscribe(
                //   this.kbbServiceService.GetKBBEngines(this.bookValueRequestPost).subscribe(
                (result: ValuationData) => {
                    this.processBindEng_Tran_DrvTra(this.ValuationData = result, Type)

                },
                (error: Response | ValuationData) => this.errorHandler.handleError(error));
        }


    }

    ddlBodyStyle_SelectedIndexChanged = function (selected, Type) {

        if (Type == 'BlackBook') {
            if (this.bookConfiguration.BookIDs.indexOf(30) != -1) {
                this.BlackBookMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;

            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
            this.bookValueRequestPost.ProviderID = "4";
            this.BlackbookvaluationData.vin = this.vinVehicleDetails.VIN;
            this.BlackbookvaluationData.Options = "";
            this.BlackbookvaluationData.RequestXML = "";
            this.BlackbookvaluationData.Mileage = this.vinVehicleDetails.Mileage;
            this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
            this.persistBlackBookValueationData(this.BlackbookvaluationData);
            this.bookValueRequestPost.valuationData.Uvc = null;

            this.kbbServiceService.GetOptionsADP(this.bookValueRequestPost).subscribe(
                (result: OptionValues) => {
                    this.processBindOptions(this.optionValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
            this.BlackbookvaluationData.NewVehicle = false;
        }
        if (Type == 'Mainhaim') {
            this.kbbServiceService.isFinishEnable.next(false);
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.MainhaimvaluationData.vin = this.vinVehicleDetails.VIN;
            this.MainhaimvaluationData.Options = null;
            this.MainhaimvaluationData.RequestXML = "";
            this.MainhaimvaluationData.Mileage = this.vinVehicleDetails.Mileage;
            this.MainhaimvaluationData.NewVehicle = false;
            this.MainhaimvaluationData.Uvc = this.vinVehicleDetailBooks.Mainhaim.Uvc;
            this.persistMainHaimValueationData(this.MainhaimvaluationData);
            this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;

            this.bookValueRequestPost.DecodeType = "MMR";
            this.bookValueRequestPost.dealerId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.busyManheim = this.kbbServiceService.GetManheimBookValues(this.bookValueRequestPost).subscribe(
                (result: BookValue) => {
                    this.ErrorMainhaim = false;
                    this.PerstistErrorMainhaim(this.ErrorMainhaim);
                    this.processManheimBookOptionADP(this.bookValue = result)
                },
                (error: any) => {
                    this.ErrorMainhaim = true;
                    this.ErrorMessageMainhaim = error.json().message;
                    this.PerstistMessageErrorMainhaim(this.ErrorMessageMainhaim);
                    this.PerstistErrorMainhaim(this.ErrorMainhaim);

                    this.ManhaimMan = true;
                    this.BindManheim = null;
                    this.persistMainHaim(null);
                    this.BindManheim = new BookValue();
                    if (this.isKBBFailure) {
                        if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true)) {
                            this.kbbServiceService.isFinishEnable.next(true);
                        }

                    }
                    else {
                        if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true) && (this.KBBDefault == true)) {
                            this.kbbServiceService.isFinishEnable.next(true);
                        }
                    }
                    this.errorHandler.handleError(error)
                });

        }

        if (Type == 'NADA') {
            if (this.bookConfiguration.BookIDs.indexOf(10) != -1) {
                this.NADAMan = false;
                this.kbbServiceService.isFinishEnable.next(false);
            }
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
            this.bookValueRequestPost.ProviderID = "6";

            this.NADAvaluationData.Options = "";
            this.NADAvaluationData.RequestXML = "";
            this.NADAvaluationData.Mileage = this.vinVehicleDetails.Mileage;
            this.NADAvaluationData.NewVehicle = false;
            this.NADAvaluationData.Uvc = this.vinVehicleDetailBooks.NADA.Uvc;

            this.bookValueRequestPost.valuationData = this.NADAvaluationData;
            this.bookValueRequestPost.valuationData.Uvc = null;

            this.kbbServiceService.GetOptionsADP(this.bookValueRequestPost).subscribe(
                (result: OptionValuesUVC) => {
                    this.processBindOptions(this.optionValuesUVC = result, Type)

                },
                (error: Response | OptionValuesUVC) => this.errorHandler.handleError(error));
        }



        if (selected == "BB") {

        }
    }

    ddlEngine_SelectedIndexChanged = function (selected, Type) {
        this.name = selected;
        if (Type == 'KBB') {
            if (this.KBBvaluationData.Transmission != null && this.KBBvaluationData.DriveTrain != null) {
                this.isKBBOptions = true;
            }
        }
    }

    ddlTransmission_SelectedIndexChanged = function (selected, Type) {
        this.name = selected;
        if (this.KBBvaluationData.Engine != null && this.KBBvaluationData.DriveTrain != null) {
            this.isKBBOptions = true;
        }
    }

    ddlDriveTrain_SelectedIndexChanged = function (selected, Type) {
        this.name = selected;
        if (Type == 'KBB') {
            this.vinVehicleDetailBooks.KBB.Options = null;
            this.persistKBBValueationData(this.KBBvaluationData);
            this.bookValueRequestPost.NadaRegionId = "";
            this.bookValueRequestPost.adpRegionID = "";
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
            this.bookValueRequestPost.ProviderID = "5";
            this.bookValueRequestPost.valuationData = this.KBBvaluationData;
            this.kbbServiceService.GetOptionsKBB(this.bookValueRequestPost).subscribe(
                (result: IDValues) => {
                    this.processBindOptions(this.iDValues = result, Type)

                },
                (error: Response | IDValues) => this.errorHandler.handleError(error));
        }


    }
    GetAllOptionsADP = function (valuationData) {



        this.kbbServiceService.GetOptionsADPfromAPI(this.vehicleParams).subscribe(
            (result: OptionValues) => {
                this.processBookOptionADP(this.optionValues = result)
            },
            (error: Response | OptionValues) => this.errorHandler.handleError(error));
    }

    processBookOptionADP(data) {

        this.optionValues = data;

    }

    GetBookValueADP = function (KBBbookValueRequestPost, Type) {
        if (Type == "NADA") {
            this.kbbServiceService.isFinishEnable.next(false);
            this.busyNADA = this.kbbServiceService.GetBookValueNADA(KBBbookValueRequestPost).subscribe(
                (result: BookValue) => {
                    this.processGetBookValueADP(this.bookValue = result, Type)
                },
                (error: any) => {
                    this.ErrorNADA = true;
                    this.ErrorMessageNADA = error.json().message;
                    this.PerstistMessageErrorMainhaim(this.ErrorMessageNADA);
                    this.PerstistErrorNADA(this.ErrorNADA);
                    this.BindNADA = null;
                    this.persistNADA(null);
                    this.errorHandler.handleError(error)
                });
        }
        else {
            this.kbbServiceService.isFinishEnable.next(false);
            this.busyBlackBook = this.kbbServiceService.GetBookValueADP(KBBbookValueRequestPost).subscribe(
                (result: BookValue) => {
                    this.processGetBookValueADP(this.bookValue = result, Type)
                },
                (error: any) => {
                    this.ErrorBlackBook = true;
                    this.ErrorMessageBlackBook = error.json().message;
                    this.PerstistMessageErrorMainhaim(this.ErrorMessageBlackBook);

                    this.PerstistErrorBlackBook(this.ErrorBlackBook);

                    this.BindBlackBook = null;
                    this.persistBlackBook(null);
                    this.errorHandler.handleError(error)
                });
        }
    }
    GetBookValueKBB = function (KBBbookValueRequestPost, Type) {
        this.kbbServiceService.isFinishEnable.next(false);
        this.busyKBB = this.kbbServiceService.GetBookValueKBB(KBBbookValueRequestPost).subscribe(
            (result: BookValue) => {
                this.processGetBookValueADP(this.bookValue = result, Type)
            },
            (error: Response | BookValue) => this.errorHandler.handleError(error));
    }


    processGetBookValueADP(data, Type) {
        this.bookValueSaveParams.VehicleId = this.vehicleParams.VehicleId;
        this.bookValueSaveParams.StoreId = this.vehicleParams.StoreId;
        this.bookValueSaveParams.InvtryId = this.vehicleParams.InventoryId;
        this.bookValueSaveParams.UpdateResponseTableOnly = false;
        this.bookValueSaveParams.UserName = this.vehicleParams.UserName;

        if (Type == "BlackBook") {
            this.ErrorBlackBook = false;
            this.BindBlackBook = data;
            this.persistBlackBook(data);
            this.isSaveBlackBook = true;
            this.PerstistIsSaveBlackBook(true);
            this.BlackBookMan = true;
            if (this.isKBBFailure) {
                if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true)) {
                    this.kbbServiceService.isFinishEnable.next(true);
                }

            }
            else {
                if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true) && (this.KBBDefault == true)) {
                    this.kbbServiceService.isFinishEnable.next(true);
                }
            }
        }
        if (Type == "NADA") {
            this.ErrorNADA = false;
            this.BindNADA = data;
            this.persistNADA(data);
            this.isSaveNADA = true;
            this.PerstistIsSaveNADA(true);
            this.NADAMan = true;
            if (this.isKBBFailure) {
                if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true)) {
                    this.kbbServiceService.isFinishEnable.next(true);
                }

            }
            else {
                if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true) && (this.KBBDefault == true)) {
                    this.kbbServiceService.isFinishEnable.next(true);
                }
            }
        }
        if (Type == "KBB") {
            this.BindKBB = data;
            this.persistKBB(data);
            this.isSaveKBB = true;
            this.PerstistIsSaveKBB(true);
            this.KBBMan = true;
            this.KBBDefault = true;
            if (this.isKBBFailure) {
                if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true)) {
                    this.kbbServiceService.isFinishEnable.next(true);
                }

            }
            else {
                if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true) && (this.KBBDefault == true)) {
                    this.kbbServiceService.isFinishEnable.next(true);
                }
            }

        }


    }



    processManheimBookOptionADP(data) {
        if (data != null && data != undefined) {
            this.ErrorMainhaim = false;
            this.BindManheim = data;
            this.persistMainHaim(data);
            this.MainhaimvaluationData.Uvc = data.Uvc;
            this.persistMainHaimValueationData(this.MainhaimvaluationData);
            this.BindManheim.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
            this.BindManheim.decodeType = "MMR"
            this.isSaveMainhaim = true;
            this.PerstistIsSaveMainhaim(true);
            this.LoadMMRValues(data);
            this.ManhaimMan = true;
            if ((this.BlackBookMan == true) && (this.ManhaimMan == true) && (this.NADAMan == true) && (this.KBBMan == true)) {
                this.kbbServiceService.isFinishEnable.next(true);
            }
            this.bookValueSaveParams.VehicleId = this.vehicleParams.VehicleId;
            this.bookValueSaveParams.StoreId = this.vehicleParams.StoreId;
            this.bookValueSaveParams.InvtryId = this.vehicleParams.InventoryId;
            this.bookValueSaveParams.UpdateResponseTableOnly = false;
            this.bookValueSaveParams.UserName = this.vehicleParams.UserName;
        }
        else {
            this.ErrorMainhaim = true;
        }
    }
    processBindYear(data, type) {
        if (type == 'KBB') {
            this.vinVehicleDetailBooks.KBB.years = new Array<IDValues>();
            this.vinVehicleDetailBooks.KBB.years = data;
            this.vinVehicleDetailBooks.KBB.make = null;
            this.vinVehicleDetailBooks.KBB.model = null;
            this.vinVehicleDetailBooks.KBB.series = null;
            this.vinVehicleDetailBooks.KBB.Engine = null;
            this.vinVehicleDetailBooks.KBB.Transmission = null;
            this.vinVehicleDetailBooks.KBB.DriveTrain = null;
            this.BindKBB = null;
            this.persistKBB(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.KBB.years.length == 1) {
                this.KBBvaluationData.Year = new IDValues;
                this.KBBvaluationData.Year.ID = this.vinVehicleDetailBooks.KBB.years[0].ID;
                this.KBBvaluationData.Year.Value = this.vinVehicleDetailBooks.KBB.years[0].Value;
                this.ddlYear_SelectedIndexChanged("", "KBB")
            }
            this.persistKBBValueationData(this.KBBvaluationData);
        }


    }
    processBindMake(data, type) {
        if (type == 'BlackBook') {
            this.BlackbookvaluationData = this.kbbServiceService.GetBalckBookValuationFromCache();

            this.vinVehicleDetailBooks.BlackBook.make = new Array<IDValues>();
            this.vinVehicleDetailBooks.BlackBook.make = data;
            this.vinVehicleDetailBooks.BlackBook.model = null;
            this.vinVehicleDetailBooks.BlackBook.series = null;
            this.vinVehicleDetailBooks.BlackBook.DriveTrain = null;
            this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
            this.BindBlackBook = null;
            this.persistBlackBook(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.BlackBook.make.length == 1) {
                this.BlackbookvaluationData.make = new IDValues;
                this.BlackbookvaluationData.make.ID = this.vinVehicleDetailBooks.BlackBook.make[0].ID;
                this.BlackbookvaluationData.make.Value = this.vinVehicleDetailBooks.BlackBook.make[0].Value;
                this.ddlMake_SelectedIndexChanged("", "BlackBook")
            }
            this.persistBlackBookValueationData(this.BlackbookvaluationData);
        }
        if (type == 'Mainhaim') {
            this.MainhaimvaluationData = this.kbbServiceService.GetManhaimValuationFromCache();

            this.vinVehicleDetailBooks.Mainhaim.make = new Array<IDValues>();
            this.vinVehicleDetailBooks.Mainhaim.make = data;
            this.vinVehicleDetailBooks.Mainhaim.model = null;
            this.vinVehicleDetailBooks.Mainhaim.series = null;
            this.vinVehicleDetailBooks.Mainhaim.DriveTrain = null;
            this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
            this.BindManheim = null;
            this.persistMainHaim(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.Mainhaim.make.length == 1) {
                this.MainhaimvaluationData.make = new IDValues;
                this.MainhaimvaluationData.make.ID = this.vinVehicleDetailBooks.Mainhaim.make[0].ID;
                this.MainhaimvaluationData.make.Value = this.vinVehicleDetailBooks.Mainhaim.make[0].Value;
                this.ddlMake_SelectedIndexChanged("", "Mainhaim");

            }
            this.persistMainHaimValueationData(this.MainhaimvaluationData);
        }
        if (type == 'NADA') {
            this.NADAvaluationData = this.kbbServiceService.GetNADAValuationFromCache();

            this.vinVehicleDetailBooks.NADA.make = new Array<IDValues>();
            this.vinVehicleDetailBooks.NADA.make = data;
            this.vinVehicleDetailBooks.NADA.model = null;
            this.vinVehicleDetailBooks.NADA.series = null;
            this.vinVehicleDetailBooks.NADA.DriveTrain = null;
            this.vinVehicleDetailBooks.NADA.bodyStyle = null;
            this.BindNADA = null;
            this.persistNADA(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.NADA.make.length == 1) {
                this.NADAvaluationData.make = new IDValues;
                this.NADAvaluationData.make.ID = this.vinVehicleDetailBooks.NADA.make[0].ID;
                this.NADAvaluationData.make.Value = this.vinVehicleDetailBooks.NADA.make[0].Value;

                this.ddlMake_SelectedIndexChanged("", "NADA")
            }
            this.persistNADAValueationData(this.NADAvaluationData);
        }
        if (type == 'KBB') {
            this.KBBvaluationData = this.kbbServiceService.GetKBBValuationFromCache();

            this.vinVehicleDetailBooks.KBB.make = new Array<IDValues>();
            this.vinVehicleDetailBooks.KBB.make = data;
            this.vinVehicleDetailBooks.KBB.model = null;
            this.vinVehicleDetailBooks.KBB.series = null;
            this.vinVehicleDetailBooks.KBB.DriveTrain = null;
            this.vinVehicleDetailBooks.KBB.Engine = null;
            this.vinVehicleDetailBooks.KBB.Transmission = null;
            this.BindKBB = null;
            this.persistKBB(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.KBB.make.length == 1) {
                this.KBBvaluationData.make = new IDValues;
                this.KBBvaluationData.make.ID = this.vinVehicleDetailBooks.KBB.make[0].ID;
                this.KBBvaluationData.make.Value = this.vinVehicleDetailBooks.KBB.make[0].Value;
                this.ddlMake_SelectedIndexChanged("", "KBB")
            }
            this.persistKBBValueationData(this.KBBvaluationData);
        }

    }
    processBindModel(data, type) {

        if (type == 'BlackBook') {
            this.BlackbookvaluationData = this.kbbServiceService.GetBalckBookValuationFromCache();

            this.vinVehicleDetailBooks.BlackBook.model = new Array<IDValues>();
            this.vinVehicleDetailBooks.BlackBook.model = data;
            this.vinVehicleDetailBooks.BlackBook.series = null;
            this.vinVehicleDetailBooks.BlackBook.DriveTrain = null;
            this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
            this.BindBlackBook = null;
            this.persistBlackBook(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.BlackBook.model.length == 1) {
                this.BlackbookvaluationData.model = new IDValues;
                this.BlackbookvaluationData.model.ID = this.vinVehicleDetailBooks.BlackBook.model[0].ID;
                this.BlackbookvaluationData.model.Value = this.vinVehicleDetailBooks.BlackBook.model[0].Value;

                this.ddlModel_SelectedIndexChanged("", "BlackBook")
            }
            this.persistBlackBookValueationData(this.BlackbookvaluationData);

        }
        if (type == 'Mainhaim') {
            this.MainhaimvaluationData = this.kbbServiceService.GetManhaimValuationFromCache();

            this.vinVehicleDetailBooks.Mainhaim.model = new Array<IDValues>();
            this.vinVehicleDetailBooks.Mainhaim.model = data;
            this.vinVehicleDetailBooks.Mainhaim.series = null;
            this.vinVehicleDetailBooks.Mainhaim.DriveTrain = null;
            this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
            this.persistMainHaim(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.persistMainHaimValueationData(this.MainhaimvaluationData);

            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.BlackBook.model.length == 1) {
                this.MainhaimvaluationData.model = new IDValues;
                this.MainhaimvaluationData.model.ID = this.vinVehicleDetailBooks.Mainhaim.model[0].ID;
                this.MainhaimvaluationData.model.Value = this.vinVehicleDetailBooks.Mainhaim.model[0].Value;

                this.ddlModel_SelectedIndexChanged("", "BlackBook")
            }

        }
        if (type == 'NADA') {
            this.NADAvaluationData = this.kbbServiceService.GetNADAValuationFromCache();

            this.vinVehicleDetailBooks.NADA.model = new Array<IDValues>();
            this.vinVehicleDetailBooks.NADA.model = data;
            this.vinVehicleDetailBooks.NADA.series = null;
            this.vinVehicleDetailBooks.NADA.DriveTrain = null;
            this.vinVehicleDetailBooks.NADA.bodyStyle = null;
            this.BindNADA = null;
            this.persistNADA(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.NADA.model.length == 1) {
                this.NADAvaluationData.model = new IDValues;
                this.NADAvaluationData.model.ID = this.vinVehicleDetailBooks.NADA.model[0].ID;
                this.NADAvaluationData.model.Value = this.vinVehicleDetailBooks.NADA.model[0].Value;
                this.ddlModel_SelectedIndexChanged("", "BlackBook")
            }
            this.persistNADAValueationData(this.NADAvaluationData);

        }
        if (type == 'KBB') {
            this.KBBvaluationData = this.kbbServiceService.GetKBBValuationFromCache();

            this.vinVehicleDetailBooks.KBB.model = new Array<IDValues>();
            this.vinVehicleDetailBooks.KBB.model = data;
            this.vinVehicleDetailBooks.KBB.series = null;
            this.vinVehicleDetailBooks.KBB.Engine = null;
            this.vinVehicleDetailBooks.KBB.Transmission = null;
            this.vinVehicleDetailBooks.KBB.DriveTrain = null;
            this.BindKBB = null;
            this.persistKBB(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.KBB.model.length == 1) {
                this.KBBvaluationData.model = new IDValues;
                this.KBBvaluationData.model.ID = this.vinVehicleDetailBooks.KBB.model[0].ID;
                this.KBBvaluationData.model.Value = this.vinVehicleDetailBooks.KBB.model[0].Value;

                this.ddlModel_SelectedIndexChanged("", "KBB")
            }
            this.persistKBBValueationData(this.KBBvaluationData);

        }
    }

    processBindTrims(data, type) {
        if (type == 'BlackBook') {
            this.BlackbookvaluationData = this.kbbServiceService.GetBalckBookValuationFromCache();
            this.vinVehicleDetailBooks.BlackBook.series = new Array<IDValues>();
            this.vinVehicleDetailBooks.BlackBook.series = data;
            this.vinVehicleDetailBooks.BlackBook.DriveTrain = null;
            this.vinVehicleDetailBooks.BlackBook.bodyStyle = null;
            this.BindBlackBook = null;
            this.persistBlackBook(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);

            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.BlackBook.series.length == 1) {
                this.BlackbookvaluationData.series = new IDValues;
                this.BlackbookvaluationData.series.ID = this.vinVehicleDetailBooks.BlackBook.series[0].ID;
                this.BlackbookvaluationData.series.Value = this.vinVehicleDetailBooks.BlackBook.series[0].Value;

                this.ddlSeries_SelectedIndexChanged("", "BlackBook");
            }
            this.persistBlackBookValueationData(this.BlackbookvaluationData);
        }
        if (type == 'Mainhaim') {
            this.MainhaimvaluationData = this.kbbServiceService.GetManhaimValuationFromCache();

            this.vinVehicleDetailBooks.Mainhaim.series = new Array<IDValues>();
            this.vinVehicleDetailBooks.Mainhaim.series = data;
            this.vinVehicleDetailBooks.Mainhaim.DriveTrain = null;
            this.vinVehicleDetailBooks.Mainhaim.bodyStyle = null;
            this.BindManheim = null;
            this.persistMainHaim(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);

            this.refresh(this.vinVehicleDetailBooks);
        }
        if (type == 'NADA') {
            this.NADAvaluationData = this.kbbServiceService.GetNADAValuationFromCache();

            this.vinVehicleDetailBooks.NADA.series = new Array<IDValues>();
            this.vinVehicleDetailBooks.NADA.series = data;
            this.vinVehicleDetailBooks.NADA.DriveTrain = null;
            this.vinVehicleDetailBooks.NADA.bodyStyle = null;
            this.BindNADA = null;
            this.persistNADA(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);

            if (this.vinVehicleDetailBooks.NADA.series.length == 1) {
                this.NADAvaluationData.series = new IDValues;
                this.NADAvaluationData.series.ID = this.vinVehicleDetailBooks.NADA.series[0].ID;
                this.NADAvaluationData.series.Value = this.vinVehicleDetailBooks.NADA.series[0].Value;
                this.ddlSeries_SelectedIndexChanged("", "NADA");
            }
            this.persistNADAValueationData(this.NADAvaluationData);
        }
        if (type == 'KBB') {
            this.KBBvaluationData = this.kbbServiceService.GetKBBValuationFromCache();
            this.vinVehicleDetailBooks.KBB.series = new Array<IDValues>();
            this.vinVehicleDetailBooks.KBB.series = data;
            this.vinVehicleDetailBooks.KBB.Engine = null;
            this.vinVehicleDetailBooks.KBB.Transmission = null;
            this.vinVehicleDetailBooks.KBB.DriveTrain = null;
            this.BindKBB = null;
            this.persistKBB(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);

            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.KBB.series.length == 1) {
                this.KBBvaluationData.series = new IDValues;
                this.KBBvaluationData.series.ID = this.vinVehicleDetailBooks.KBB.series[0].ID;
                this.KBBvaluationData.series.Value = this.vinVehicleDetailBooks.KBB.series[0].Value;
                this.ddlSeries_SelectedIndexChanged("", "KBB");

            }
            this.persistKBBValueationData(this.KBBvaluationData);
        }
    }

    processBindBodyStyle(data, type) {
        if (type == 'BlackBook') {

            this.BlackbookvaluationData = this.kbbServiceService.GetBalckBookValuationFromCache();

            this.vinVehicleDetailBooks.BlackBook.bodyStyle = new Array<IDValues>();
            this.vinVehicleDetailBooks.BlackBook.bodyStyle = data;
            this.BindBlackBook = null;
            this.persistBlackBook(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);

            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.BlackBook.bodyStyle.length == 1) {
                this.BlackbookvaluationData.bodyStyle = new IDValues;
                this.BlackbookvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.BlackBook.bodyStyle[0].ID;
                this.BlackbookvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.BlackBook.bodyStyle[0].Value;

                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;

                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
                this.bookValueRequestPost.ProviderID = "4";
                this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
                this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.valuationData.Options = null;
                this.bookValueRequestPost.valuationData.Uvc = null;
                this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;

                this.kbbServiceService.GetOptionsADP(this.bookValueRequestPost).subscribe(
                    (result: OptionValuesUVC) => {
                        this.processBindOptions(this.optionValuesUVC = result, type)

                    },
                    (error: Response | OptionValuesUVC) => this.errorHandler.handleError(error));
            }
            this.persistBlackBookValueationData(this.BlackbookvaluationData);

        }
        if (type == 'Mainhaim') {
            this.vinVehicleDetailBooks.Mainhaim.bodyStyle = new Array<IDValues>();
            this.vinVehicleDetailBooks.Mainhaim.bodyStyle = data;
            this.BindManheim = null;
            this.persistMainHaim(null)
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.MainhaimvaluationData = this.kbbServiceService.GetManhaimValuationFromCache();

            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.Mainhaim.bodyStyle.length == 1) {
                this.MainhaimvaluationData.bodyStyle = new IDValues;
                this.MainhaimvaluationData.bodyStyle.ID = this.vinVehicleDetailBooks.Mainhaim.bodyStyle[0].ID;
                this.MainhaimvaluationData.bodyStyle.Value = this.vinVehicleDetailBooks.Mainhaim.bodyStyle[0].Value;
                this.bookValueRequestPost.valuationData = this.MainhaimvaluationData;
                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;

                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.MainhaimdRegionId;
                this.bookValueRequestPost.ProviderID = "6";
                this.bookValueRequestPost.valuationData.Uvc = null;

                this.kbbServiceService.GetOptionsADP(this.bookValueRequestPost).subscribe(
                    (result: OptionValuesUVC) => {
                        this.processBindOptions(this.optionValuesUVC = result, type)

                    },
                    (error: Response | OptionValuesUVC) => this.errorHandler.handleError(error));
            }
            this.persistMainHaimValueationData(this.MainhaimvaluationData);
        }
        if (type == 'NADA') {
            this.NADAvaluationData = this.kbbServiceService.GetNADAValuationFromCache();

            this.vinVehicleDetailBooks.NADA.bodyStyle = new Array<IDValues>();
            this.vinVehicleDetailBooks.NADA.bodyStyle = data;
            this.BindNADA = null;
            this.persistNADA(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.NADA.bodyStyle.length == 1) {
                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
                this.bookValueRequestPost.ProviderID = "5";
                this.bookValueRequestPost.valuationData = this.NADAvaluationData;
                this.kbbServiceService.GetOptionsADP(this.bookValueRequestPost).subscribe(
                    (result: OptionValuesUVC) => {
                        this.processBindOptions(this.optionValuesUVC = result, type)

                    },
                    (error: Response | OptionValuesUVC) => this.errorHandler.handleError(error)),
                    this.kbbServiceService.isFinishBookDisable.next(false);
            }
        }
    }

    processBindEng_Tran_DrvTra(data, type) {
        if (type == 'KBB') {
            this.KBBvaluationData = this.kbbServiceService.GetKBBValuationFromCache();
            this.vinVehicleDetailBooks.KBB.Engine = new Array<IDValues>();
            this.vinVehicleDetailBooks.KBB.Engine = data.Engine;
            this.vinVehicleDetailBooks.KBB.Transmission = new Array<IDValues>();
            this.vinVehicleDetailBooks.KBB.Transmission = data.Transmission;
            this.vinVehicleDetailBooks.KBB.DriveTrain = new Array<IDValues>();
            this.vinVehicleDetailBooks.KBB.DriveTrain = data.DriveTrain;
            this.BindKBB = null;
            this.persistKBB(null);
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);

            this.refresh(this.vinVehicleDetailBooks);
            if (this.vinVehicleDetailBooks.KBB.Engine.length == 1) {
                this.KBBvaluationData.Engine = new IDValues;
                this.KBBvaluationData.Engine.ID = this.vinVehicleDetailBooks.KBB.Engine[0].ID;
                this.KBBvaluationData.Engine.Value = this.vinVehicleDetailBooks.KBB.Engine[0].Value;
            }
            if (this.vinVehicleDetailBooks.KBB.Transmission.length == 1) {
                this.KBBvaluationData.Transmission = new IDValues;
                this.KBBvaluationData.Transmission.ID = this.vinVehicleDetailBooks.KBB.Transmission[0].ID;
                this.KBBvaluationData.Transmission.Value = this.vinVehicleDetailBooks.KBB.Transmission[0].Value;
            }
            if (this.vinVehicleDetailBooks.KBB.DriveTrain.length == 1) {
                this.KBBvaluationData.DriveTrain = new IDValues;
                this.KBBvaluationData.DriveTrain.ID = this.vinVehicleDetailBooks.KBB.DriveTrain[0].ID;
                this.KBBvaluationData.DriveTrain.Value = this.vinVehicleDetailBooks.KBB.DriveTrain[0].Value;
                this.ddlDriveTrain_SelectedIndexChanged(this.KBBvaluationData.DriveTrain.Value, "KBB");
            }

            this.persistKBBValueationData(this.KBBvaluationData);
        }
    }

    processBindOptions(data, type) {
        if (type == 'BlackBook') {
            this.vinVehicleDetailBooks.BlackBook.Options = new Array<OptionValues>();
            this.vinVehicleDetailBooks.BlackBook.Options = data.optionsUVC;
            this.BindBlackBook = null;
            this.persistBlackBook(null);
            if (data.UVC != null) {
                this.vinVehicleDetailBooks.BlackBook.Uvc = data.UVC;
            }

            this.refresh(this.vinVehicleDetailBooks);
            if (data.optionsUVC.length == 0) {
                this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                if (data.UVC == null) {
                    this.BlackbookvaluationData.Uvc = this.vinVehicleDetailBooks.BlackBook.Uvc;
                }
                else {
                    this.BlackbookvaluationData.Uvc = data.UVC;
                }
                this.BlackbookvaluationData.Options = data.optionsUVC;
                this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;

                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
                this.bookValueRequestPost.ProviderID = "4";
                this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;
                this.persistBlackBookValueationData(this.BlackbookvaluationData);
                this.bookValueRequestPost.valuationData.Options = this.vinVehicleDetailBooks.BlackBook.Options.filter(x => x.Selected == true);
                this.GetBookValueADP(this.bookValueRequestPost, "BlackBook");
            }

        }
        else if (type == 'Mainhaim') {
            this.vinVehicleDetailBooks.Mainhaim.Options = new Array<OptionValues>();
            this.vinVehicleDetailBooks.Mainhaim.Options = data.optionsUVC;
            this.BindManheim = null;
            this.persistMainHaim(null);
            this.vinVehicleDetailBooks.Mainhaim.Uvc = data.UVC;
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);

            this.refresh(this.vinVehicleDetailBooks);
        }
        else if (type == 'NADA') {
            this.vinVehicleDetailBooks.NADA.Options = new Array<OptionValues>();
            this.vinVehicleDetailBooks.NADA.Options = data.optionsUVC;
            this.BindNADA = null;
            this.persistNADA(null);

            this.refresh(this.vinVehicleDetailBooks);
            if (data.UVC != null) {
                this.vinVehicleDetailBooks.NADA.Uvc = data.UVC;
            }

            this.persistGetAllBooksData(this.vinVehicleDetailBooks);
            if (data.optionsUVC.length == 0) {
                this.NADAvaluationData.Options = data.optionsUVC;
                this.NADAvaluationData.Uvc = this.vinVehicleDetailBooks.NADA.Uvc;
                this.persistNADAValueationData(this.NADAvaluationData);

                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
                this.bookValueRequestPost.ProviderID = "6";
                this.bookValueRequestPost.valuationData = this.NADAvaluationData;
                this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.valuationData.Options = this.vinVehicleDetailBooks.NADA.Options.filter(x => x.Selected == true);
                this.GetBookValueADP(this.bookValueRequestPost, "NADA");
            }


        }
        else if (type == 'KBB' && !this.isKBBFailure) {
            this.isGetProceess == true;
            this.KBBvaluationData = this.kbbServiceService.GetKBBValuationFromCache();
            this.vinVehicleDetailBooks.KBB.Options = new Array<OptionValues>();
            this.vinVehicleDetailBooks.KBB.Options = data.optionsUVC;
            this.refresh(this.vinVehicleDetailBooks);
            this.vinVehicleDetailBooks.KBB.Uvc = data.UVC;
            this.persistGetAllBooksData(this.vinVehicleDetailBooks);

            this.bookValueRequestPost.valuationData = this.KBBvaluationData;
            this.bookValueRequestPost.valuationData.RequestXML = "";
            this.bookValueRequestPost.ProviderID = "5";

            this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
            this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
            this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
            this.bookValueRequestPost.valuationData.Options = new Array<OptionValues>()
            this.bookValueRequestPost.valuationData.Options = data.optionsUVC;
            this.bookValueRequestPost.valuationData.RequestXML = "";
            this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;


            this.optionValuesKBB = this.bookValueRequestPost.valuationData.Options;

            this.factoryOptionsData = this.kbbServiceService.GetKBBFactoryOptionsFromCache(this.vehicleParams);


            let factoryArray = [];
            let factoryArray1 = [];
            var vehicleFactoryOptions1 = [];

            for (let categories of this.factoryOptionsData) {
                factoryArray.push(categories.factoryItem);
            }
            for (let categories of factoryArray) {
                for (let categorie of categories) {
                    if (categorie.isSelected == true) {
                        factoryArray1.push(categorie);
                    }
                }
            }
            let optionValuesKBB1 = [];
            for (var option1 of this.optionValuesKBB) {
                option1.Selected = false;
                optionValuesKBB1.push(option1);
            }
            if (optionValuesKBB1.length >= 1) {
                for (var item of factoryArray1) {
                    for (var option of optionValuesKBB1) {
                        if (option.ID.toString() == item.optionId.toString() && option.Value == item.displayName) {
                            if (item.isSelected == true) {
                                option.Selected = true;
                            }
                        }
                    }
                }
            }
            this.bookValueRequestPost.valuationData.Options = optionValuesKBB1;
            this.KBBvaluationData.Uvc = this.vinVehicleDetailBooks.KBB.Uvc;
            this.GetBookValueKBB(this.bookValueRequestPost, "KBB");

        }
        else if (type == 'KBB' && this.isKBBFailure) {
            this.vinVehicleDetailBooks.KBB.Options = new Array<OptionValues>();
            this.vinVehicleDetailBooks.KBB.Options = data.optionsUVC;
            this.BindKBB = null;
            this.persistKBB(null);
            if (data.UVC != null || data.UVC != " ") {
                this.vinVehicleDetailBooks.KBB.Uvc = data.UVC;
            }

            this.refresh(this.vinVehicleDetailBooks);
            if (data.optionsUVC.length == 0) {
                this.persistGetAllBooksData(this.vinVehicleDetailBooks);
                if (data.UVC == null) {
                    this.KBBvaluationData.Uvc = this.vinVehicleDetailBooks.KBB.Uvc;
                }
                else {
                    this.KBBvaluationData.Uvc = data.UVC;
                }
                this.KBBvaluationData.Options = data.optionsUVC;
                this.bookValueRequestPost.valuationData = this.KBBvaluationData;
                this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;

                this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
                this.bookValueRequestPost.ProviderID = "5";
                this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
                this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
                this.bookValueRequestPost.Millage = this.vinVehicleDetails.Mileage;
                this.persistKBBValueationData(this.KBBvaluationData);
                this.bookValueRequestPost.valuationData.Options = this.vinVehicleDetailBooks.KBB.Options.filter(x => x.Selected == true);
                this.GetBookValueKBB(this.bookValueRequestPost, "KBB");
            }
            if (this.KBBvaluationData.Engine == null || this.KBBvaluationData.Transmission == null) {
                this.isKBBOptions = false;
            }

        }
    }
    refresh(data: VinVehicleDetailBooks) {
        if (data.BlackBook != null) {
            if (data.BlackBook.years != null && data.BlackBook.years.length > 1) this.isBBYear = false;
            if (data.BlackBook.make != null && data.BlackBook.make.length > 1) { this.isBBMake = false } else { this.isBBMake = true };
            if (data.BlackBook.model != null && data.BlackBook.model.length > 1) { this.isBBModel = false } else { this.isBBModel = true };
            if (data.BlackBook.series != null && data.BlackBook.series.length > 1) { this.isBBSeriesTrim = false } else { this.isBBSeriesTrim = true };
            if (data.BlackBook.bodyStyle != null && data.BlackBook.bodyStyle.length > 1) { this.isBBBodyStyle = false } else { this.isBBBodyStyle = true };
            if (data.BlackBook.Options != null && data.BlackBook.Options.length > 0) { this.isBBOptions = true } else { this.isBBOptions = false };
        }
        if (data.NADA != null) {
            if (data.NADA.years != null && data.NADA.years.length > 1) { this.isNadaYear = false } else { this.isNadaYear = true };
            if (data.NADA.make != null && data.NADA.make.length > 1) { this.isNadaMake = false } else { this.isNadaMake = true };
            if (data.NADA.model != null && data.NADA.model.length > 1) { this.isNadaModel = false } else { this.isNadaModel = true };
            if (data.NADA.series != null && data.NADA.series.length > 1) { this.isNadaSeriesTrim = false; } else { this.isNadaSeriesTrim = true; }
            if (data.NADA.bodyStyle != null && data.NADA.bodyStyle.length > 1) { this.isNadaBodyStyle = false; } else { this.isNadaBodyStyle = true; }
            if (data.NADA.Options != null && data.NADA.Options.length > 0) { this.isNadaOptions = true } else { this.isNadaOptions = false };
        }
        if (data.Mainhaim != null) {
            if (data.Mainhaim.years != null && data.Mainhaim.years.length > 1) { this.isMhmYear = false } else { this.isMhmYear = true; }
            if (data.Mainhaim.make != null && data.Mainhaim.make.length > 1) { this.isMhmMake = false; } else { this.isMhmMake = true; }
            if (data.Mainhaim.model != null && data.Mainhaim.model.length > 1) { this.isMhmModel = false; } else { this.isMhmModel = true; }
            if (data.Mainhaim.series != null && data.Mainhaim.series.length > 1) { this.isMhmSeriesTrim = false; } else { this.isMhmSeriesTrim = true; }
            if (data.Mainhaim.bodyStyle != null && data.Mainhaim.bodyStyle.length > 1) { this.isMhmBodyStyle = false; } else { this.isMhmBodyStyle = true; }
            if (data.Mainhaim.Options != null && data.Mainhaim.Options.length > 0) { this.isMhmOptions = true; }
        }
        if (data.KBB != null && this.isKBBFailure) {
            if (data.KBB.years != null && data.KBB.years.length > 1) { this.isKBBYear = false } else { this.isKBBYear = true; }
            if (data.KBB.make != null && data.KBB.make.length > 1) { this.isKBBMake = false; } else { this.isKBBMake = true; }
            if (data.KBB.model != null && data.KBB.model.length > 1) { this.isKBBModel = false; } else { this.isKBBModel = true; }
            if (data.KBB.series != null && data.KBB.series.length > 1) { this.isKBBSeriesTrim = false; } else { this.isKBBSeriesTrim = true; }
            if (data.KBB.Engine != null && data.KBB.Engine.length > 1) { this.isKBBEngine = false; } else { this.isKBBEngine = true; }
            if (data.KBB.Transmission != null && data.KBB.Transmission.length > 1) { this.isKBBTransmission = false; } else { this.isKBBTransmission = true; }
            if (data.KBB.DriveTrain != null && data.KBB.DriveTrain.length > 1) { this.isKBBDriveTrain = false; } else { this.isKBBDriveTrain = true; }
            if (data.KBB.Options != null && data.KBB.Options.length > 0) { this.isKBBOptions = true; } else { this.isKBBOptions = false; }
        }

    }
    updateBlackBook() {
        this.isSaveBlackBook = true;
        this.PerstistIsSaveBlackBook(true);
        this.bookValueRequestPost.NadaRegionId = "";
        this.bookValueRequestPost.adpRegionID = "";
        this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
        this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.blackBookRegionId;
        this.bookValueRequestPost.ProviderID = "4";
        this.bookValueRequestPost.valuationData = this.BlackbookvaluationData;
        this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
        this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;

        this.BlackbookvaluationData.Uvc = this.vinVehicleDetailBooks.BlackBook.Uvc;
        this.persistBlackBookValueationData(this.BlackbookvaluationData);

        this.bookValueRequestPost.valuationData.Options = this.vinVehicleDetailBooks.BlackBook.Options.filter(x => x.Selected === true);
        this.GetBookValueADP(this.bookValueRequestPost, "BlackBook");

    }
    updateNADA() {
        this.isSaveNADA = true;
        this.PerstistIsSaveNADA(true);
        this.bookValueRequestPost.NadaRegionId = "";
        this.bookValueRequestPost.adpRegionID = "";
        this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
        this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.nadaRegionId;
        this.bookValueRequestPost.ProviderID = "6";
        this.bookValueRequestPost.valuationData = this.NADAvaluationData;
        this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
        this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
        this.NADAvaluationData.Uvc = this.vinVehicleDetailBooks.NADA.Uvc;
        this.persistNADAValueationData(this.NADAvaluationData);


        this.bookValueRequestPost.valuationData.Options = this.vinVehicleDetailBooks.NADA.Options.filter(x => x.Selected === true);;
        this.GetBookValueADP(this.bookValueRequestPost, "NADA");


    }

    updateKBB() {
        this.isSaveKBB = true;
        this.PerstistIsSaveKBB(true);
        this.bookValueRequestPost.NadaRegionId = "";
        this.bookValueRequestPost.adpRegionID = "";
        this.bookValueRequestPost.dealerId = this.vinVehicleDetailBooks.dealerId;
        this.bookValueRequestPost.RegionId = this.vinVehicleDetailBooks.kbbRegionId;
        this.bookValueRequestPost.ProviderID = "5";
        this.bookValueRequestPost.valuationData = this.KBBvaluationData;
        this.bookValueRequestPost.valuationData.vin = this.vinVehicleDetails.VIN;
        this.bookValueRequestPost.valuationData.Mileage = this.vinVehicleDetails.Mileage;
        this.KBBvaluationData.Uvc = this.vinVehicleDetailBooks.KBB.Uvc;
        this.persistKBBValueationData(this.KBBvaluationData);


        this.bookValueRequestPost.valuationData.Options = this.vinVehicleDetailBooks.KBB.Options.filter(x => x.Selected === true);;
        this.GetBookValueKBB(this.bookValueRequestPost, "KBB");


    }

    PrintBookout() {
        this.isprintbookOut = true;
        this.isBookNotSaved = true;
        this.saveBookDetails();

        window.open("../../Reports/Pages/PrintandSaveBookout.aspx?VehicleID=" + this.vehicleParams.VehicleId + "&StoreID=" + this.vehicleParams.StoreId + "&InvID=" + this.vehicleParams.InventoryId);
    }

    processFactoryOptionselectedData() {
    }

    toggleManagerNotes() {
        this.showManagerNotes = !this.showManagerNotes;
        this.kbbServiceService.showManagerNotes = this.showManagerNotes;
        if (this.showManagerNotes) {
            this.toggleManagerNotesText = 'Hide Manager Notes';
        }
        else {
            this.toggleManagerNotesText = 'Show Manager Notes';
        }
    }
    persistentVehicleManagerNotes() {
        this.kbbServiceService.vinVehicleDetails.ManagerNote = this.managerNotes;
        this.kbbServiceService.managerNotesText = this.managerNotes;
    }

    saveManagerNotes() {
        let body = JSON.stringify(this.kbbServiceService.vinVehicleDetails);
        this.kbbServiceService.SaveVehicleDetails(body).subscribe(
            (result: SIMSResponseData) => {
                if (!this.showPricingStep && !this.isprintbookOut) {
                    this.Redirect(result);
                }
            },
            (error: Response | any) => this.errorHandler.handleError(error));
    }
}
