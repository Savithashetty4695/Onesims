import { Component, OnInit, Input } from '@angular/core';
import { Gallery, GalleryConfig, GalleryItem } from 'ng-gallery';
import { VehicleParams } from '../Model/vehicle-params.model';
import { ErrorHandler } from '../common/error-handler';
import { KBBServiceService } from '../Services/kbbservice.service';
import { VehiclePhotoWrapper } from '../model/vehicle-photo-details';
import { Response } from '@angular/http';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { VehiclePhoto } from '../model/vehicle-photo';



@Component({
    selector: 'app-photo-import',
    templateUrl: './photo-import.component.html',
    styleUrls: ['./photo-import.component.css']
})
export class PhotoImportComponent implements OnInit {
    @Input() phototype: string; // Appraisal or Marketing
    @Input() vSection: string; //0=DriverSide, 1=Front, 2=PassengerSide, 3=Rear, 4=Interior, 5=Mechanical, 6=Marketing
    PhotoID: number;
    AppraisalStatus: number[] = [101, 102];
    MarketingStatus: number[] = [201, 202, 203, 204, 205, 214, 215, 216, 217, 218, 219, 221, 232, 236, 238];
    SaleStatus: number[] = [301, 302, 303, 305];
    params: VehicleParams;
    errorHandler: ErrorHandler;
    //vehiclePhotoDetails: VehiclePhotoDetails;
    photoWrapper: VehiclePhotoWrapper;
    closeResult: string;
    busyA: Subscription;
    busyB: Subscription;


    bScreen: boolean;

    reqshowGallery = false;

    photosPerSlide: number = 6;
    totalSlides: number;
    constructor(private gallery: Gallery, public kbbServiceService: KBBServiceService, private modalService: NgbModal) {
        this.params = new VehicleParams();
        this.errorHandler = new ErrorHandler();
        this.photoWrapper = new VehiclePhotoWrapper();
    }
    appraisalImages = [];
    marketingImages = [];
    sectionPhotos = [];

    ngOnInit() {
        this.params = this.kbbServiceService.getVehicleParameters();
        //let StatusId: number = this.kbbServiceService.GetVehicleDetailsFromCache(null).StatusID;
        //this.params.SourceType = parseInt(this.kbbServiceService.GetVehicleDetailsFromCache(null).SourceType, 10);
        this.bScreen = window.innerHeight > 768 ? true : false;
        this.getPhotos();
        this.kbbServiceService.uploadComplete$.subscribe(result => {
            this.getPhotos();
        })
    }

    getPhotos() {
        this.params.StatusId = this.vSection == "mktng" ? 20 : 10;
        //this.params.StatusId = this.phototype == "Appraisal" ? 10 : this.phototype == "Marketing" ? 20 : 0;

        this.busyA = this.kbbServiceService.GetAppraisalPhotos(this.params).subscribe(
            (result: VehiclePhotoWrapper) => {
                this.photoWrapper = result;
                this.MakePhotoGallery(result);
            },
            (error: Response | any) => this.errorHandler.handleError(error));
    }

    delete(photoId: number): void {

        this.params = this.kbbServiceService.getVehicleParameters();
        this.params.StatusId = this.vSection == "mktng" ? 20 : 10;
        //this.params.StatusId = this.phototype == "Appraisal" ? 10 : this.phototype == "Marketing" ? 20 : 0;
        this.gallery.reset();
        this.busyB = this.kbbServiceService.DeleteAppraisalPhoto(this.params, photoId).subscribe(
            (result: VehiclePhotoWrapper) => {
                this.photoWrapper = result;
                this.MakePhotoGallery(result);
            },
            (error: Response | any) => this.errorHandler.handleError(error));

    }

    makeCarousel(section: VehiclePhoto[]) {
        this.sectionPhotos = [];
        if (section != null) {
            var isDivisible = section.length % this.photosPerSlide == 0 ? true : false;
            var arrays = Math.floor(section.length / this.photosPerSlide);
            this.totalSlides = isDivisible ? arrays : arrays + 1;
            for (var i = 0; i < this.totalSlides; i++) {
                var dummyArray = [];
                for (var j = i * this.photosPerSlide; j < section.length; j++) {
                    if (j < this.photosPerSlide * (i + 1)) {
                        dummyArray.push({
                            src: section[j].Media_Photo_Url,
                            thumbnail: section[j].Media_Thumbnail_Url == null ||
                                section[j].Media_Thumbnail_Url == undefined ||
                                section[j].Media_Thumbnail_Url == ""
                                ? section[j].Media_Photo_Url
                                : section[j].Media_Thumbnail_Url,
                            text: section[j].PhotoCaption,
                            photoId: section[j].Photo_ID,
                            Photo_Cat: section[j].Photo_Cat,
                            photoGuide: this.setImageText(section[j].PhotoGuide)
                        })
                    }
                    else {

                        break;
                    }
                }
                this.sectionPhotos[i] = dummyArray;
            }
        }
    }
    makeappraislaCarousel() {
        this.sectionPhotos = [];
        var section = this.appraisalImages
        if (section != null) {
            var isDivisible = section.length % this.photosPerSlide == 0 ? true : false;
            var arrays = Math.floor(section.length / this.photosPerSlide);
            this.totalSlides = isDivisible ? arrays : arrays + 1;
            for (var i = 0; i < this.totalSlides; i++) {
                var dummyArray = [];
                for (var j = i * this.photosPerSlide; j < section.length; j++) {
                    if (j < this.photosPerSlide * (i + 1)) {
                        dummyArray.push({
                            src: section[j].src,
                            thumbnail: section[j].thumbnail,
                            text: section[j].text,
                            photoId: section[j].photoId,
                            Photo_Cat: section[j].Photo_Cat,
                            photoGuide: this.setImageText(section[j].photoGuide)
                        })
                    }
                    else {

                        break;
                    }
                }
                this.sectionPhotos[i] = dummyArray;
            }
        }
    }

    makeAppraisalGallery(appraisal: VehiclePhoto[]) {

        if (appraisal != null) {
            for (var item of appraisal) {
                this.appraisalImages.push({
                    src: item.Media_Photo_Url,
                    thumbnail: item.Media_Thumbnail_Url == null ||
                        item.Media_Thumbnail_Url == undefined ||
                        item.Media_Thumbnail_Url == ""
                        ? item.Media_Photo_Url
                        : item.Media_Thumbnail_Url,
                    text: item.PhotoCaption,
                    photoId: item.Photo_ID,
                    Photo_Cat: item.Photo_Cat,
                    photoGuide: item.PhotoGuide
                });
            }
        }
    }

    makeMarketingGallery(marketing: VehiclePhoto[]) {
        this.marketingImages = [];
        if (marketing != null) {
            for (var item of marketing) {
                this.marketingImages.push({
                    src: item.Media_Photo_Url,
                    thumbnail: item.Media_Thumbnail_Url == null ||
                        item.Media_Thumbnail_Url == undefined ||
                        item.Media_Thumbnail_Url == ""
                        ? item.Media_Photo_Url
                        : item.Media_Thumbnail_Url,
                    text: item.PhotoCaption,
                    photoId: item.Photo_ID,
                    Photo_Cat: item.Photo_Cat
                });
            }
        }
    }

    MakePhotoGallery(data: VehiclePhotoWrapper): void {
        switch (this.vSection) {
            case "appraisal":
                this.appraisalImages = [];
                this.makeAppraisalGallery(data.DriverSide);
                this.kbbServiceService.DsLatestThumbnail.next(data.DsLatestThumbnail);
                this.kbbServiceService.DsLatestWheelThumbnail.next(data.DsLatestWheelThumbnail);
                this.kbbServiceService.DsLatestAdditionalThumbnail.next(data.DsLatestAdditionalThumbnail);
                this.makeAppraisalGallery(data.Front);
                this.kbbServiceService.FrontLatestThumbnail.next(data.FrontLatestThumbnail);
                this.kbbServiceService.FrontLatestAdditionalThumbnail.next(data.FrontLatestAdditionalThumbnail);
                this.makeAppraisalGallery(data.PassengerSide);
                this.kbbServiceService.PsLatestThumbnail.next(data.PsLatestThumbnail);
                this.kbbServiceService.PsLatestWheelThumbnail.next(data.PsLatestWheelThumbnail);
                this.kbbServiceService.PsLatestAdditionalThumbnail.next(data.PsLatestAdditionalThumbnail);
                this.makeAppraisalGallery(data.Rear);
                this.kbbServiceService.RearLatestThumbnail.next(data.RearLatestThumbnail);
                this.kbbServiceService.RearLatestAdditionalThumbnail.next(data.RearLatestAdditionalThumbnail);
                this.makeAppraisalGallery(data.Interior);
                this.kbbServiceService.VinLatestThumbnail.next(data.VinLatestThumbnail);
                this.kbbServiceService.DashboardLatestWheelThumbnail.next(data.DashboardLatestWheelThumbnail);
                this.kbbServiceService.OdometerLatestAdditionalThumbnail.next(data.OdometerLatestAdditionalThumbnail);
                this.kbbServiceService.FrontSeatLatestThumbnail.next(data.FrontSeatLatestThumbnail);
                this.kbbServiceService.BackSeatLatestThumbnail.next(data.BackSeatLatestThumbnail);
                this.kbbServiceService.InteriorLatestAdditionalThumbnail.next(data.InteriorLatestAdditionalThumbnail);
                this.makeappraislaCarousel();
                break;
            case "mktng":
                this.makeMarketingGallery(data.MarketingPhotos);
                break;
            case "ddc":
                this.makeMarketingGallery(data.DDCAdditionalPhotos);
                break;
        }
    }
    showGallery(i: number, phType: string): void {
        this.kbbServiceService.reqGallery = true;
        if (phType == "Appraisal") {
            this.gallery.load(this.appraisalImages);
        }
        else {
            this.gallery.load(this.marketingImages);
        }
        this.gallery.set(i);
        this.getGalleryConfig();
    }
    open(content, photoId: number) {
        document.getElementById('errMsgPhotoUpload').innerHTML = "";
        this.modalService.open(content, { windowClass: 'custom-modal' });
        this.PhotoID = photoId;

    }
    makeSinglePhotoGallery(sender: string, flag: string) {
        switch (flag) {
            case "ds": this.showSinglePhotoGallery(this.photoWrapper.DriverSide.filter(x => x.Media_Thumbnail_Url === sender));
                break;
            case "front": this.showSinglePhotoGallery(this.photoWrapper.Front.filter(x => x.Media_Thumbnail_Url === sender));
                break;
            case "ps": this.showSinglePhotoGallery(this.photoWrapper.PassengerSide.filter(x => x.Media_Thumbnail_Url === sender));
                break;
            case "rear": this.showSinglePhotoGallery(this.photoWrapper.Rear.filter(x => x.Media_Thumbnail_Url === sender));
                break;
            case "interior": this.showSinglePhotoGallery(this.photoWrapper.Interior.filter(x => x.Media_Thumbnail_Url === sender));
                break;

        }
    }
    showSinglePhotoGallery(imageArray: VehiclePhoto[]) {
        this.kbbServiceService.reqGallery = true;
        let img: GalleryItem[] = [{
            src: imageArray[0].Media_Photo_Url,
            thumbnail: imageArray[0].Media_Thumbnail_Url,
            text: imageArray[0].PhotoCaption
            }];
        this.gallery.load(img);
        this.gallery.set(0);
        this.getGalleryConfig();
    }

    getGalleryConfig(): any {
        return this.gallery.config = JSON.parse(
            `{
  "style": {
    "background": "#121519",
    "width": "100%",
    "height": "100%",
    "padding": "1em"   
  },
  "animation": "fade",
  "loader": {
    "width": "50px",
    "height": "50px",
    "position": "center",
    "icon": "oval"
  },
  "description": {
    "position": "top",
    "overlay": false,
    "text": false,
    "counter": true
  },
  "navigation": true,
  "bullets": {
    "position": "bottom"
  },
  "player": {
    "autoplay": false,
    "speed": 3000
  },
  "thumbnails": {
    "width": 120,
    "height": 90,
    "position": "bottom",
    "space": 20
  }
}`);
    }
    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
    setImageText(photoGuide): string {
        let text: string;
        switch (photoGuide) {
            case 'photo-driver-side': text = 'Driver Side'; break;
            case 'ds-wheel-photo': text = 'Driver Side Wheel'; break;
            case 'photo-front': text = 'Front'; break;
            case 'photo-passenger-side': text = 'Passenger Side'; break;
            case 'ps-wheel-photo': text = 'Passenger Side Wheel'; break;
            case 'photo-rear': text = 'Rear'; break;
            case 'photo-vin': text = 'VIN'; break;
            case 'photo-dashboard': text = 'Dashboard'; break;
            case 'photo-odometer': text = 'Odometer'; break;
            case 'photo-interior-front': text = 'Interior Front'; break;
            case 'photo-interior-rear': text = 'Interior Rear'; break;
            default: text = 'Additional'; break;

        }
        return text;
    }
}
