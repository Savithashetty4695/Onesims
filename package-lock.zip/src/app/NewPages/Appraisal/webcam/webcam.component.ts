import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
@Component({
    selector: 'app-webcam',
    templateUrl: './webcam.component.html',
    styleUrls: ['./webcam.component.css']
})
export class WebcamComponent implements OnInit {
    filesToUpload: Array<string>;
    showId: boolean;
    @ViewChild('video',{static: false}) video: any;
    @ViewChild('image',{static: false}) img: ElementRef;

    @ViewChild('canvas',{static: false}) canvas: ElementRef;
    private context: CanvasRenderingContext2D;
    @Output() uploadPhoto: EventEmitter<string> = new EventEmitter();

    constructor() {
        this.showId = false;
    }
    public snapshot() {
        this.showId = true;
        this.canvas.nativeElement.style.display = "block";
        this.context = this.canvas.nativeElement.getContext("2d");
        this.context.drawImage(this.video.nativeElement, 0, 0, this.canvas.nativeElement.clientWidth, this.canvas.nativeElement.clientHeight);
        this.img.nativeElement.src = this.canvas.nativeElement.toDataURL("image/png");
        this.img.nativeElement.style.display = "block";
        this.canvas.nativeElement.style.display = "none";
    }

    ngOnInit() {
    }
    close(event) {
        console.log(event);
    }
    ngAfterViewInit() {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    this.video.nativeElement.src = window.URL.createObjectURL(stream);
                    this.video.nativeElement.play();
                })
        }
    }
    public show() {
        this.img.nativeElement.style.display = "none";
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    this.video.nativeElement.src = window.URL.createObjectURL(stream);
                   
                    this.video.nativeElement.play();
                })
        }
    }

    upload() {
        this.uploadPhoto.emit(this.img.nativeElement.src);
    }
}
